# Isolated residual-component-tree proposal checkpoint

Task UUID: 63c7feaa-c07f-44a7-b19c-9e40e23d5b21. No production files edited. No DST/RAM state, score thresholds, model-specific rules, chosen merge node or actor/AT identity were introduced.

## Concrete current defect and evidence

At the exact saved 4200s source frame, residual25 isolates the gray mallet head beside the brownie-shaped body, residual34 covers a thin handle/fragment, and residual2 is part of the command UI. The main body is split across other raw residuals. `map-video-residual.mjs` extracts only 4-neighbour components above its single global Otsu split. `fitRenderedBody` then treats each component ROI as a possible complete body extent and uniformly scales a whole normalized template to that ROI. It preserves aspect ratio; there is no anisotropic stretching bug. This candidate-domain limitation permits cloud templates to explain disconnected bright fragments as separate hypothetical bodies.

Seven relevant renderer/descriptor modules are byte-identical to the current parent integration stage. Fresh exact-video/ROM thumbnail replays reproduce all 831 model/region gains across the five fixed frames. Current map compatibility binding preserves all original final predictions: 4200 false z038a at25/2/34, 1200 z061c at58, c28 unknown,2355 unknown,3300 z002b at120/131. Full source hashes are in evidence/RENDERER_CURRENT_SOURCE_CHECK.json.

## Implemented source

`web/residual-component-tree.mjs` exports:

- `residualComponentTreeAlternatives`: validates the exact complete raw component domain against the supplied known residual pixels. It enumerates every distinct original-component merge set at all integer levels below the unchanged Otsu split. It emits only the first extent for each merge set. No new threshold or radius is selected. Equal-level pixels are processed together. Original raw regions remain unchanged, with their original IDs.
- `budgetResidualMergeAlternatives`: admits a caller-supplied number of optional groups in deterministic merge-level/source-scan order. It retains the complete group domain and every omitted group as uncomputed/unknown. It never changes the original raw-component queue.

Each group preserves exact frame/background-branch binding and original residual IDs. A group is only a competing partial-body proposal: weak residuals may connect different objects, party, UI or background errors. It does not certify common actor membership, add a sighting/draw, narrow AT or select a species. Entry/background/current-source identity mismatches reject; current-source changes cancel.

The module is not wired into production. This is a candidate-enumeration checkpoint, not an identity correction ready to activate.

## Results and decisive negative

All five frames' raw components are preserved. The component tree emits37/190/421/199/167 groups for4200/1200/c28/2355/3300 respectively:1,014 total. Every group has a current-code fit for every retained model,6,267 model/group fits total. Positive best-body counts are14/78/85/65/62. Positive gain is not objectness proof. Explicit budgets0/1/32/full have complete uncomputed ledgers.

At4200 one automatically enumerated node spans the main body and mallet (40×31). With unchanged fitting, z002b gains3,173,506 while z038a gains−31,827. Smaller fragment ancestors continue preferring z038a; larger background ancestors become negative. No node was selected or excluded from evaluation.

A fresh pinned ONNX Runtime Web1.23.2 WASM/DINO pass evaluates all49 raw components and37 groups against all72 supported production thumbnails of the five source models.

- Using retained exact native256×192 query pixels, the whole-body node ranks z002b0.6022 ahead of z005b0.6003 and agrees with its body-fit winner. However three additional grouped UI/background z038a agreements are false. Raw25/34 appearance rankings also differ from saved full-resolution scores. This sampling-domain result is not production descriptor parity.
- A bounded formal-video decode recovers exactly the saved frame's I420 bytes: SHA2563dff4cff3e5aa9cf4c99fbf157c12c921e08f8f99c7bf8ad4bf4361f5b1b3d85 matches saved copiedYuvSHA256. FFmpeg's full-resolution RGBA conversion differs from browser-canvas RGB (hash47bef83ea442738d888c45448af13189a956fdaabb43088196124618d66b2c0f versus saved727f8e46111c5007e0cd6ffd002174b5ab5dc8da2831755822f8758855185482); these are explicitly separate domains.
- The full-resolution exact-source-frame pass preserves the saved first-ranked model for all10 original classified regions, though scores differ. On the grouped whole-body node it instead ranks z005b0.5504 above z002b0.5208. Thus it fails the body/appearance agreement. Only one grouped agreement remains, a false background z038a region.

The native-resolution agreement was sampling-domain dependent. Do not promote this as a species or false-positive fix. The implementation proves a missing whole-body extent can be proposed automatically without selecting a threshold, but current appearance inference still does not reliably identify it. No new DINO passes on the other four frames' grouped nodes are claimed; those have exhaustive group/body-fit coverage only. No live UI or AT integration was performed.

## Tests and failures retained

39 synthetic assertions pass, including11 malformed/stale input rejections, source cancellation, equal-level merge stability, unknown/party/background semantics, unchanged raw components, and bounded omission ledgers.

The first harness run referenced absent baseline monster_geometry.wasm; the existing recovered public source artifact was then used. The second harness failed to mimic production's unsupported-animation catch; it was corrected to skip and record the same unsupported clips as production. Both original failure logs remain private. No animation parser restriction was relaxed. The first pre-map-binding summary is superseded by the final current-source binding result; raw gains were identical throughout.

Earlier3300 source-shape-anchor experiments already failed and remain in their original frozen checkpoint. They were not repeated or promoted here.

## Reproduction

Run from the workspace root, using the existing private fixtures documented in the scripts:

    node correct-false-body-4200-63c7feaa/tests/component-tree.test.mjs
    node correct-false-body-4200-63c7feaa/scripts/component-tree-fixed.mjs
    SCORE_TREE=1 node correct-false-body-4200-63c7feaa/scripts/replay-current-thumbnails.mjs
    node correct-false-body-4200-63c7feaa/scripts/score-tree-4200.mjs
    node correct-false-body-4200-63c7feaa/scripts/describe-tree-4200.mjs
    node correct-false-body-4200-63c7feaa/scripts/describe-tree-4200.mjs full

The `full` descriptor command additionally requires the private exact4200 FFmpeg RGBA and I420 files. The script validates the I420 hash against the saved capture before accepting that full-resolution domain. It never claims the resulting RGB is browser-identical.

Raw video, ROM, raster/template pixels, source vectors, intermediate frame buffers and large evidence remain private. The source archive contains only this report, the one new module, scripts/tests, source hashes and aggregate results. Parent owns any further integration decision.

## Same deployed camera-conditioned source service follow-through

All four native-query agreement groups (including every UI/background false case) were sent through the deployed-stage automatic native support service with all five retained models and the complete retained camera set. No new production adapter or source service change was necessary: grouped ROI IDs remain separate strings with their original component provenance. The production budget remains1,500ms/128 proposals per slice. An explicit40-slice maximum was set; the predetermined first-sweep plus one emitted-path outcome for every model/camera pair finished in4 slices, with20/20 pairs and67 actual source renders. Unsearched stored-domain alternatives remain; this is not exhaustive pose enumeration.

The deployed camera alternative comparator returns unknown for all four groups. The body-sized group has z002b gain897,772 and all tested rivals negative. Both small background groups have all tested models negative. The command-UI group still has positive z002b1,388,920, z043a1,346,735 and z038a1,214,309.

Every group retains a common incomplete rival: z038a uses the mixed source-composition raster and its extent metadata explicitly states that the final-writer ownership mask can omit an earlier body contribution through later map blending. The compositor writes colorOwnerIsBody = Number(body) after each accepted map/body translucent fragment; the extent reader intentionally does not claim complete contribution ownership. No comparator condition was relaxed, and missing rival evidence was not converted into a background decision. GROUPED_NATIVE_SUMMARY.json records all four outcomes.

Reproduce this additional bounded check after the native-query DINO output exists:

    node correct-false-body-4200-63c7feaa/scripts/replay-grouped-native-4200.mjs

The missing grouping proposal is therefore demonstrated, but neither classification nor false-box correction is ready for production. Full-resolution grouped appearance still disagrees, and mixed-material ownership is incomplete. No hard exclusion, selected node, species certification or AT event was added.

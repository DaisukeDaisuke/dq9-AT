import{EnemyProposalTracker,PROPOSAL_LIMITS}from'../monster-position-proposals.mjs?v=video-replay-tracking-20261006-0423';
import{trackingGray,patchTrackingFrame,correspondVideoPatch,videoTrackingFrameKey,videoTrackingSourceKey}from'./video-patch-correspondence.mjs?v=video-replay-tracking-20261006-0423';
const clone=x=>structuredClone(x),time=f=>f.stamp.mediaTime??f.stamp.videoTime,scope=b=>JSON.stringify([b?.romSHA256,b?.recordKey,b?.mapId]),pause=()=>new Promise(r=>setTimeout(r,0));
const frameStamp=(f,trackingObservationSequence)=>({videoTime:time(f),frameSerial:f.stamp.frameSerial??null,trackingSequenceScope:'retained-frame-replay-pair',trackingObservationSequence,sceneContext:{gameplayROI:{x:0,y:0,w:256,h:192}}});
function restoredTracker(previous,tracks){const tracker=new EnemyProposalTracker();tracker.tracks=clone(tracks);tracker.previous={captureStamp:frameStamp(previous,0),trackingFrame:patchTrackingFrame(previous,tracks)};return tracker;}
const trackingRows=rows=>rows.map(r=>({id:r.id,roi:clone(r.roi),firstSeen:r.firstSeen,lastSeen:r.lastSeen,sightings:r.sightings,...(r.measuredCorrespondence?{partialPatch:r.measuredCorrespondence.partialPatch===true,knownPatchSamples:r.measuredCorrespondence.forward.knownSamples,observedPatchROI:clone(r.measuredCorrespondence.observedROI),unobservedPatchPixels:r.measuredCorrespondence.unobservedPatchPixels}:r.partialPatch!==undefined?{partialPatch:r.partialPatch,knownPatchSamples:r.knownPatchSamples,observedPatchROI:clone(r.observedPatchROI),unobservedPatchPixels:r.unobservedPatchPixels}:{})}));
/** Fixed-size actual-pixel replay. There are no predicted frames, root
 * propagation, species decisions or inferred birth/death/AT events here. */
export class VideoTrackingReplay {
 constructor({maximumFrames=256,maximumWorkSliceMs=8,correspond=correspondVideoPatch,onState=()=>{},yieldTask=pause}={}){if(!Number.isSafeInteger(maximumFrames)||maximumFrames<2)throw Error('At least two retained measured frames required');if(!Number.isFinite(maximumWorkSliceMs)||maximumWorkSliceMs<=0)throw Error('Positive cooperative replay work budget required');Object.assign(this,{maximumFrames,maximumWorkSliceMs,correspond,onState,yieldTask,generation:0,sequence:0,activeFrames:[]});this.reset('initial');}
 reset(reason='source-reset'){this.generation++;this.frames=[];this.history=new Map();this.source=null;this.batch=null;this.evictedFrames=0;this.rejectedFrames=0;this.gaps=[];this.reason=reason;if(!this.activePromise){this.busy=false;this.activePromise=null;}this.onState(this.snapshot());}
 noteGap(stamp,reason){this.gaps.push({sourcePTS:stamp?.mediaTime??stamp?.videoTime??null,reason,observed:false,absenceCertified:false});if(this.gaps.length>this.maximumFrames)this.gaps.shift();}
 retain({image,stamp}){
  const pts=stamp?.mediaTime??stamp?.videoTime;
  if(typeof stamp?.sourceId!=='string'||!['sourceEpoch','timelineSegment'].every(k=>Number.isSafeInteger(stamp[k])&&stamp[k]>=0)||!Number.isFinite(pts)||pts<0||!/^[a-f0-9]{64}$/.test(stamp.gameplayRGBA_SHA256??'')){this.rejectedFrames++;this.noteGap(stamp,'actual-frame-binding-unavailable');return null;}
  const source=videoTrackingSourceKey(stamp);if(this.source!==null&&source!==this.source)this.reset('source-identity-changed');this.source=source;
  const key=videoTrackingFrameKey(stamp),same=this.frames.find(f=>f.key===key);if(same)return same.key;
  const sameTime=this.frames.find(f=>time(f)===pts);if(sameTime){sameTime.conflicted=true;this.rejectedFrames++;this.generation++;this.history.clear();if(this.batch){this.batch.tracks=[];this.batch.stopped='same-PTS-different-pixels';}this.noteGap(stamp,'same-PTS-different-pixels');this.onState(this.snapshot());return null;}
  if(this.frames.length===this.maximumFrames&&pts<time(this.frames[0])){this.rejectedFrames++;this.noteGap(stamp,'late-frame-history-evicted');return null;}
  const pixels=trackingGray(image),f={key,stamp:clone(stamp),...pixels};this.frames.push(f);this.frames.sort((a,b)=>time(a)-time(b));while(this.frames.length>this.maximumFrames){const old=this.frames.shift();this.history.delete(old.key);this.evictedFrames++;}this.schedule();return key;
 }
 seed({stamp,backgroundEvidence,tracking}){
  const key=videoTrackingFrameKey(stamp),frame=this.frames.find(f=>f.key===key),pts=stamp.mediaTime??stamp.videoTime;
  if(!frame||frame.conflicted){this.noteGap(stamp,'residual-seed-frame-not-retained');return{ready:false,reason:'residual-seed-frame-not-retained',identityCertified:false};}
  if(this.batch&&pts<=time(this.batch.seed))return{ready:false,reason:'older-or-identical-seed-retained',identityCertified:false};
  const rows=(tracking?.observed??[]).slice(0,PROPOSAL_LIMITS.maxTracks);
  const valid=r=>typeof r.id==='string'&&r.id.length>0&&r.lastSeen===pts&&Number.isFinite(r.firstSeen)&&r.firstSeen<=pts&&Number.isSafeInteger(r.sightings)&&r.sightings>0&&r.roi&&['x','y','w','h'].every(k=>Number.isFinite(r.roi[k]))&&r.roi.w>0&&r.roi.h>0&&r.roi.x>=0&&r.roi.y>=0&&r.roi.x+r.roi.w<=256&&r.roi.y+r.roi.h<=192;
  if(!rows.every(valid)||new Set(rows.map(r=>r.id)).size!==rows.length){this.noteGap(stamp,'residual-seed-track-binding-unavailable');return{ready:false,reason:'residual-seed-track-binding-unavailable',identityCertified:false};}
  const tracks=trackingRows(rows);
  this.generation++;this.history.clear();
  this.batch={id:'measured-replay-'+(++this.sequence),seed:{key:frame.key,stamp:clone(frame.stamp)},previous:frame,tracks,mapScope:scope(backgroundEvidence),seedReferences:rows.map(r=>({trackId:r.id,originalProposalId:String(r.originalResidualId),sourceFrameKey:key,sourcePTS:pts})),steps:0,stopped:null,lastFailures:[]};
  this.onState(this.snapshot());this.schedule();return{ready:true,sourceFrameKey:key,tracks:tracks.length,identityCertified:false};
 }
 schedule(){if(this.busy||!this.batch||!this.frames.some(f=>time(f)>time(this.batch.previous)))return;this.busy=true;const mine=this.generation;this.activePromise=this.drain(mine).finally(()=>{this.activeFrames=[];this.busy=false;this.activePromise=null;this.schedule();});}
 async drain(mine){
  while(mine===this.generation&&this.batch){const b=this.batch,next=this.frames.find(f=>time(f)>time(b.previous));if(!next)break;const previous=b.previous,before=trackingRows(b.tracks),dt=time(next)-time(previous),failures=[],proposals=[];this.activeFrames=[previous,next];
   if(previous.conflicted||next.conflicted||!(dt>0&&dt<=PROPOSAL_LIMITS.maxGapSeconds)){b.stopped='unobserved-or-conflicted-frame-gap';b.tracks=[];this.noteGap(next.stamp,b.stopped);}
   else if(before.length){
    let sliceStarted=performance.now();
    for(const track of before){const local=this.correspond(previous,next,track.roi,{trackId:track.id});if(local.ready)proposals.push({proposalId:track.id,roi:local.roi,measuredCorrespondence:local});else failures.push({trackId:track.id,reason:local.reason,positionCurrent:false,absenceCertified:false});if(performance.now()-sliceStarted>=this.maximumWorkSliceMs){await this.yieldTask();if(mine!==this.generation||this.batch!==b)return;sliceStarted=performance.now();}}
    const tracker=restoredTracker(previous,before),result=tracker.update({captureStamp:frameStamp(next,1),proposals,trackingFrame:patchTrackingFrame(next,proposals)});
    const continued=result.observed.filter(r=>r.association==='tentative-continuation'&&r.id===r.proposalId),continuedIds=new Set(continued.map(r=>r.id));
    for(const p of proposals)if(!continuedIds.has(p.proposalId))failures.push({trackId:p.proposalId,reason:result.resetReason??'existing-association-gate-unresolved',positionCurrent:false,absenceCertified:false});
    b.tracks=trackingRows(continued);if(result.resetReason)b.stopped=result.resetReason;
    this.history.set(next.key,{batchId:b.id,previousKey:previous.key,previousFrame:previous,tracksBefore:before,continuedIds:[...continuedIds],failures:clone(failures),mapScope:b.mapScope,seedFrameKey:b.seed.key,seedPTS:time(b.seed),steps:b.steps+1});
   }
   b.steps++;b.previous=next;b.lastFailures=failures;this.onState(this.snapshot());await this.yieldTask();
  }
 }
 /** Apply only when the delayed ROM residual frame itself is present. Use the
  * existing conservative tracker on its immediately preceding measured state. */
 continuityFor({stamp,backgroundEvidence,components}){
  const key=videoTrackingFrameKey(stamp),record=this.history.get(key),current=this.frames.find(f=>f.key===key);
  if(!record||!current||current.conflicted||record.previousFrame.conflicted||record.mapScope!==scope(backgroundEvidence))return{ready:false,reason:'matching-measured-history-unavailable',identityCertified:false};
  const before=record.tracksBefore.filter(t=>record.continuedIds.includes(t.id));if(!before.length)return{ready:false,reason:'no-bidirectional-object-correspondences',identityCertified:false};
  const tracker=restoredTracker(record.previousFrame,before),observed=tracker.update({captureStamp:frameStamp(current,1),proposals:components.map(r=>({...r,originalResidualId:r.id,roi:clone(r.roi)})),trackingFrame:patchTrackingFrame(current,components)}),priorIds=new Set(before.map(r=>r.id));
  const associations=observed.observed.filter(r=>r.association==='tentative-continuation'&&priorIds.has(r.id)).map(r=>({originalResidualId:r.originalResidualId,trackId:r.id,firstSeen:r.firstSeen,lastSeen:r.lastSeen,sightings:r.sightings}));
  return{ready:associations.length>0,kind:'measured-video-patch-continuity-v1',id:record.batchId+':'+key,targetFrameKey:key,targetSourceKey:videoTrackingSourceKey(stamp),mapScope:record.mapScope,seedFrameKey:record.seedFrameKey,seedPTS:record.seedPTS,measuredSteps:record.steps,associations,identityCertified:false,birthCertified:false,absenceCertified:false,independentDrawCertified:false,minimumProvenATCalls:0};
 }
 snapshot(){const b=this.batch,ownedFrames=new Set([...this.frames,...this.activeFrames,...[...this.history.values()].map(h=>h.previousFrame),...(b?.previous?[b.previous]:[])]);return{schema:'measured-video-tracking-replay-v1',sourceKey:this.source,reason:this.reason,retainedFrames:this.frames.length,maximumFrames:this.maximumFrames,maximumWorkSliceMs:this.maximumWorkSliceMs,pixelBytes:[...ownedFrames].reduce((n,f)=>n+f.gray.byteLength+f.blocked.byteLength,0),retainedHistories:this.history.size,maximumRetainedPixelBytes:(this.maximumFrames+3)*49152*2,evictedFrames:this.evictedFrames,rejectedFrames:this.rejectedFrames,recentGaps:clone(this.gaps.slice(-8)),seedFrameKey:b?.seed.key??null,seedPTS:b?time(b.seed):null,currentFrameKey:b?.previous.key??null,currentPTS:b?time(b.previous):null,measuredSteps:b?.steps??0,tracks:clone(b?.tracks??[]),seedReferences:clone(b?.seedReferences??[]),lastFailures:clone(b?.lastFailures??[]),stopped:b?.stopped??null,historyComplete:false,identityCertified:false,bodyExtentCertified:false,birthCertified:false,absenceCertified:false,minimumProvenATCalls:0};}
 currentGray(){const f=this.batch?.previous;return f?{gray:f.gray.slice(),stamp:clone(f.stamp)}:null;}
 async settled(){while(this.activePromise)await this.activePromise;return this.snapshot();}
}

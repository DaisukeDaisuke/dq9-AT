# Negative checkpoint: original-component support shadow

**Do not promote.** This source-bound support policy loses the visible orange monster earlier than the unchanged bbox lane. The result is retained without changing gates or source inputs.

Task UUID: c719b65b-23c5-4709-ab00-50fa639c8c0d.
Baseline: frozen measured-video replay checkpoint SHA2560079e1dd00c60202d759ca5e6a605523052fa3671b6dc89699d66dd543f30f45, which remains byte-identical.

## Scope

Three source paths form the shadow delta:

- new map-browser-preview/video-component-support.mjs
- new map-browser-preview/video-component-correspondence.mjs
- copied map-browser-preview/video-tracking-replay.mjs with an optional correspondence callback; its default bbox behavior remains unchanged

No UI or production caller selects component support. This is a narrow offline single-seed shadow harness, not a production support-bank lifecycle implementation. The original bbox matcher file is byte-identical, and default replay outputs are verified equal. No native memory, DST, SAV, model selection, camera truth or RNG seed is supplied. Filename strings are used only to locate existing videos.

## Source support and exact policy

The producer validates the original video source/epoch/segment/PTS/full-frame hash, selected ROM-background branch, mask bytes, component bounds and original pixel count. It reconstructs the same4-connected component from the original residual mask. It never uses a hand-chosen ROI or masks from a later frame.

Orange residual12 has exactly418 connected pixels inside its22×33 rectangle (726 pixels). All418 are sampled. Components larger than the1024-sample work budget use a deterministic raster-order stride; omitted pixels are reported, and no pixel is duplicated to manufacture support.

Each successful correspondence keeps only support points observed in both frames. Points lost to clipping or unavailable pixels are removed from the active prior support. They are not replenished when a region returns onscreen. No morphological erosion is performed. This transported prior support is explicitly **not current segmentation** or a certified body mask. Appearance still comes from each actually observed previous image, so the matcher does not freeze the seed's RGB values.

The150-known-sample minimum and all inherited texture, residual, search-radius, temporal and association gates stay unchanged. Duplicated/out-of-template support points are rejected. Missing or insufficient support is unknown; it never becomes absence, death, a new detection or an AT event.

## Actual negative results

Each comparison uses the same actual frame sequence and same saved raw seed boxes for both lanes: exact browser seed pixels followed by source-PTS-bound FFmpeg frames. Mixed decoder evidence remains explicit; no color correction is applied.32 raw regions are seeded, including UI/background/party/error possibilities; these counts are not monster accuracy.

- **Orange170.312:** bbox survives through170.712; component support fails immediately at170.412. Its best translation is(-6,+3), with418 known samples and clipped mean residual14.3708133971, above the unchanged limit14. No14.4/14.5 tolerance was tried. Bbox/support track counts at the first step are6/2; support never recovers orange12.
- **Legacy5306.5:** bbox/support counts start2/1. Residual51 remains unresolved. Separate residuals17 and31 contain84/26 exact component points and fail the unchanged150-sample minimum; rectangle pixels are not borrowed and the components are not merged.
- **Fragmented3300:** bbox/support counts start3/2 and both reach0 at3300.7. Existing fragmented/gray probe failures are not reclassified as solved.
- **Holdout5330:** counts start3/3, become3/2 at5330.2, then remain2/2 later. No accuracy improvement is claimed.

Across these four measured sequences, support-only continuations do not appear: retained support-lane IDs are a subset of bbox-lane IDs at every step. This is a statement about these inputs, not all cases. Unknown/body/identity/birth/AT certifications remain false. Lower work time in some runs comes with earlier failures/fewer tracked hypotheses and is not a performance or quality win.

SUMMARY.json retains exact selected failures, support counts, all fixture PTS, aggregate counts and measured times. Full local comparison logs remain in evidence/; raw/decoded video pixels are excluded from the checkpoint.

## Tests

16 source/binding/geometry checks pass:
- exact418 source-component points and distinct84/26 components
- mutated source hash, epoch, PTS, ROM, branch, mask bytes, bounds/count and duplicate IDs rejected
- deterministic sampling without duplicates
- clipping400 points to280, with120 explicitly removed and never replenished
- insufficient support and original temporal/source gates

Two additional checks verify unchanged bbox source bytes and default callback-driver output parity. These18 checks establish plumbing and failure handling, not successful tracking. All observed orange/fixed failures remain.

## Reproduce

```sh
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/support-source.test.mjs
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/default-callback-parity.test.mjs
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/measure-shadow.mjs orange
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/measure-shadow.mjs legacy
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/measure-shadow.mjs fragmented
node connect-moving-tracks-c719b65b/component-support-shadow-0513/tests/measure-shadow.mjs holdout
```

The source-only ZIP includes full changed files, exact prior driver, patch, test scripts, this README, summary and hashes. It excludes ROM, assets, masks, video, decoded frames and secrets. It depends on the separately frozen six-file lane and original private inputs. No Git write, deployment, browser or user-computer action was taken.

The next separately authorized experiment is per-hypothesis ROM body-color ownership support, retaining every model/camera alternative. Raw residual support is not silently substituted for that footprint, and this negative checkpoint stays frozen.

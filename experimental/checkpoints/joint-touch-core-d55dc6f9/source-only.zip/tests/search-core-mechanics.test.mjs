// These intentionally tiny generated fixtures test candidate mechanics only.
// They are not ROM sprites, game execution, video evaluation or calibration.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { JOINT_SEARCH_PLAN_SHA256, SEARCH_BUDGET, jointRoleScore,
  searchJointTouchVectors, scoreExactJointRaster } from '../web/joint-touch-search-core.mjs';
let assertions = 0;
const eq = (a,b) => { assert.deepEqual(a,b); assertions++; };
const bad = (fn,re) => { assert.throws(fn,re); assertions++; };
const reject = async (fn,re) => { await assert.rejects(fn,re); assertions++; };
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
eq(hash(fs.readFileSync(new URL('../evidence/SEARCH_PLAN.json', import.meta.url))), JOINT_SEARCH_PLAN_SHA256);
eq(jointRoleScore([0,0,0,0]),1); eq(jointRoleScore([1,1,1,1]),0);
eq(jointRoleScore([0,0,0,1]),.375);
bad(() => jointRoleScore([0,0,0]),/Four/); bad(() => jointRoleScore([0,0,0,NaN]),/Four/);
const image = {width:24,height:16,rgba:Uint8ClampedArray.from({length:24*16*4},(_,i)=>i%4===3?255:(i*17)%256)};
const sprite = () => ({width:2,height:2,rgba:Uint8Array.from([0,100,255,255, 20,120,240,255, 80,200,255,255, 0,0,0,0])});
const model = {sprites:Array.from({length:4},sprite), originPoints:[[{x:-1,y:-1,rgb:[0,100,255]}],[{x:1,y:1,rgb:[80,200,255]}]],
  constants:{minimumDistanceFx:8*4096,shaftWidthScale:4096,shaftLengthBias:4096,shaftLengthDivisor:2*4096,headScaleX:4096,headScaleY:-4096}};
const pixels = hash(image.rgba), inputs = JSON.stringify(model);
let checks = 0, yields = 0;
const result = await searchJointTouchVectors(image,model,{checkCurrent:()=>{checks++;},yieldTask:async()=>{yields++;}});
eq(result.statistics.originPlacements,22*14); eq(result.statistics.unsupportedOriginPlacements,24*16-22*14);
eq(result.statistics.coarseVectorEvaluations,result.statistics.retainedOriginProposals*6*4);
eq(result.statistics.exactRasterProposals<=SEARCH_BUDGET.exactRaster,true);
eq(result.proposals.every(p=>p.origin.length===2&&p.endpoint.length===2&&p.origin.concat(p.endpoint).every(Number.isInteger)),true);
eq(result.proposals.every(p=>Math.hypot(p.origin[0]-p.endpoint[0],p.origin[1]-p.endpoint[1])>=8),true);
eq(result.proposals.every(p=>p.proposalOnly),true);
eq(result.unknownAlternatives.some(p=>p.kind==='absent-overlay'),true);
eq(result.unknownAlternatives.some(p=>p.kind==='short-vector-heading'),true);
eq(result.unknownAlternatives.some(p=>p.kind==='uncomputed-vectors'),true);
eq(result.threshold,null);eq(result.admitted,false);eq(result.pixelOwnershipVerified,false);eq(result.safeForHardPruning,false);eq(result.excludedPixels,0);
eq(hash(image.rgba),pixels);eq(JSON.stringify(model),inputs);eq(checks>16,true);eq(yields>0,true);
const repeat = await searchJointTouchVectors(image,model);eq(repeat,result);
await reject(()=>searchJointTouchVectors(image,model,{checkCurrent:()=>{throw Error('Cancelled or stale');}}),/Cancelled/);
await reject(()=>searchJointTouchVectors({...image,rgba:new Float32Array(image.rgba)},model),/byte RGBA/);
await reject(()=>searchJointTouchVectors(image,{...model,sprites:[]}),/four-sprite/);
const native = {width:4,height:1,rgba:Uint8ClampedArray.from([0,0,0,255,80,100,200,255,150,140,100,255,255,255,255,255])};
const raster = {isolatedRasterReady:true,width:4,height:1,rgba:native.rgba.slice(),owner:Int32Array.from([0,1,2,3])};
const scored = scoreExactJointRaster(native,raster);eq(scored.complete,true);eq(scored.score,1);eq(scored.roleCounts,[1,1,1,1]);
raster.owner[3]=0;eq(scoreExactJointRaster(native,raster).complete,false);raster.owner[3]=3;
raster.rgba[15]=0;eq(scoreExactJointRaster(native,raster).complete,false);raster.rgba[15]=255;
eq(scoreExactJointRaster(native,{isolatedRasterReady:false,failures:['unsupported']}).complete,false);
bad(()=>scoreExactJointRaster(native,{...raster,width:3}),/shape/);
const summary={assertions,scope:'Generated tiny fixtures test pure mechanics only; no ROM/video dependencies were available after environment replacement',
  deterministic:true,sourceAndVideoInputsUnchanged:true,absentAndUncomputedAlternativesPreserved:true,threshold:null,realFramesTested:0};
fs.writeFileSync(new URL('../evidence/CORE_MECHANICS_TESTS.json',import.meta.url),JSON.stringify(summary,null,2));
console.log(summary);

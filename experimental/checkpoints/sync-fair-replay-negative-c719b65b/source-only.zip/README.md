# Synchronous-between-yields fair replay successor (held)

One isolated scheduler-plumbing change. Do not activate production on this evidence. Original orange retention is unchanged, paired speed differences are small and one fixed fixture is slower.

## Change and exact invariants

video-fair-correspondence.mjs no longer creates/awaits a promise for every displacement cost. advance() returns a plain step when no cooperative yield is due, and returns a promise only at the same explicit yield condition. Cancellation guards remain before each step and after every actual yield. Search procedures, thresholds, evaluation order, baseline reservations,594 × active-original ceiling, round-robin quanta and current-only conditional-bank policy are unchanged.

The matcher and replay files are byte-identical to the frozen fair-replay predecessor. Test-only source instrumentation compares every displacement evaluation across all four complete full32 sequences. Entire outputs, cost prefixes, budgets, progress and yield boundaries match under a controlled clock. Cancellation at the third controlled yield produces the identical prefix and no completed-step publication. Instrumentation does not alter source files.

Actual baseline records and conditional position/parent sets also match the slower predecessor exactly. No source ID, region, model or known answer is targeted. Orange still loses at170.812; raw region315 is only a conditional image path, not an enemy gain. Prior unverified links become explicit unknowns and receive no future allocation. No classifier, camera-input, identity or AT changes are included.

## Timing, including worse results

One paired warmup followed by four predetermined alternating-order pairs, using the same actual full32 inputs and headless yield microtasks:

- Orange median219.91→210.04ms, about4.5% lower.
- Legacy median173.75→170.42ms, about1.9% lower.
- Fragmented median153.72→159.39ms, about3.7% worse.
- Holdout median227.13→221.02ms, about2.7% lower.

Every individual timing, warmup and adverse pair is retained. These changes are small relative to variability and do not establish a general performance benefit. The substantial overhead relative to the original single-winner replay remains.

Mounted browser-controller code with controlled Node Canvas/VideoFrame providers: asynchronous predecessor169.00ms versus successor157.78ms. Both retain13 frames while background work waits, replay11 steps, classify once and close13/13 handles. Timer gaps43.60→45.14ms are worse. Source-work slice maximum11.99→9.58ms; both exceed the requested8ms, so no hard realtime deadline is claimed. This is controlled mounted timing, not a live browser/renderer throughput measurement.

## Tests and limits

Six new exact-prefix checks pass. The12 fair runtime/source/lifecycle checks,45 existing mounted-controller checks,8 capture/resource checks and8 edge/binding checks pass again. The controlled mounted test's four checks pass. The preserved original replay suite has9 passing assertions and the same one failing overlapping-duplicate assertion(expected0,actual1), with exit1. Inputs and expected outcome remain unchanged.

The slow predecessor archive remains immutable. Original active-track budgets, default256-frame pixel bound and current-only hypothesis storage are unchanged. Runtime validation still covers source changes, hash/map binding, cancellation during a cost yield, newer delayed seeds, evicted seeds, missing actual history, frame-serial preservation and70-step bounded resource behavior. No new accuracy gain, full automation or actor identity claim follows.

## Reproduction

From the authorized workspace root:
- Run tests/measure-fair.mjs with orange, legacy, fragmented and holdout under this directory.
- Run tests/paired-timing.mjs with the same four arguments.
- Run tests/sync-prefix.test.mjs and tests/fair-runtime.test.mjs.
- tests/mounted-cooperative.test.mjs accepts `web sync` or `../fair-replay-0621/web async`.
- tests/run-preserved-replay-suite.mjs intentionally exits1 for the unchanged duplicate assertion.

These use the original saved browser seed pixels and existing actual FFmpeg crops/PTS, plus the frozen predecessor source. Subsequent frames retain their own hashes and do not inherit the seed serial/full-frame hash. Mixed-decoder evidence is not browser pixel parity. The source-only checkpoint contains the one full changed source file, its exact baseline, patch, relevant tests, all timing/check summaries and manifests. Restore above the isolated fair-replay predecessor, never over current production without review. ROM, videos, pixels, masks, game assets, emulator states and credentials are excluded.

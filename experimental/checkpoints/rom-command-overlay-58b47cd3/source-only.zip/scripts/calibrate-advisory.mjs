import fs from'node:fs';import{source,root,hash}from'./fixtures.mjs';import{calibrateCommandOverlayAdvisory}from'../web/rom-command-overlay-advisory.mjs';
const protocol=fs.readFileSync(root+'ROBUST_CALIBRATION_PROTOCOL.json'),{resource}=await source();
const{result,positives,negatives}=calibrateCommandOverlayAdvisory(resource,{protocolSHA256:hash(protocol)});
fs.writeFileSync(root+'ADVISORY_CALIBRATION.json',JSON.stringify(result,null,2));fs.writeFileSync(root+'private-evidence/ADVISORY_CALIBRATION_FULL.json',JSON.stringify({result,positives,negatives},null,2));console.log(result);

# Root browser validation handoff

Status: source/mounted candidate; live browser performance not verified. Root's localhost attempt returned ERR_BLOCKED_BY_CLIENT after a bounded retry. Do not bypass via another IP, tunnel, proxy or security-setting change. This candidate has not been published by the worker.

Candidate web root: /workspace/scratch/4d4d74ad4379/integrate-measured-replay-a9f6b3fc/web
Entry path: /map-browser-preview/index.html
Candidate revision: measured-replay-candidate-20261006-0653
Base web commit:126d5dfd207ce2dbf144ce196c48dd84f5ef5828. Later root backup commits do not themselves change that source baseline.

## Build dependency

Root owns the successful formal LLVM19 build at:
/workspace/scratch/4d4d74ad4379/inspect-at-connection-20261004-2203/local-browser-validation-0655/web/wasm

The candidate's copied WASM directory may contain repository placeholders. Before an actual local candidate run, root should copy/verify its own completed code-build WASM outputs into the isolated candidate web/wasm directory. Do not run concurrent scripts/build.sh: its temporary object names are not unique. The worker has not rebuilt, changed or uploaded those binaries. They are not in the source checkpoint. Root decides whether/when the reviewed source and code-built WASM are published by its permitted route.

## Normal file selection and activation

Only after a permitted candidate browser route works and its entry revision is verified:

1. Select recovery-20261004-2203/verified/dq9_new2.nds in input#rom. Expected ROM SHA256:3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7. Keep it a private browser file selection, not a repository or server asset.
2. Select recovery-20261004-2203/verified/videos/1ninn.mkv in input#comparison-file. Existing source size330181795 bytes. Do not upload the video into repository/server assets.
3. Either click button#auto-map-search once or use the native video's play control once. Test these as separate fresh runs, without manual map, model, layout, pose, seed, JSON or seconds entries. Leave the normal inference backend unchanged.
4. Allow ordinary playback and ROM rendering/classification to proceed. Missing maps, retained history or classifier readiness remain unknown. Do not substitute known game-state parameters to make the run succeed.

The script scripts/browser-readout.js is read-only and may be evaluated through the approved browser tool. It reads DOM evidence/status; it does not operate controls or set input parameters. Save readouts with their actual wall time and source PTS. Use existing download buttons for timeline/comparison/body evidence. Comparison exports now contain measuredVideoTracking and measuredClassificationView alongside the original frozen comparison; those timestamps intentionally may differ.

## Evidence to collect

- Confirm revision tag and file selections. While ROM rendering is busy, measuredReplay.retainedFrames should advance only on captured pixels; skipped/busy/unbound callbacks remain gaps.
- After residuals arrive, seedEvidence/seedFrameKey must identify their original frame. Replay currentPTS may advance through retained actual frames, without replacing the classification sourcePTS.
- For late classification, the candidate label appears beside the current measured patch only with an exact frame anchor or measured seed handoffs. Verify classificationPTS, positionPTS, both ages and anchor kind. Missing/evicted/lost anchors must show current binding unknown.
- A retained patch, old label or same model is not a new detection, same-actor proof or AT draw. All certification fields remain false/zero.
- Pause/resume retains valid state; seek/file/ROM replacement and explicit stop must clear stale replay/anchors. Stop must hide the live preview. Existing completed-classification panel remains explicitly historical.
- Sample retainedFrames/pixelBytes/maximumRetainedPixelBytes and classificationAnchorRetention. Defaults are256 measured frames and at most256×32 compact source/proposal references, with eviction/loss pruning.

## Performance limits requiring real-browser measurement

The fast path still uses a full1920×1080 getImageData readback before exact256×192 sampling:8,294,400 RGBA bytes per capture plus196,608 sampled bytes. At the0.1s capture budget, readbacks could total about82.9MB/s. These are explicit byte counts, not measured CPU/GPU time or total browser heap. One reusable canvas and one pending hash are retained; callbacks while hashing are skipped rather than queued. Every retained VideoFrame is closed on success/failure. Sampling/hash semantics were not optimized or replaced.

Record actual browser responsiveness, long tasks/frame gaps, render/classification latency and memory if the approved browser tool exposes them. Controlled mounted Canvas timings are not real getImageData/GPU timings. Without such a run, report browser runtime performance as unperformed.

## Existing fixed failures

The original duplicate assertion remains expected0/actual1. Its overlapping writes leave one exact patch and an overwritten first patch; the separate non-overlapping exact-tie fixture rejects ambiguity. Do not rewrite the old assertion or lower gates. In saved real pixels, orange12 lasts through170.712 and fails170.812; the current integration preserves that limit. No fair/set-valued/witness extra searches are present.

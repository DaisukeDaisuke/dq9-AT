import fs from 'node:fs';import assert from 'node:assert/strict';
import {source} from '../../restore-touch-geometry-4d501e2a/scripts/fixture-utils.mjs';
import * as prior from '../../restore-touch-geometry-4d501e2a/web/rom-touch-overlay-composition.mjs';
import * as current from '../web/rom-touch-overlay-composition.mjs';
const {opts}=source(),before=await prior.loadTouchOverlayComposition(opts),after=await current.loadTouchOverlayComposition(opts),
 inputs=JSON.parse(fs.readFileSync('restore-touch-geometry-4d501e2a/private-evidence/ROM_ORACLE.json'));
assert.deepEqual(after,before);
for(const row of inputs){const candidate={schema:'dq9-touch-vector-validation-candidate-v1',provenance:'synthetic-source-validation',origin:row.origin,endpoint:row.endpoint};
 assert.deepEqual(current.produceTouchOverlayPolygons(after,candidate),prior.produceTouchOverlayPolygons(before,candidate));}
const result={cases:inputs.length,completeValidationOutputIdentical:true,sourceDescriptorIdentical:true,
 scope:'Regression equality against the reconstructed independently ROM-validated producer after adding a provenance branch; not a new source oracle or video detection count'};
fs.writeFileSync('derive-touch-common-domain-ad3e0e26/evidence/VALIDATION_PATH_PRESERVED.json',JSON.stringify(result,null,2));console.log(result);

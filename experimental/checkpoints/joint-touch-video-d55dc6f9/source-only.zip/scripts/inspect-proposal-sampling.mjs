import fs from 'node:fs';import crypto from 'node:crypto';
import{openMapRom}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/static-scene.mjs';
import{readArm9Overlay}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/rom-overlay.mjs';
import{loadTouchOverlayComposition,produceTouchOverlayPolygons,snapshotTouchCompositionForRaster}from'../web/rom-touch-overlay-composition.mjs';
import{rasterTouchOverlayValidation}from'../web/rom-touch-overlay-raster.mjs';
const rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds'),s=await loadTouchOverlayComposition({...openMapRom(rom),romSHA256:crypto.createHash('sha256').update(rom).digest('hex'),fieldOverlay:readArm9Overlay(rom,17)}),p=produceTouchOverlayPolygons(s,{schema:'dq9-touch-vector-validation-candidate-v1',provenance:'synthetic-source-validation',origin:[64,48],endpoint:[96,80]}),r=rasterTouchOverlayValidation(s,p,{profile:'isolated-source-validation-native1x-Z-pre-fog'}),ss=snapshotTouchCompositionForRaster(s,p).sprites;
const results=[];
for(const role of[0,3])for(let oy=-2;oy<=2;oy++)for(let ox=-2;ox<=2;ox++){const sprite=ss[role],offset=role?s.transform.dotOffset:s.transform.ringOffset;let n=0,err=0;for(let y=0;y<sprite.height;y++)for(let x=0;x<sprite.width;x++){const i=(y*sprite.width+x)*4;if(!sprite.rgba[i+3])continue;const j=((48+offset.y+y+oy)*256+64+offset.x+x+ox)*4;for(let c=0;c<3;c++)err+=(r.rgba[j+c]-sprite.rgba[i+c])**2;n++;}results.push({role,ox,oy,err:err/(n*3*255*255)});}
console.log(JSON.stringify(results.sort((a,b)=>a.role-b.role||a.err-b.err),null,2));

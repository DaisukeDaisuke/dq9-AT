# Touch-origin overlay source checkpoint

隔離検証専用。本番経路には未接続。入力は ROM と映像のみであり、DST/RAM 由来の位置・姿勢・カメラ・入力状態を使用しない。未確定の UI 仮説からプレイヤー位置や敵の不存在を断定しない。

Task UUID: ab633c61-a525-4ea8-9aca-d00db48e9759. Protocol: Library libfile_564b88200db481919e83f5494a793df9, local DQ9_COMMITTEE_PROTOCOL_AUTH_v1_1.zip / PROTOCOL.md. Only the existing internal task workflow is used.

## Result and recommendation

The white ring and blue arrow are source-backed touch-control UI sprites, not a world-space player selection ring. The ring origin is taken from the touch-start screen-coordinate bytes. It can be away from the player. The ordinary field UI subpass is a 256×192 orthographic draw. Source arrow0 is drawn at touch origin minus(8,8), and later arrow3 at origin minus(4,4). arrow1/arrow2 draw the direction shaft/head between them, using a source rotation/length path. Current touch state and visibility remain unknown.

Two isolated modules implement a guarded runtime ROM reader and a whole-scene conditional competing-explanation path. They do not change production imports, residuals, classifications, tracking, or AT. The first frozen independent calibration fails. Do not activate this matcher or lower its gate: it supplies no acceptance threshold and no admitted alternatives on any fixed actual frame. Region18's false z038a prediction is not corrected by this checkpoint.

## Implemented files

- web/rom-touch-origin-overlay.mjs: verify twelve ROM code spans; derive four arrow resource paths, viewport dimensions and ring/dot offsets from guarded instructions/literals; decode source format3 sprites with paletted RGB555 semantics; preserve unsupported footer/visibility/overdraw states. Owned source snapshots reject mutation or a forged clone.
- web/rom-touch-origin-advisory.mjs: source-support luma descriptor, fixed source/procedural calibration, every fully contained integer translation, exact ROM/source/frame/pixel binding, cancellation and stale/mutated-input rejection, independent raw-component membership validation, per-placement conditional overlap annotations. No pruning authority exists, even for perfect source copies.

No existing source file was edited. The deployed baseline is not replaced. Direct imports resolve to the existing parent-camera-alternative-integration-0523 snapshot and read-only command-overlay checkpoint; dependency hashes are recorded in MANIFEST.json. The frozen preceding optional appearance-query checkpoint remains immutable.

## Source chain

- ARM9 02098254 loads four arrow%d.spr resources through 02048898 and its /data/ani/%s formatter.
- 02098330 updates touch-origin/current coordinate bytes. 02098474 passes them to the conditional draw; no player/world coordinate is used as the origin.
- 02098888 draws the ring/shaft/head/dot sequence. 02098a58 supplies the ring offset; 02098b88 supplies the dot offset. A short-distance direction fallback can consult actor heading. This checkpoint does not execute or supply that fallback.
- 020481e8,02048374,02048538 supply the default sprite transform and GX indexed-texture draw. Transparent palette index0, source RGB555 and default material apply only to the admitted ordinary path.
- Overlay17 02196cb0…02196f64 establishes the field UI projection and calls this draw. Width/height are derived from instructions at02196d3c/02196d34, not from a fitted actual box.
- Read-only source spans and sprite hashes are in CODE_BINDINGS.json / SOURCE_SUMMARY.json. Actual ROM bytes, decoded pixels and disassembly stay private.

The existing command sprite decoder rejected the arrow payloads because it disallows any palette high bit. The dedicated decoder follows the existing native texture unpacker's 15-bit palette semantics; toggling every palette high bit leaves each decoded arrow unchanged in tests. No shared decoder was changed.

This is not a full native UI rasterizer. Shaft/head overdraw, conditional visibility, animation/footer, capture filtering/phase/modulation, fractional placement, clipping and other later writes remain explicit unknowns. The ring+dot image is a bounded ordinary source hypothesis, not complete color ownership.

## Frozen calibration and negative finding

CALIBRATION_PLAN.json was written before any numeric actual-frame search. The fixed descriptor uses the minimum Pearson luma correlation of four spatial quadrants and source-only blur0/1/2 variants. Only exactly opaque support is sampled; no box/background fill is declared source-owned.

Source support is104 pixels,26 per quadrant. One blur leaves only24 fully opaque pixels,6 per quadrant. Two blurs leave1 per quadrant, so that variant is omitted as uninformative. The predeclared486 synthetic positives span six procedural backgrounds, three capture blur passes, gain/bias and bounded noise. The78 negatives include whole-background search, color permutations, and omitted source quadrants/halves. The weakest positive is0.6780217436612193; the strongest negative is0.9805806756909202, a repeating checker background. Separation is false and threshold remains null. No calibration change followed actual results.

The limited blurred support can correlate strongly with periodic backgrounds. This is a concrete descriptor failure, not evidence of a ring at its winning location. The exact default source copy itself scores essentially1 in a synthetic whole-scene search, but still cannot gain admission after failed calibration.

## Five actual frames and negative controls

Each frame searches42,657 placements. All registered approximate winners use the one-blur profile. No accepted alternatives, removed pixels, species changes or AT branches are emitted.

| Actual frame | Unfiltered best diagnostic score | Extra one-pass capture blur score | Raw components retained |
|---|---:|---:|---:|
|4200|0.8207724529|0.9452127057|49|
|1200|0.8733706266|0.8305396283|268|
|c28|0.8300162504|0.8359835501|716|
|2355|0.8673880760|0.8593325050|283|
|3300|0.8230281646|0.8550774066|247|

Visual inspection sees the arrow/ring in4200,1200,2355 and no visible arrow/ring in c28 or3300. Unfiltered maxima are background-pattern matches rather than reliable ring detections. The extra-blur4200 winner is ring-like at(111,92), but absent-frame backgrounds still score strongly. The extra blur is a separately reported out-of-domain control and never updates calibration or source pixels.

All1,563 connected components, their IDs/ROI/pixel counts, every original residual-mask byte and each original video-pixel byte are preserved. This is broader than the earlier125 classified-proposal subset; classification is not rerun or changed by these modules. The1200 positive and c28 alternative remain untouched through absence of any consumer edit, not through a claimed new detector success. The4200 region18 remains its original5×5,9-pixel component. Nearby body evidence is not erased.

## Tests and preserved failures

Commands from the shared workspace root:

    node explain-player-ring-ab633c61/scripts/calibrate.mjs
    node explain-player-ring-ab633c61/tests/touch-origin.test.mjs
    node explain-player-ring-ab633c61/scripts/replay-fixed.mjs

All50 assertions pass, including changed ROM-code rejection, forged/mutated source or calibration rejection, source/pixel mutation before and during scan, malformed/stale frame, cancellation, registration mutation/clone, changed residual membership and unchanged raw domains. The five-frame replay additionally compares exact calibration output, source pixels, original components and residual masks. The full negative calibration data are retained, not an expected-positive assertion rewritten to pass.

Preserved setup failures: shared SPR decoder's high-bit rejection; attempted zero-height preview after all four rejections; an inspection helper initially ignored a Uint8Array byteOffset and failed an initialized-ROM-range lookup. The original source-bindings-first-failure.log remains private. Its helper was corrected and successfully rerun. These failures did not alter source/projection findings or calibration.

## Missing link and stopping condition

The source/transform relation is established. This single bounded descriptor attempt fails both synthetic separation and actual localization. A safe competing explanation needs more complete source shaft/head/capture composition or a descriptor independently shown to reject periodic backgrounds while retaining ring evidence. No threshold adjustment, player-center prior, handpicked region, known monster label or native-memory state is justified. This checkpoint stops at that executable negative finding and does not request production activation.

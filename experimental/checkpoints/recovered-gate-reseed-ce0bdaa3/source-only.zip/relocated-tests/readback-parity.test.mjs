// Original TREE_DINO provenance file is unavailable after replacement. This derived test binds the same restored full/YUV bytes to the saved prior READBACK_PARITY receipt and the still-available fixed COMPARISON. It does not recreate the missing provenance file.
// Recovery relocation: same bytes at restored paths, original file preserved.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {sampleGameplayFrame as original,gameplayVideoROI as originalROI} from '../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/map-video-residual.mjs';
import {sampleGameplayFrame as candidate,gameplayVideoROI,gameplaySampleReadbackRect as rectFor} from '../web/map-browser-preview/map-video-residual.mjs';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),checks=[],rows=[];
const pass=s=>{checks.push(s);console.log('PASS '+s);};
export function crop(image,r){const out=new Uint8ClampedArray(r.w*r.h*4);for(let y=0;y<r.h;y++)out.set(image.rgba.subarray(((r.y+y)*image.width+r.x)*4,((r.y+y)*image.width+r.x+r.w)*4),y*r.w*4);return out;}
// Independent exhaustive oracle: all four addressed source pixels, including
// zero-weight neighbors, using the untouched original expression.
function addressedRect(roi){let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 for(let y=0;y<192;y++)for(let x=0;x<256;x++){
  const fx=clamp(roi.x+(x+.5)*roi.w/256-.5,roi.x,roi.x+roi.w-1),fy=clamp(roi.y+(y+.5)*roi.h/192-.5,roi.y,roi.y+roi.h-1),ix=Math.floor(fx),iy=Math.floor(fy),jx=Math.min(ix+1,roi.x+roi.w-1),jy=Math.min(iy+1,roi.y+roi.h-1);
  x0=Math.min(x0,ix,jx);y0=Math.min(y0,iy,jy);x1=Math.max(x1,ix,jx);y1=Math.max(y1,iy,jy);
 }
 return{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
}
function compare(image,roi,label){const rect=rectFor(image.width,image.height,roi),full=original(image,roi),uncropped=candidate(image,roi),cropped=candidate({...image,rgba:crop(image,rect)},roi,{sourceRect:rect});assert.deepEqual(rect,addressedRect(roi),label+' minimal rectangle');assert.deepEqual(uncropped,full,label+' default sampler');assert.deepEqual(cropped,full,label+' cropped sampler');const sha=hash(full.rgba);assert.equal(hash(cropped.rgba),sha);return{label,sourceSize:{width:image.width,height:image.height},roi,rect,sourceRGBA_SHA256:hash(image.rgba),sampleSHA256:sha,originalBytes:image.rgba.length,readbackBytes:rect.w*rect.h*4,bytesSaved:image.rgba.length-rect.w*rect.h*4,all196608SampleBytesEqual:true};}
let seed=0x5a53c3d1;function random(n){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;}
function pixels(width,height){const rgba=new Uint8ClampedArray(width*height*4);for(let i=0;i<rgba.length;i++)rgba[i]=random(0x100000000)>>>24;return{width,height,rgba};}
const cases=[
 [1,1,{x:0,y:0,w:1,h:1}], [2,2,{x:0,y:0,w:2,h:2}], [4,3,{x:0,y:0,w:4,h:3}],
 [256,192,{x:0,y:0,w:256,h:192}], [255,191,{x:0,y:0,w:255,h:191}], [257,193,{x:0,y:0,w:257,h:193}],
 [1920,1080,{x:960,y:0,w:960,h:720}], [513,389,{x:0,y:0,w:513,h:389}],
 [513,389,{x:1,y:1,w:511,h:387}], [513,389,{x:512,y:388,w:1,h:1}],
 [1024,768,{x:0,y:0,w:1024,h:768}], [1024,768,{x:1023,y:0,w:1,h:768}], [1024,768,{x:0,y:767,w:1024,h:1}],
 [261,199,{x:5,y:7,w:256,h:192}], [4096,3072,{x:0,y:0,w:4096,h:3072}],
];
for(let i=0;i<96;i++){const width=1+random(1024),height=1+random(768),x=random(width),y=random(height);cases.push([width,height,{x,y,w:1+random(width-x),h:1+random(height-y)}]);}
for(const [i,[w,h,roi]]of cases.entries())compare(pixels(w,h),roi,'synthetic-'+i);
pass(`${cases.length} dimensions/ROIs compare every 256x192 RGBA sample and all addressed extrema exactly`);
const image=pixels(260,196),valid={x:2,y:2,w:256,h:192};
for(const key of ['x','y','w','h'])for(const delta of [.5,-.5]){const roi={...valid,[key]:valid[key]+delta};assert.throws(()=>original(image,roi));assert.throws(()=>candidate(image,roi));assert.throws(()=>rectFor(image.width,image.height,roi));}
for(const roi of [{x:-1,y:0,w:2,h:2},{x:0,y:-1,w:2,h:2},{x:259,y:0,w:2,h:2},{x:0,y:195,w:2,h:2},{x:0,y:0,w:0,h:1},{x:0,y:0,w:1,h:-1},{...valid,w:NaN},{...valid,h:Infinity}]){assert.throws(()=>original(image,roi));assert.throws(()=>candidate(image,roi));assert.throws(()=>rectFor(image.width,image.height,roi));}
pass('Fractional/out-of-bounds/nonfinite/empty ROIs preserve rejection; no implicit rounding or clipping');
const rect=rectFor(image.width,image.height,valid);
for(const r of [{...rect,x:rect.x+1,w:rect.w-1},{...rect,y:rect.y+1,h:rect.h-1},{...rect,w:rect.w-1},{...rect,h:rect.h-1}])assert.throws(()=>candidate({...image,rgba:crop(image,r)},valid,{sourceRect:r}),/読戻し矩形/);
assert.deepEqual(candidate(image,valid,{sourceRect:{x:0,y:0,w:260,h:196}}),original(image,valid));
assert.throws(()=>candidate({...image,rgba:new Uint8Array(1)},valid,{sourceRect:rect}));
pass('Missing interpolation neighbors, invalid buffer sizes rejected; larger valid read rectangle remains exact');
for(const [width,height,layout]of [[1920,1080,'obs-side-1920'],[256,192,'single'],[4,3,'single'],[512,384,'single'],[256,384,'ds-vertical'],[512,192,'ds-horizontal'],[1024,1536,'ds-vertical'],[2048,768,'ds-horizontal']]){
 const roi=gameplayVideoROI(width,height,layout);assert.deepEqual(roi,originalROI(width,height,layout));rows.push(compare(pixels(width,height),roi,layout+'-'+width+'x'+height));
}
for(const [w,h,l]of [[1920,1080,'single'],[1919,1080,'obs-side-1920'],[512,193,'ds-horizontal'],[256,383,'ds-vertical'],[256,192,'unknown']]){assert.throws(()=>originalROI(w,h,l));assert.throws(()=>gameplayVideoROI(w,h,l));}
pass('Every existing layout preserves valid/invalid dimension handling; single-screen cases explicitly retain zero byte savings');
const comparisonRoot='recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005/',files=['BROWSER_1NINN_AUTOPLAY_COMPARISON_c28bcdf.json','BROWSER_LONG4200_COMPARISON_df40cb.json','BROWSER_LONG3300_COMPARISON_84747e3.json','BROWSER_LONG5306500_COMPARISON_eb44154.json','BROWSER_LONG5330_COMPARISON_84747e3.json'];
for(const file of files){const bytes=fs.readFileSync(comparisonRoot+file),cmp=JSON.parse(bytes),rgba=Uint8ClampedArray.from(cmp.nativeVideo.rgba),image={width:256,height:192,rgba};assert.equal(rgba.length,196608);const row=compare(image,{x:0,y:0,w:256,h:192},file);rows.push({...row,inputJSON_SHA256:hash(bytes),recordedMediaTime:cmp.video.mediaTime,recordedGameplaySHA256:cmp.video.gameplayRGBA_SHA256,nativeMatchesRecordedGameplay:hash(rgba)===cmp.video.gameplayRGBA_SHA256,scope:'Saved native pixels only; not reconstructed full browser pixels'});}
pass('Five fixed real native buffers remain byte/SHA identical without inventing absent full-resolution pixels');
const root='recovery-20261006-0852/capture-inputs/restored-fixed-captures/correct-false-body-4200-63c7feaa/evidence/',provenanceBytes=fs.readFileSync(new URL('../pinned-inputs/READBACK_PARITY.json',import.meta.url)),priorFull=JSON.parse(provenanceBytes).rows.find(row=>row.label==='existing-full-4200'),provenance={sourceRGBASHA256:priorFull.sourceRGBA_SHA256,sourceI420SHA256:priorFull.sourceI420SHA256},full=fs.readFileSync(root+'ffmpeg4200.rgba'),yuv=fs.readFileSync(root+'ffmpeg4200.yuv'),cmp=JSON.parse(fs.readFileSync(comparisonRoot+'BROWSER_LONG4200_COMPARISON_df40cb.json'));
assert.equal(hash(full),provenance.sourceRGBASHA256);assert.equal(hash(yuv),provenance.sourceI420SHA256);assert.equal(hash(yuv),cmp.video.analysisInput.copiedYuvSHA256);assert.equal(full.length,1920*1080*4);
const row=compare({width:1920,height:1080,rgba:new Uint8ClampedArray(full)},gameplayVideoROI(1920,1080,'obs-side-1920'),'existing-full-4200');
assert.equal(row.sampleSHA256,priorFull.sampleSHA256);rows.push({...row,inputPath:root+'ffmpeg4200.rgba',sourceI420SHA256:hash(yuv),originalProvenanceFileRevalidated:false,priorReceiptSHA256:hash(provenanceBytes),historicalProvenanceJSON_SHA256:priorFull.provenanceJSON_SHA256,recordedMediaTime:cmp.video.mediaTime,savedBrowserGameplaySHA256:cmp.video.gameplayRGBA_SHA256,sampledEqualsSavedBrowser:row.sampleSHA256===cmp.video.gameplayRGBA_SHA256,scope:'Existing verified source I420 converted by FFmpeg; comparison is old/new sampler on identical bytes, not FFmpeg/Canvas converter parity'});
pass('Existing real 1920x1080 full frame verifies source hashes and exact old/new sampled SHA');
fs.writeFileSync(new URL('../evidence/READBACK_PARITY.json',import.meta.url),JSON.stringify({checks,syntheticCases:cases.length,rows,browserPerformanceMeasured:false},null,2)+'\n');

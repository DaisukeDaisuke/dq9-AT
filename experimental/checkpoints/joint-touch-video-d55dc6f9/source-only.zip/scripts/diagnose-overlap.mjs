// Post-search diagnostic only. These historical residuals and labels NEVER enter
// the proposal search. Source alpha intersection is not observed pixel ownership.
import fs from 'node:fs';import assert from 'node:assert/strict';
import{unpackBranchRGBA,unpackBackgroundMask}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/background-branch-support.mjs';
import{cases,fixture,hash}from'./restored-fixtures.mjs';
const root='derive-video-touch-d55dc6f9/',rows=[];
for(const test of cases){const f=fixture(test),W=256,H=192,support=f.cmp.background.backgroundBranchSupport,
 branch=support.branches.find(b=>b.rowIndex===support.selectedPreviewRowIndex),bg=unpackBranchRGBA(branch.alignedBackgroundRGBA),known=unpackBackgroundMask(branch.knownMask),
 mask=Uint8Array.from({length:W*H},(_,i)=>known[i]&&Math.round([0,1,2].reduce((s,c)=>s+Math.abs(f.image.rgba[i*4+c]-bg[i*4+c]),0)/3)>f.cmp.stats.residualThreshold?1:0),
 labels=new Int32Array(W*H).fill(-1),queue=new Int32Array(W*H),found=[];
 for(let start=0;start<labels.length;start++){if(!mask[start]||labels[start]>=0)continue;const id=found.length;let head=0,tail=1,x0=W,y0=H,x1=-1,y1=-1;queue[0]=start;labels[start]=id;
  while(head<tail){const p=queue[head++],x=p%W,y=Math.floor(p/W);x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);
   for(const q of[x?p-1:-1,x+1<W?p+1:-1,y?p-W:-1,y+1<H?p+W:-1])if(q>=0&&mask[q]&&labels[q]<0){labels[q]=id;queue[tail++]=q;}}
  found.push({id,roi:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1},pixels:tail});}
 assert.equal(found.length,f.cmp.components.length);for(const c of f.cmp.components){const r=found[c.id];assert.equal(r.pixels,c.pixels);assert.deepEqual(r.roi,c.roi);}
 const alpha=fs.readFileSync(root+'private-evidence/TOP_RASTER_'+f.id+'.rgba'),overlaps=new Map();for(let i=0;i<labels.length;i++)if(alpha[i*4+3]===255&&labels[i]>=0)overlaps.set(labels[i],(overlaps.get(labels[i])??0)+1);
 rows.push({id:f.id,comparisonSHA256:f.comparisonSHA256,rawResidualSHA256:hash(mask),originalComponents:found.length,
  originalMembershipVerified:true,conditionalTopHypothesisOverlap:[...overlaps].map(([originalRegionId,sourceOpaqueSupportPixels])=>({originalRegionId,sourceOpaqueSupportPixels,originalResidualPixels:found[originalRegionId].pixels})),
  region18:f.id==='4200'?found[18]:undefined,excludedPixels:0,pixelOwnershipVerified:false,bodyDecision:'unchanged'});
}
fs.writeFileSync(root+'evidence/POST_SEARCH_RESIDUAL_DIAGNOSTICS.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows,null,2));

# Bounded set-valued video correspondence shadow

Status: held experiment. No verified-retention improvement, no production or AT identity wiring.

## Exact criterion and implementation

The original single-best matcher and measured replay are untouched. Two new isolated modules expose a bounded correspondence set and propagate it over actually observed frames. Forward candidates need not be the unique best, but they must satisfy the same150 known samples, texture2, clipped SAD<=14, clip40, strict displacement radius16 and0.5s source gap. A verified continuation still needs a completed independent reverse search whose unique best is the exact inverse, then the unchanged single-patch EnemyProposalTracker association gate. Ties are ambiguous. Fixed inverse SAD is never a confirmation: on a fully visible stride1 rectangle it is algebraically symmetric with forward SAD.

Each original track shares594 displacement-cost evaluations across all parents and reverse searches for one observed pair. This is the two-search ceiling of the original even coarse grid plus fine search:297+297. Best-score-first reverse verification preserves the original best candidate's place in the work order; it does not pick an accepted position. All tested forward-feasible positions are recorded. A completed nonreciprocal reverse best rejects that branch. Untested reverse searches and ties remain explicitly unverified. Budget-exhausted parent branches have unknown current position and never inherit a stale box as measured support. Identical current ROIs only coalesce within the same original track, with separate parent edges retained.

A verified local link cannot repair an unverified earlier link. Outputs count unique original tracks with wholly verified paths separately from originals having only unverified paths and from the number of current position hypotheses. These are raw-box correspondence paths, not confirmed monsters, species, actors, births or AT draws. Unknown/unsearched alternatives always remain. No branch count is reported as a detection success.

The bank stores one previous measured gray frame, current bounded states and their most recent evaluation summary. At most32 original seeds; omitted originals are explicit. Per original, both current states and parent edges are bounded by the594 cost budget. Source changes, nonpositive/over0.5s gaps and stale seeds invalidate propagation. It has no timer, no pending capture queue and no production caller. The existing256-frame replay, capture lifecycle, classifier and AT controller were not modified.

## Actual video results

All runs use the exact saved browser seed followed by the already retained actual FFmpeg PTS frames at0.1s spacing. Subsequent frames do not inherit the seed's full-frame hash or observed frame serial. This is a mixed-decoder headless comparison, not browser pixel parity. Each run has one original residual track, avoiding cross-actor branch mixing; it is not a full32-track controller performance result.

Orange residual12:
- Original and verified set paths last through170.712; both lose verified continuity at170.812.
- At that failure the six forward-feasible offsets are(4,-2),(4,-1),(4,-3),(5,-1),(3,-1),(5,-2), all726 known samples.
- The297-cost forward search plus297-cost independent reverse of the original best consumes the budget. Its reverse best(-4,+1) is not inverse to forward(4,-2), so that branch is rejected.
- The other five offsets stay unverified. They remain one unresolved original track, not five successes.
- Later frames do not resolve the missing link. Current unverified positions grow to43 at171.412; budget omissions remain unknown.

Fixed negatives/control rows, verified steps versus original single-track replay:
-5306.5 r17/r31:0/0 each.
-5306.5 r51:7/7, with up to80 unverified positions and55 at the last frame.
-3300 r99:6/6; r120/r126/r131/r141:0/0 each.
-5330 r371:4/4.

No verified lifetime differs in these four fixed actual sequences. No species/classification result changed. The additional hypotheses mostly multiply uncertainty. Initial and final headless timings are both retained in SUMMARY.json. Final orange baseline46.87ms versus bank92.75ms; r51 baseline62.52ms versus bank88.52ms. These small-run timings are noisy, but they do not support a speed or useful retention claim. Lower times on some immediately failing rows are not accuracy improvements. The original overlapping-duplicate fixture failure and all earlier worse component/ownership experiments remain preserved separately.

## Verification and reproduction

12 tests pass: original170.812 failure, budget derivation, six feasible candidates with independent reverse rejection, no promotion of unverified lineage, bounded positions/edges, source reset and explicit reseed, actual missing0.7s gap, owned seed buffers, track cap/omissions, stale/invalid seed rejection, exact repeated-texture ties and all four fixed actual comparisons. The prior three frozen source checkpoint ZIP hashes were rechecked unchanged.

Run from the authorized workspace root:
- `node connect-moving-tracks-c719b65b/set-valued-tracking-0554/tests/measure-set.mjs orange`
- Repeat with `legacy`, `fragmented`, `holdout`.
- `node connect-moving-tracks-c719b65b/set-valued-tracking-0554/tests/set-correspondence.test.mjs`

Requires the frozen replay source and authorized private saved inputs/crops. Two full new source files, two tests/scripts, baseline review copies, source-only patch, summary, README and manifest are bundled. The source files deliberately import the frozen sibling replay code; relocating them requires preserving that reviewed dependency rather than silently using current production. No ROM, video, raw pixels, masks, game assets, emulator state or credentials are included.

Remaining limit: the same computational budget cannot fully reverse-check all feasible forward alternatives. Increasing that budget or changing search order for this known case was not used. A later continuation would need independently justified exact search reuse/pruning or a separately approved work-allocation method, preserving uncertainty and the fixed failures.

# Isolated video/ROM camera-body alternative

Task1f8dd07f-f151-4347-aa4b-484311bdbd01. Reference main77fa730b09e7132c6a8fdf1476e2f96f494d5a86, with the supplied parent-production-input-correction-0415/web renderer. Source hashes are in CURRENT_RENDERER_MANIFEST.json. This work uses actual retained video pixels, ROM assets and saved video/ROM inverse hypotheses only. No DST, emulator session, native-memory operand or privileged pose/root/camera truth was read or used.

## Result

Three isolated implementation files are ready for review, not production admission:

1. web/monster-camera-body-alternative.mjs adds a separate camera-conditioned body alternative. It does not replace the thumbnail prediction or use that prediction as a veto.
2. web/monster-native-extent-evidence.mjs adds known-pixel spatial-support rank to existing source ownership metadata. No renderer, pixels, scores or old extent fields are changed.
3. web/tracking-camera-body-alternative.mjs joins an alternative to exact per-frame/map/camera enc table/species pairs and produces an optional conditional singleton branch for the existing AT compiler.

Five actual fixed-frame cases were rerendered with the same current source code:125 residuals,803 evaluated body proposals, and446 candidate/branch pairs with no retained best proposal. Every successful current gain equals its saved counterpart. The446 unavailable proposals were not rerendered and are not reported as current renderer failures. They remain explicit missing alternatives.

Only c28 residual12 obtains the new camera-aware z019b alternative. Other tested regions receive no new alternative. The original1200s z061c prediction remains unchanged. Existing4200s z038a false predictions and3300s failures also remain unchanged. This is neither a general false-positive repair nor a claim that body recognition is complete.

## The concrete domain mismatch

At c28 video170.312s, viewed actual pixels show the orange monster in residual12. The frozen appearance ranking prefers z019b. The normalized45-degree thumbnail body fit instead prefers z064a, so the existing conditional-body prediction remains null. The current consumer derives automatic singleton events only from that legacy prediction; the already computed, camera-aware source-GX comparison is advisory and cannot supply its own optional AT branch.

The new path keeps the two evidence domains separate. It requires an independently frame-bound ROM/video body comparison, every retained camera branch, every expected model's evaluated complete ownership, a unique positive best-tested body per branch, and agreement with the unique appearance preference. It joins the winning model to each branch's encounter source. Unsearched poses, other source states, party, UI, background error, other spawn routes and no-event remain possible. No learned or hand-fitted score threshold is added: positive means improvement over that branch's frozen background-only SSE.

This condition is a conservative candidate rule for evaluation, not an identity proof or a calibrated detector. Fixed-frame success is insufficient for automatic production admission.

## Same-current-code render results

- c28:32 regions,256 current proposals,256 equal gains. Only residual12 receives z019b as a separate alternative. The visible player, UI and cloud/background regions receive no new alternative.
-1200s:22 regions,218 current proposals,2 unavailable retained proposals. No new camera alternative. Legacy residual58/z061c stays unchanged.
-4200s:10 regions,26 current proposals,24 unavailable retained proposals. No new camera alternative. Legacy z038a results25/2/34, including the known false cases, remain.
-2355s:29 regions,15 current proposals,420 unavailable retained proposals. No new alternative. Most saved candidates had no best render for their camera branch; they were not silently discarded.
-3300s:32 regions,288 current proposals,288 equal gains. No new alternative. Existing z002b results120/131 and missing/uncertain bodies remain unchanged.

The replay rerenders the saved best-tested source proposal for each available model/branch, using its previously image-derived camera, root/floor and source pose hypothesis. It is not a new exhaustive search over all current-code poses. The appearance scores are retained observations, not newly computed DINO embeddings. Thus these tests establish current source pixel-score reproducibility and candidate-rule behavior over this bounded domain, not end-to-end video inference accuracy.

## Preserved unsuccessful experiments

All are retained privately and not promoted:

1. The original64 thumbnail samples reproduce all128 c28 model/region gains exactly.
2. Substituting the saved source camera orientation in those thumbnails does not recover residual12. z019b gain falls from728812 to389915; the alternative thumbnail winner becomes z000c.
3. Replacing only thumbnail positions with same-ROM integer-emitted stored-pose positions does not fix the target. z019b gain falls to585950, and UI residual75 gains a false conditional z021a prediction. This is why a small fixed-point/float geometry discrepancy is not presented as the cause or the fix.
4. Enumerating all stored stand/run/appear frames with the four existing canonical views improves some fits but still selects z000c over z019b at residual12. No conditional predictions result in the tested32-region set. This expansion is not a production change or proof of coverage.

The ROM-only geometry diagnostic used mathematical identity transforms to compare the same source poses. Those are test inputs, not inferred camera or actor-state truth. Its maximum float/fixed discrepancy across16 quick poses is0.0523 model units; that does not explain the observed classifier failure by itself.

## Exact branch and ownership handling

The complete retained branch list comes from backgroundBranchSupport and its passingBranchCount, not whichever body jobs completed. Truncation, duplicate/unexpected branches, stale frame identities and inconsistent source domains are rejected or remain unknown.

Known non-collinear body-color pixels are required. The extent addition distinguishes empty/point/line/area support and uses only valid comparison pixels. Bounding-box width/height alone cannot make a diagonal or a two-point support set two-dimensional. Missing ownership, unknown final mixed-translucency contributions, unavailable pixels and unsupported rivals prevent a preference. Existing failure records remain attached.

Models originating in another retained map are still compared geometrically as rival alternatives; they are not removed to make a local model win. If the best-tested model lacks this branch's exact encounter origin, the branch remains unknown. Encounter aliases are joined by the existing source-backed encoder, not multiplied across every table.

## AT consumer proof

For c28 residual12, the consumer joins both retained camera branches to table30/species31 and emits a separate conditional singleton. It does not forge the legacy conditionalBodyPrediction field, and the existing legacy-only motion selection checks therefore do not silently become satisfied.

Tests through the actual compileTrackingObservations path verify:

- The existing no-event tracking-observation-unknown branch is byte-identical before/after.
- Its SHA256 remains868720d94e9280886acf0efa8ae5bced21cf6d289f08369c646f23e70412ab3d.
- An actual prior1200s z061c experiment branch is also byte-identical.
- Existing sightings, search domain and budget are unchanged.
- The new branch has one possible latent event and no event-to-event edges.
- Two repeated observations on the same tentative image track coalesce into one event, with both sighting IDs bound to that same latent event.
- Repeated append is idempotent.
- No independent draw, birth, event order, global narrowing or current-video AT state is certified; minimumProvenATCalls remains0.

One additional singleton means an additional disjunctive explanation to inspect. It is not another draw added to an existing event sequence. The compiler's broad unknown branch is retained, so the complete current-state universe is not narrowed.

## Verification

-803 current source rerenders,803 identical saved gains.
-9 malformed-input rejection guards and16 unknown-preservation guards.
-6 known-support geometry cases, including point, horizontal/vertical/diagonal line, area and unavailable pixels.
-9 AT provenance/idempotency guards.
- Actual legacy/unknown experiment preservation and repeated-track coalescing pass.

No source renderer or default thumbnail fitting/ranking code was changed. CURRENT_RENDERER_MANIFEST.json confirms byte identity of the six principal renderer/decoder files. The only existing-module delta is extent metadata. No production file, Git state, deployment, native-memory debug checkpoint or root-owned integration file was changed.

## Recommendation and limitation

Keep this isolated until root reviews the candidate semantics and consumer wiring. It supplies a principled separate source/video alternative and a tested optional AT branch, but the five-frame evaluation is too small for broad deployment claims. The remaining goals include actual missed-body recovery across clips, correct ownership under occlusion/translucency/effects, background/player rejection, video-derived pose/placement coverage and temporal association. Existing false outcomes were preserved rather than hidden.

# Original measured-video replay integration candidate

Task UUID(Python uuid4):a9f6b3fc-0633-4e10-90c0-9ce41fde64cf.
Base:126d5dfd207ce2dbf144ce196c48dd84f5ef5828, verified against its published local web blob receipt. Current protocol libfile_564b88200db481919e83f5494a793df9 was reread; no external board identity, communication or credentials were created.

Source candidate only; worker did not publish. Seven functional files plus two cache-only parents. It integrates the original replay-lane-ce87377 capture/matcher/replay, not any fair, set-valued, support-mask or extra reverse-search experiment. Existing126d production input guards, conditional-camera code, classifier and AT source remain unchanged.

## Executable connection

Normal automatic-start or native video play captures bounded actual frames while ROM background work is busy. Delayed residual boxes seed only their exact retained source frame/hash, then advance through actually retained pixels using the original clipped patch matcher and existing association gates. Missing history, correspondence failure and eviction remain unknown. Source serials are observed serials where available; an internal pair order is separate and never synthesized from microsecond PTS.

The live grayscale preview now shows current measured patch positions separately from the existing historical classification panel. A past label is attached only through an exact classification frame/proposal/ROI anchor. Both classificationPTS and positionPTS, and their ages relative to reported playback PTS, are explicit. Candidate ranks/evidence and their original timestamps are not rewritten; current classification and physical identity remain unknown, and AT/draw certification stays zero.

Mounted delayed-classification evidence showed that a strict current-seed-only join was unusable after normal seed replacement: classificationPTS0 completed with replay seedPTS0.36 and one surviving patch, but no label attachment. The approved bounded extension retains compact original frame/proposal/ROI references across actual measured-continuity handoffs. Handoffs require the real replay history/batch/target/map and the internally computed component association/ROI binding, not matching track ID or species alone. The same one-button mounted flow now transports the historical label through three such handoffs while preserving itsPTS0 source. Lost tracks, changed source/map, hash conflicts, missing history or frame eviction prune anchors. At most256 retained frame anchors ×32 references; no unbounded lineage chain or past pixel duplication.

## Two reproduced activation binding fixes

1. An early callback with unknown layout used to establish a source key with undefined layout. The next valid layout cleared the slow seed. Mounted native-play evidence before:13 captures, classifier once, seedPTS=null,0 replay steps. After:13 retained frames, seedPTS0,11 replay steps, classifier once,13/13 VideoFrame handles closed. Unknown layout records a gap; it does not establish a layout identity.
2. Callback metadata can normally switch from HTMLMediaElement.currentTime to requestVideoFrameCallback.mediaTime. Both captures can still use the same retained-VideoFrame pixel clock. A controlled provider reproduced an erroneous source reset on that switch. Capture source identity now uses source/epoch/segment/layout; the original actual pixel timestamp binding remains untouched. Source/epoch replacement still invalidates immediately, including when layout is unknown. Before/after evidence is retained.

An earlier fast capture at the samePTS/hash may lack the slow capture's observed serial/full-frame hash. Seed evidence now preserves the actual slow seed metadata separately; it does not invent a serial for the fast frame.

## Duplicate fixture and unchanged failures

The original duplicate assertion remains preserved with expected0, actual1 and exit1. Its second20×20 write overlaps eight columns of the first patch. The first differs in159/400 pixels, clipped SAD13.6325; the second is an exact400/400 match, SAD0. Forward(+14,0)/reverse(-14,0) selects that unique surviving patch. The fixture did not construct two surviving identical patches, so its tie premise is invalid. No old input/assertion was rewritten, and no threshold was changed. The separately constructed non-overlapping exact-tie test remains unresolved as required; this is not a guarantee about every ambiguous scene.

Actual saved-video full32 replay tracks are byte-identical to the original frozen lane on orange, legacy5306.5, fragmented3300 and holdout5330. Original edge-intersection behavior is preserved. Orange12 lasts through170.712 and fails170.812 while still visible. No extra-search retention result is included. Headless final times(original→candidate) were85.85→89.23ms,131.33→124.06ms,105.79→106.55ms and182.31→156.75ms. These single-run differences are noisy; no performance improvement is claimed.

## Checks

-45 existing mounted activation/latest/pause/AT-controller checks pass.
-4 original mounted fast-lane checks and the separate native-play startup regression checks pass.
-The mounted delayed-anchor run verifies the exact old classification/new position split and zero added draws, then clears it on stop.
-13 new classification-anchor checks pass, including source/hash/map/serial/ROI mutations, fake/missing handoffs, reused IDs, source loss, eviction and70 bounded reseeds.
-10 capture/resource checks pass, plus the separate callback-clock transition check.
-8 edge/binding checks pass, including all four frame edges and a real exact-tie construction.
-The preserved original replay suite has9 passes and1 retained failure.

Controlled resource tests keep4 frame slots and peak491,520 gray/mask bytes over70 steps. The default logical pixel bound remains25,460,736 bytes, excluding transient readback/canvas/hash buffers, anchor metadata and other renderer/classifier allocations. Anchor counts stay bounded and are pruned when the actual source frame leaves the ring.

## Real-browser limitation and handoff

Live browser performance is unperformed. Root's bounded localhost retry returned ERR_BLOCKED_BY_CLIENT; no alternate IP, tunnel, proxy or security bypass was used. Controlled mounted Canvas/VideoFrame tests are not actual browser/GPU readback timings.

The capture path still reads full1920×1080 RGBA(8,294,400 bytes) before sampling256×192(196,608 bytes), potentially about82.9MB/s of readbacks at10Hz. These are byte counts, not CPU/GPU or total heap measurements. One reusable canvas and one pending hash are kept; later callbacks are skipped, not queued. Sampling/hash semantics are unchanged and VideoFrame resources are closed.

ROOT_BROWSER_VALIDATION.md gives the exact candidate web root, entry, revision, formal ROM/video paths, one-button/native-play steps and expected readouts. scripts/browser-readout.js only reads DOM evidence. Root owns the verified LLVM/WASM build and browser/publication decision. The copied web/wasm directory may contain repository placeholders and is not part of this source checkpoint; use root's verified code-built WASM for a real candidate run. Do not run concurrent build.sh.

## Source checkpoint

The ZIP contains all nine full changed files, five existing-file baselines, patch, tests, read-only browser diagnostic, README/handoff instructions, source manifest and measured summaries. Pre-fix capture source and before/after failures are retained. No ROM, video, pixels, masks, game assets, emulator states, WASM binaries or credentials are bundled. The previous frozen experiment archives remain unchanged. General video tracking, species accuracy and full one-button automation remain unproved.

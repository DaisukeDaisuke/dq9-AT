# One-frame same-Canvas readback gate

Task UUID: `da2d94ae-c18c-4de8-b036-90eb1bb190cf`, generated with Python uuid.uuid4().
Isolated base: `reduce-exact-readback-044af153/web`. The prior source ZIP is unchanged, SHA256 `7dae46d59b18544d7974b30078dfcc4a9d324032a335af6ea5d8d6e51ac8df38`.
Status: implemented and controlled tests passed; actual browser execution/publication belong to parent and have not been performed by this task.

## Normal path, no extra UI

For each current source ID, epoch, timeline segment, video width/height and layout:

1. Wait for the first valid bound retained-VideoFrame capture. Unknown layout, invalid geometry or unbound pixel timing do not consume the check.
2. Draw that retained VideoFrame ONCE to the original full-size Canvas.
3. Read full pixels and run the unchanged normal sampler. Read the derived minimal rectangle from the SAME Canvas and run the exact cropped sampler. Compare every196,608 sampled byte synchronously.
4. The first captured result ALWAYS uses the original full-read sample and its single normal hash. The second sample is only temporary, never retained or hashed.
5. If all bytes match, later captures use one rectangular read each. If bytes differ or the rectangular read/sample throws, record the reason and stay on one full read per later capture. Do not re-probe that current identity.

If the first full read fails, record it, close the VideoFrame and report the existing missing-frame gap. Later frames may recover through full reads, without another probe. If a later already-checked rectangular read fails, try the original full read on the SAME Canvas, enter sticky full fallback and record why. That exceptional failure frame can perform two read attempts; ordinary frames never do.

If the derived rectangle is the full frame, use the old full path immediately, with `full-frame-rectangle-no-byte-saving` and no check. There is no benefit that warrants duplicate reads for256×192/512×384 single-screen cases.

## Invalidation, asynchronous work and bounds

Source ID, epoch, segment, width/height and layout changes invalidate the prior gate. Size/source changes invalidate immediately even if layout is currently unavailable. Explicit reset/cancel also clears the check. Only one current identity is stored; there is no dictionary of past checks.

The existing generation guard still rejects a stale pending hash. The gate itself has no promise and no queue. A stale hash cannot restore the previous gate or fill a new gate's evidence. Hash evidence is attached through the exact originating probe object, not a timestamp comparison, so a later capture with the same PTS cannot fill an earlier failed probe's hash record. Cancel does not create a second pending hash; offers remain bounded until the old hash settles.

Stored state is scalars plus source/rectangle/probe metadata. No extra source pixels, sample pixels or VideoFrames are retained. The existing one reusable Canvas and one pending selected-sample hash remain the bounds. Snapshot calls return a defensive clone.

## Initial cost

OBS1920×1080, derived rectangle961,1,958,718:

- Full read:8,294,400 bytes
- Rectangular read:2,751,376 bytes
- Initial total readback:11,045,776 bytes
- Two sampled buffers:393,216 bytes total
- Cropped sampler temporary column arrays:6,144 bytes
- Added first-probe typed-array work relative to the old full-read path:2,954,128 bytes, plus196,608 byte comparisons

These are explicit buffer/work counts. They are not measured live heap, GPU traffic or wall time. The full input is already unreachable after its sampling call returns, and actual collection timing is engine-dependent. Conservatively counting allocations before any GC, the first probe totals11,445,136 typed-array bytes, excluding the existing Canvas, VideoFrame, hash implementation and other app allocations.

Later accepted captures return2,751,376 bytes instead of8,294,400(66.83% fewer). Sticky fallback returns the original full size. No extra SHA or async verification is added. Actual Canvas timing, GPU sync, browser responsiveness and total memory remain unmeasured.

## Existing evidence/export connection

No test panel, selector or manual parameter was added. The existing COMPARISON download gains `measuredVideoCapture`. It contains mode, reason, source/geometry, minimal rectangle, read attempt counts, returned byte count and the first comparison's result, PTS, pixel timestamp, sample size, mismatch count, first mismatch byte index and selected-sample SHA when available. It contains no extra pixel array.

The existing mounted object gains a read-only `measuredCaptureSnapshot()` accessor. The ordinary UI, one-button activation, native-play activation, replay, classification and AT policies are unchanged.

Every exported probe contains the scope: one captured frame compared on the same Canvas is NOT proof for every frame, input, browser or GPU. A successful check enables this bounded optimization; it is not all-input/full-automation certification.

## Tests and retained failures

`evidence/FINAL_CHECKS.json`:19 independent test runs match expectations,18 exit0 and the preserved replay suite's known expected0/actual1 overlap assertion exits1.

-22 gate checks: first frame one draw/one hash; exact old pixels/stamps; success followed by single reads; mismatch, crop exception and malformed return fallback; initial full failure and recovery; later crop failure; source/epoch/segment changes with and without layout; size change; cancellation/reset; no-saving cases; unknown layout/unbound timing; same-PTS stale hash attribution.
-Correct-rectangle mounted native-play/automatic activation:13 retained frames,11 replay steps, classifier once. Gate reports1 full read and12 rectangle reads. Every controlled VideoFrame closes.
-Mounted deliberate rectangle mismatch: same seed preservation,13 frames,11 steps and classifier once while using full fallback. Existing download exports the mismatch and sticky reason. No extra action is needed to start it.
-Mounted delayed classification retains classificationPTS0, positionPTS0.36 and three measured seed handoffs, with zero certified draws. Stop clears the gate and tracking state.
-The previous111 synthetic ROI exactness cases,5 fixed real native buffers,1 real full frame and48 existing decoded source frames pass again. No new actual browser/Canvas observation is claimed from controlled providers.
-All unchanged original mounted mocks now recover through full fallback when their malformed crop returns are rejected. Separate rectangle-correct tests prove the actual cropped branch; ordinary mock passes alone are not claimed as that proof.
-The old overlapping duplicate failure, real sequence failures and previous ZIP remain unchanged.

## Files and integration

Production changes relative to previous readback candidate:

- `video-tracking-capture.mjs`: bounded one-frame gate, fallback, diagnostics, size invalidation.
- `map-video-comparison.mjs`: capture import version plus two small additive connections, export field and read-only accessor.
- `map-video-residual.mjs` is unchanged from the previous exact-readback candidate, included as the required code dependency.

`GATE_FROM_READBACK.patch` applies over the previous optimization. `GATE_FROM_MEASURED_REPLAY.patch` also includes that optimization when starting at frozen measured-replay source. These are NOT a claim to replace the current published4c046656 source or the parallel HUD work wholesale. Merge the narrow comparison-module hunks with those changes and retain the parent's ancestor cache updates. See INTEGRATION.md.

## Reproduce

From the shared workspace root: `node verify-capture-readback-da2d94ae/scripts/run-checks.mjs`.

Private inputs are read from the exact existing paths; no media/pixels/ROM/SAV/DST/RAM/extracted assets/models, credentials or compiled binaries are in the source checkpoint. There was no browser operation, external worker, Git publication or change to shared production files.

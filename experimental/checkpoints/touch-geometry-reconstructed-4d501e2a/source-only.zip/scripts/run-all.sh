#!/usr/bin/env bash
set -euo pipefail
D=restore-touch-geometry-4d501e2a
node "$D/scripts/prepare-oracle.mjs"
python3 "$D/scripts/rom-execution-oracle.py"
node "$D/scripts/compare-oracle.mjs"
node "$D/tests/composition-restored.test.mjs"
node "$D/scripts/replay-raster.mjs"

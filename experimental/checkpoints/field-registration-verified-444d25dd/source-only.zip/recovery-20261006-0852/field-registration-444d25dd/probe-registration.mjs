import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {MapProject,MapRenderer} from './source/web/map-core.mjs';
import {MapPositionMatcher} from './source/web/map-position.mjs';
import {deriveVideoPlayerMapInput} from './source/web/map-browser-preview/video-player-map-input.mjs';
const out=new URL('.',import.meta.url),rom=await fs.readFile(new URL('../verified/dq9_new2.nds',out)),wasm=await fs.readFile(new URL('../../integrate-capture-reseed-restored-392beab9/web/wasm/map_render.wasm',out)),{instance}=await WebAssembly.instantiate(wasm),renderer=new MapRenderer(instance),project=new MapProject(rom.buffer.slice(rom.byteOffset,rom.byteOffset+rom.byteLength),await fs.readFile(new URL('./source/web/data/map-id-names.csv',out),'utf8')),matcher=new MapPositionMatcher(instance),results=[];
for(const sec of process.argv.slice(2)){
 const rgba=await fs.readFile(new URL(`field${sec}.rgba`,out)),sourceImage={width:1920,height:1080,rgba},frameEvidence={fullRGBA_SHA256:createHash('sha256').update(rgba).digest('hex'),sourcePTS:Number(sec),source:'independent-ffmpeg-decode-not-retained-browser-frame'},maps=[];
 for(const [mapId,path]of [[7401,'D04M01.bmmp'],[7402,'D04M02.bmmp']]){
  const mapImage=renderer.compose(project,path),runs=[];
  for(const mode of ['coarse6','coarse24','dense']){
   const proxy={setReference:im=>matcher.setReference(im),match:(frame,options)=>matcher.match(frame,{...options,maxMilliseconds:1500,...(mode==='coarse24'?{coarseSeeds:24}:mode==='dense'?{denseTranslation:true}:{})})};
   const result=deriveVideoPlayerMapInput({sourceImage,layout:'obs-side-1920',mapImage,mapId,matcher:proxy,floors:{instances:[],unsupported:['floor loading intentionally omitted for registration-only probe']},frameEvidence});
   runs.push({mode,status:result.status,registration:result.registration,markerCount:result.markers.candidates.length,primary:result.primaryCandidate});
  }
  maps.push({mapId,path,runs});
  if(sec===process.argv[2]){await fs.writeFile(new URL(path+'.rgba',out),mapImage.rgba);await fs.writeFile(new URL(path+'.meta.json',out),JSON.stringify({width:mapImage.width,height:mapImage.height,originPixel:mapImage.originPixel,descriptor:mapImage.descriptor}));}
 }
 results.push({sec,frameEvidence,maps});console.log(JSON.stringify({sec,maps:maps.map(m=>({...m,runs:m.runs.map(r=>({mode:r.mode,status:r.status,resolved:r.registration.resolved,best:r.registration.best,margin:r.registration.margin,search:r.registration.search,markerCount:r.markerCount,primaryWorld:r.primary?.world}))}))}));
}
await fs.writeFile(new URL('probe-results.json',out),JSON.stringify({wasmSHA256:createHash('sha256').update(wasm).digest('hex'),romSHA256:createHash('sha256').update(rom).digest('hex'),sourceCommit:'de68aef82e31e707da2f039dce009c6865ad7c4d',results},null,2));

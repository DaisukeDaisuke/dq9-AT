# Explicit optional consumer wiring proposal

No production wiring is applied in this checkpoint.

## Source files to review

- web/monster-camera-body-alternative.mjs (new)
- web/tracking-camera-body-alternative.mjs (new)
- web/monster-native-extent-evidence.mjs (two additive ownership metadata fields)

## Producer placement

Potential existing integration point: web/map-browser-preview/residual-native-support.mjs, inside attachResidualNativeSupport after the frozen region's source groups and existing appearance rows have been checked.

Construct sourceBranches from that region's original result.groups[].bundle.branches, retaining each group's exact frame/record key and renderer. Pass the full original backgroundBranchSupport, not only completed/explored branches. expectedModelIds must come from the complete per-region appearance/enc plan domain. Run compareCameraBodyAlternative with the unchanged rankings and legacy prediction. Store a distinct sighting.cameraBodyAlternative alongside conditionalBodyPrediction. Do not overwrite the latter, selectedModelId, existing rankings, body masks, unknown flags or AT counts.

Every resumable native update must recompute the comparison against its own complete frozen branch set. Missing branches remain unknown; a later better-tested proposal may change the provisional alternative. Existing source/frame/ROM cancellation guards remain mandatory. Do not borrow a prior frame's camera or a later frame's map plan.

The completed bundle is already emitted by map-video-comparison.mjs through acceptNative and the same onObservationBundle callback. No browser state, manual parameter entry or memory-derived source is needed.

## AT placement

Potential existing integration point: web/map-browser-preview/video-tracking-at.mjs, after deriveTrackingEventEvidence(snapshot), before its no-single-events waiting check and before options.singleEvents is assigned.

Collect the new comparisons with their exact sighting IDs. Call deriveCameraBodySingletonAlternatives(snapshot,{alternatives}). Then call appendCameraBodySingletonAlternatives(automatic.singleEvents,addition). Pass the returned union to the existing singleton compiler. Keep the original automatic evidence and camera-derived evidence in separate named fields, with a fresh fingerprint/revision if admitted. Do not synthesize an old conditionalBodyPrediction or mapCompatibility object for the new route.

The consumer independently binds each comparison to its own sighting/video/ROM/frame, every retained map/camera branch, model aliases, own-frame model plan and exact enc table/species relation. Repeated observations on one tentative track union predicates into one conditional latent singleton. Other tracks are separate alternative branches, never intersected as independent draws.

Retain compileTrackingObservations' tracking-observation-unknown branch unchanged. No new chain, edge, bounded event-to-observation gap, known seed, known origin or hard current-state constraint is created. The actual compiler tests verify that existing experiment branches, domain, budget and unknown branch remain byte-identical while only the new conditional branch is appended.

## Motion boundary

No change to tracking-at-session.mjs is proposed. Its existing endpoint gate requires legacy conditionalBodyPrediction provenance and must continue to reject these new source alternatives until a separate exact-frame/camera/enc-aware motion adapter is implemented and validated. Do not fake that field merely to make an endpoint link pass.

## Scope

This is a candidate implementation and wiring proposal, not authority to enable it automatically. The new candidate remains explicitly conditional, keeps player/background/unknown/no-event alternatives and does not certify species identity, complete body ownership, a birth, an extra draw, event order or current AT recovery.

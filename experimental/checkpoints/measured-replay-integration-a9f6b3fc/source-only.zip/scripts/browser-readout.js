// Read-only browser diagnostic. Run through the approved browser tool after
// normal ROM/video selection and one start/play action. No parameters set.
(() => {
 const $=id=>document.getElementById(id), parse=x=>{try{return JSON.parse(x??'null');}catch{return null;}}, status=$('residual-tracking-status'), video=$('comparison-video');
 return {
  page:location.href,
  entryRevision:document.querySelector('script[src*="preview.mjs"]')?.getAttribute('src')??null,
  replayRevision:status?.dataset.measuredReplayRevision??null,
  playback:{currentTime:video?.currentTime??null,paused:video?.paused??null,readyState:video?.readyState??null,width:video?.videoWidth??null,height:video?.videoHeight??null},
  selectedFiles:{rom:Array.from($('rom')?.files??[],f=>({name:f.name,bytes:f.size})),video:Array.from($('comparison-file')?.files??[],f=>({name:f.name,bytes:f.size}))},
  status:{pipeline:$('video-timeline-status')?.textContent??null,background:$('auto-search-status')?.textContent??null,classification:$('residual-classification-status')?.textContent??null,AT:$('video-at-status')?.textContent??null},
  measuredReplay:parse(status?.dataset.measuredVideoTracking),
  measuredClassificationView:parse(status?.dataset.measuredClassificationView),
  visibleMeasuredPreview:Boolean($('measured-video-tracking-preview')&&!$('measured-video-tracking-preview').hidden),
  scope:'DOM readout only. No source PTS, map, pose, seed or game state is supplied by this diagnostic.'
 };
})()

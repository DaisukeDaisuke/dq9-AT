# Mode1 source-decoding reuse: measured minimal implementation

Execution UUID: aa33472f-1093-4342-93b2-072ec8e3a12d, supplied by the parent after Python UUID generation.
Baseline: published runtime fd0fd5836b7a300cbe70a6d91ec7812f263f35d2, using the exact `integrate-field-registration-444d25dd/web` source snapshot. The later main source-ZIP-only commit is not treated as another runtime implementation.

## Result

On the original monster-present long2355 saved ROM/video input, full mode1 photometric preparation has a median of 255.326455 ms before and 118.128374 ms after, a 53.7344% reduction (12 alternating-order paired measurements after two warmups for each side).

This is a preparation measurement. It is not an end-to-end browser frame-rate result, a WebGPU execution benchmark, an all-input claim, or evidence that monster identity / automatic AT search is complete.

## Minimal production change

Only `web/map-browser-preview/integer/initial-mode1-integer-preview.mjs` changes:

- Create the existing `createSourcePreparationCache` once per inventory.
- Supply it to the existing two `readNativeBinaryPolygonTexture` call sites.
- Dispose it in `finally`, including generator return and cancellation.

The existing cache rechecks source bytes before shape/alpha hits, bypasses shared/resizable buffers, validates data properties, has existing object/byte limits, and is discarded per preparation. No cross-frame cache, changed raster arithmetic, replaced source data, new threshold, branch omission, model parameter, alternative-selection rule, or unknown-status change is introduced. The renderer archive wrapper is not replaced and the cache's optional archive wrapper is not used here.

## Profiling and verification

The unmodified first long2355 measurement was 289.68 ms preparation, 539.35 ms CPU basis, 443.65 ms CPU weights, and 66.25 ms inference. A second baseline pass with V8 CPU profiling measured preparation at 301.73 ms. Its hot source functions included repeated `readNativeBinaryPolygonTexture`, `decodePackedGx`, and `collectInitialMode1IntegerInputsSteps`; the per-polygon texture calls had no source cache even though mode2 already used one. CPU raster work remained a separate large cost. The final paired numbers above were measured without CPU profiling.

`evidence/VERIFICATION.json` records all three unchanged long2355 saved camera branches:

- Deep strict equality of the complete prepared model, including ordinary states, inventories, typed arrays, source data, and rejection metadata.
- Exact equality of all packed GPU job words and ledgers; only the nondeterministic preparation-duration field is excluded.
- Deep strict equality of the full CPU basis and weight outputs, including RGBA, depth, ownership, known masks, and fog flags.
- Exact inference scores, four alternatives, margins, readiness, selected index, and uncertainty. All three branches retain source color index 2.
- Matching AbortError name/message and yield count at five deterministic cancellation boundaries: 0, 1, 3, 30, 200.

The initial profiling attempts on long1200 and long3300 correctly failed the mode1 gate because these cases use mode2; they were not changed or converted into mode1 successes. The auxiliary saved c28 case retained its insufficient-discrimination failure, with exact basis/weights and result equality; it is not the optimization target. The first c28 harness attempt failed because an analysis-video metadata object lacked RGBA; the second explicitly used its existing nativeVideo pixels. That first harness failure remains in the private evidence. Neither the c28 failure nor old Library evidence is promoted into a current production defect.

All private baseline/candidate pixel-bearing profiling evidence remains local outside the source checkpoint. No ROM/video/DST/RAM bytes are included in this ZIP. No historical captures were edited.

## Files and reproduction

- `web/.../initial-mode1-integer-preview.mjs`: replacement production source.
- `PATCH.diff`: exact production diff.
- `MANIFEST.json`: baseline and replacement hashes.
- `scripts/verify-and-benchmark.mjs`: the measured three-branch equivalence, cancellation, and paired timing harness.
- `scripts/profile-baseline.mjs` and `scripts/profile-candidate.mjs`: the bounded profiling harnesses.
- `evidence/VERIFICATION.json` and logs: non-pixel verification/timing evidence.

The local full source copies are under `reduce-background-latency-aa33472f/baseline/web` and `candidate/web`. Run from the workspace root:

    node reduce-background-latency-aa33472f/scripts/verify-and-benchmark.mjs

The harness requires the already approved formal ROM and unchanged saved captures at their existing recovery paths. A clean checkpoint consumer should reconstruct the before/after web trees from the exact baseline and verify `MANIFEST.json` before applying the replacement. No build, deployment, Git operation, browser operation, or Library write was performed. The parent owns integration, cache invalidation on publication, and an actual browser measurement.

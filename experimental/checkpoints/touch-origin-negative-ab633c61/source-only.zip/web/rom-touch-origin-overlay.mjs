// 隔離検証専用。ROM と映像以外の状態入力を禁止する。メモリ由来の位置や姿勢を使用しない。
// Ordinary touch-origin overlay hypothesis, never a player/world-position oracle.
const need=(v,m)=>{if(!v)throw Error(m);};
const u16=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint16(p,true);
const u32=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p,true);
const range=(b,p,n)=>need(Number.isSafeInteger(p)&&p>=0&&Number.isSafeInteger(n)&&n>=0&&p+n<=b.length,'SPR range outside resource');
export const sha256=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');
const ownedSources=new WeakMap();
const CODE_BINDINGS=[{"image":"sdk","address":34177620,"length":156,"sha256":"f6909fb246d42e7c2158f1ed16be28ea13bdb15cc6f7bad7d2ab75861f0d175e","purpose":"Four arrow SPR loader"},{"image":"sdk","address":33851544,"length":184,"sha256":"d896377049dd678789320e8102eb7a58c28cdc8f5d162e0facb27b34e5a49013","purpose":"SPR path formatter"},{"image":"sdk","address":33851744,"length":916,"sha256":"461049c5382d56535ef6ed41e38b82d821bd17a2a0e21e0c9a08b1e9aa605d27","purpose":"SPR payload loader"},{"image":"sdk","address":33849276,"length":148,"sha256":"c75b636c831017ac27f197be7b08a60917d13a385a62e88323b16ce871a562a3","purpose":"Sprite unit scale/RGB/alpha defaults"},{"image":"sdk","address":34177840,"length":320,"sha256":"3f4af147e8c5f1464b4bdd13597a42d8536ee07d2f83406c5c1179ce21685503","purpose":"Touch-origin/current coordinate update"},{"image":"sdk","address":34178164,"length":128,"sha256":"54ecbf52455148742d0f8d86762eb9c7cc8a26f95b2ec677778b9d1e913c61b0","purpose":"Conditional overlay call"},{"image":"sdk","address":34179208,"length":832,"sha256":"ccb9cc275a164e3e8261749b3e73873e908001ccc101e8ca492f92a1a5ed4e1b","purpose":"Ring/shaft/head/dot source transform"},{"image":"sdk","address":33849832,"length":128,"sha256":"ba5d7ee6dc6f25803a03d35026d48a42f9594fb02f14a4fa5aa6421f29673678","purpose":"Uncentered sprite draw wrapper"},{"image":"sdk","address":33850228,"length":244,"sha256":"2426ee6549c301f09942cc009c86c00635b0812c8b8ba0017d0107ccb5677f54","purpose":"SPR top-left draw transform"},{"image":"sdk","address":33850680,"length":420,"sha256":"c1207025b1c35055777b2a43926a7a56b0a2c91380bd603ebc1efbc076d3531a","purpose":"GX sprite quad/texture/alpha"},{"image":"field","address":35220656,"length":692,"sha256":"22554cc866c3a6d258fe5b7fe7638df5c5d5ea1cbfd593c5393d2c5539b750fa","purpose":"Orthographic field UI subpass and touch draw"},{"image":"field","address":35242908,"length":16,"sha256":"8b3ba88147594388732b28b449f0d28685fc30b989686304bd00954e933a1b12","purpose":"Field source constructor call"}];
function ascii(reader,address){let s='';for(let i=0;i<256;i++){const b=reader.read(address+i,1)[0];if(!b)return s;need(b>=32&&b<127,'Unsupported source string');s+=String.fromCharCode(b);}throw Error('Unterminated source string');}
function immediate(word){need((word&0x02000000)!==0,'Expected source ARM immediate');const q=word&255,r=((word>>>8)&15)*2;return ((q>>>r)|(q<<(32-r)))>>>0;}
export function decodeSPRImages(bytes){
 need(bytes instanceof Uint8Array,'SPR bytes required');range(bytes,0,4);const imageCount=u16(bytes,0),format=u16(bytes,2);need(imageCount>0&&format===3,'Only source format3 (4bpp) supported');
 const images=[];let at=4;
 for(let i=0;i<imageCount;i++){
  range(bytes,at,8);const width=u16(bytes,at),height=u16(bytes,at+2),pieces=u32(bytes,at+4);at+=8;
  need(width>0&&width<=255&&height>0&&height<=255&&pieces>0&&pieces<=255,'Unsupported source image dimensions/piece count');const parts=[];
  for(let j=0;j<pieces;j++){
   range(bytes,at,8);const x=u16(bytes,at),y=u16(bytes,at+2),wx=u16(bytes,at+4),hy=u16(bytes,at+6);at+=8;need(wx<=7&&hy<=7,'Texture exponent outside NDS format');const w=8<<wx,h=8<<hy,size=w*h/2;
   need(x+w<=width&&y+h<=height,'Clipped or padded SPR piece requires source draw implementation');range(bytes,at,size);parts.push({x,y,w,h,offset:at,bytes:bytes.slice(at,at+size)});at+=size;
  }images.push({width,height,parts});
 }
 range(bytes,at,4);const paletteCount=u32(bytes,at);at+=4;need(paletteCount>=1&&paletteCount<=16,'Unsupported source4bpp palette');range(bytes,at,paletteCount*2);const palette=Array.from({length:paletteCount},(_,i)=>u16(bytes,at+i*2));// NDS paletted RGB555 ignores palette bit15; alpha is texture index0.
 const paletteOffset=at;at+=paletteCount*2;
 const frames=images.map(({width,height,parts})=>{const rgba=new Uint8ClampedArray(width*height*4),coverage=new Uint8Array(width*height);for(const part of parts)for(let p=0;p<part.w*part.h;p++){const value=(part.bytes[p>>>1]>>>((p&1)*4))&15;need(value<palette.length,'SPR palette index outside resource');const x=part.x+p%part.w,y=part.y+Math.floor(p/part.w),i=y*width+x;need(!coverage[i],'Overlapping SPR pieces require source depth/ordering');coverage[i]=1;if(!value)continue;const color=palette[value];for(let c=0;c<3;c++){const q=(color>>>(c*5))&31;rgba[i*4+c]=(q<<3)|(q>>>2);}rgba[i*4+3]=255;}return{width,height,rgba,parts:parts.map(({bytes,...x})=>x)};});
 return{format,imageCount,frames,paletteCount,paletteOffset,decodedPixelDataEnd:at,uninterpretedTrailingBytes:bytes.length-at,scope:'Image/piece/palette payload only; animation footer not executed.'};
}


export async function loadRomTouchOriginOverlay({romSHA256,nfs,sdk,fieldOverlay}){
 need(/^[a-f0-9]{64}$/.test(romSHA256??'')&&nfs?.readFile&&sdk?.read&&fieldOverlay?.read&&fieldOverlay.id===17,'Bound ROM, SDK and overlay17 required');
 for(const b of CODE_BINDINGS)need(await sha256((b.image==='sdk'?sdk:fieldOverlay).read(b.address,b.length))===b.sha256,'Unsupported touch-overlay source code: '+b.purpose);
 const sw=a=>u32(sdk.read(a,4),0),fw=a=>u32(fieldOverlay.read(a,4),0),pathFormat=ascii(sdk,sw(0x0204894c)),nameFormat=ascii(sdk,sw(0x020982ec)),count=immediate(sw(0x020982a8));
 need(pathFormat==='/data/ani/%s'&&nameFormat==='arrow%d.spr'&&count===4,'Unsupported source arrow resource domain');
 const sprites=[];for(let i=0;i<count;i++){const path=pathFormat.replace('%s',nameFormat.replace('%d',String(i))).replace(/^\//,''),bytes=new Uint8Array(nfs.readFile(path)),d=decodeSPRImages(bytes);need(d.imageCount===1&&d.frames[0].parts.length===1,'Only single-image, single-piece source arrows admitted');sprites.push({index:i,path,sha256:await sha256(bytes),byteLength:bytes.length,...d.frames[0],footer:{bytes:d.uninterpretedTrailingBytes,executed:false}});}
 const ringOffset=-immediate(sw(0x02098a58))/4096,dotOffset=-immediate(sw(0x02098b88))/4096,ring=sprites[0],dot=sprites[3],dx=dotOffset-ringOffset,dy=dx;
 need(Number.isInteger(dx)&&dx>=0&&dx+dot.width<=ring.width&&dy+dot.height<=ring.height,'Source dot lies outside ring canvas');
 const rgba=ring.rgba.slice();for(let y=0;y<dot.height;y++)for(let x=0;x<dot.width;x++){const s=(y*dot.width+x)*4;if(dot.rgba[s+3]===255)rgba.set(dot.rgba.subarray(s,s+4),((y+dy)*ring.width+x+dx)*4);}
 const source={schema:'dq9-rom-touch-origin-source-v1',romSHA256,width:ring.width,height:ring.height,rgba,sourceSprites:sprites.map(({rgba,parts,...s})=>s),sourceCode:structuredClone(CODE_BINDINGS),viewport:{width:immediate(fw(0x02196d3c))/4096,height:immediate(fw(0x02196d34))/4096},transform:{ringOffset:{x:ringOffset,y:ringOffset},dotOffset:{x:dotOffset,y:dotOffset},input:'screen touch-origin bytes; current visibility unresolved',locationPrior:false},semantics:{textureFormat:3,paletteRGBBits:15,transparentIndex:0,defaultAlpha:31,defaultModulation:32767,supported:'Unrotated unit-size ring plus later dot only',unknown:['shaft/head overdraw','source visibility guards','capture sampling and photometry','occlusion and other later draws'],pixelOwnershipVerified:false,safeForHardPruning:false},scope:'Conditional screen-space overlay explanation. Not a player position, complete UI renderer, body identity or AT constraint.'};
 const meta=JSON.stringify({...source,rgba:undefined}),rgbaHash=await sha256(rgba);ownedSources.set(source,{meta,rgbaHash,source:structuredClone(source)});return source;
}
export async function snapshotTouchOriginSource(source){const owned=ownedSources.get(source);need(owned&&JSON.stringify({...source,rgba:undefined})===owned.meta&&await sha256(source.rgba)===owned.rgbaHash,'Unknown or mutated touch-overlay source');return structuredClone(owned.source);}

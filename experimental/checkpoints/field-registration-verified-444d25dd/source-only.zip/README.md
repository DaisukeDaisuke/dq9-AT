# Field registration source and fixed evidence backup

This immutable backup supplements FIELD_REGISTRATION_PUBLICATION_SOURCE_444d25dd.zip. That publication ZIP contains only the 15-file delta intended for the repository. This archive also retains every authored field-registration probe/verification driver, the initial four-file checkpoint, original baseline registration source, full numerical observations, manifests, and completed build/test receipts.

## Evidence boundaries

The actual-video observations use nine independently decoded frames from the formal 1ninn.mkv. They are not identical to saved browser Canvas pixels. Six field samples and three battle samples were used; there was no BODY711/END845 joining. Numerical reports preserve coarse failures, competing registration candidates, multiple floor-height alternatives, and unknown actor/AT claims. No full automation or all-input coverage is asserted.

No ROM, media, raw/encoded image, minimap descriptor extraction, model/texture/palette asset, compiled WASM, or compiler binary is included. Names ending in `pixels` inside the numerical reports are counts or uncertainty measurements, not pixel arrays.

## Original inputs and source binding

Baseline repository revision: de68aef82e31e707da2f039dce009c6865ad7c4d.
ROM SHA256: 3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7.
Compiled map_render.wasm used and independently rebuilt: f8ca0020d83d360fb247e53f856029457e28e2ff0484900106e5a4e9dbf5bafe.
Existing matcher source wasm/map_position.c SHA256: a6af8689e524d50942685cb011412f53cabbf4decff270e3939488414547a4f6.

Source files and drivers preserve their original relative workspace paths. Required external inputs remain absent intentionally. The baseline probe ran before the four-file source fix; its `./source/web` imports therefore refer to the baseline revision at that time. To reproduce that baseline pass, restore that revision under its source directory first. Then overlay the retained initial four-file checkpoint before running verify-final-registration.mjs. For verify-integrated-registration.mjs, materialize the capture/reseed stage plus the retained 15-file publication delta under integrate-field-registration-444d25dd. No driver was rewritten after its recorded run.

The archived probe-registration.mjs includes the original optional reference-image diagnostic writes; those generated assets are excluded from this archive. The final two verification drivers write numerical measurements only. The probe and verification programs use specific map candidates only for this bounded diagnostic comparison; no such map IDs or known coordinates were added to production source.

## Original independent frame extraction

For each requested second 764.329, 767.462, 770.129, 773.346, 800, 802.796, 755.246, 840, and 845.012, the original extraction command was:

    ffmpeg -nostdin -hide_banner -loglevel error -ss "$sec" -i recovery-20261006-0852/videos-59dd27c3/full/1ninn.mkv -frames:v 1 -pix_fmt rgba -f rawvideo recovery-20261006-0852/field-registration-444d25dd/field$sec.rgba

The first 764.329 extraction used the equivalent field764.rgba output name and was then renamed field764.329.rgba. Full decoded-frame SHA256 values appear in the measurement reports. Requested seek seconds are not claimed as verified retained-browser PTS.

## Validation status

No tests, builds, or measurement runs were repeated to create this backup. VALIDATION_RECEIPT.json describes the completed integrated build and prior fixed measurements. Publication verification belongs to the separate publishing operation and is not claimed here.

# Narrow parent integration

The current published4c046656 tree and parallel HUD copy were not edited. This candidate starts from the previous isolated exact-readback tree, so do not overwrite their whole map-video-comparison file.

1. Retain the exact-readback sampler dependency, unchanged SHA256 `5e8e4d1c00a3c6cd457d71a1def16241d4a7ffb17576f18bd86c88c6878a3a55`.
2. Integrate new video-tracking-capture.mjs.
3. In map-video-comparison.mjs change its capture import version to `same-canvas-readback-20261006-0817`.
4. Add `measuredVideoCapture:fastCapture.snapshot()` alongside existing `measuredVideoTracking` in the COMPARISON JSON export.
5. Add `measuredCaptureSnapshot:()=>fastCapture.snapshot()` alongside existing `measuredTrackingSnapshot` in the returned mounted object.
6. Update ancestor cache versions through the parent's normal publication process. No other UI insertion is needed.

There is no new input, button or test mode. In an actual browser run, use the existing formal file selections and normal automatic button/native play. Download the existing comparison JSON and inspect measuredVideoCapture:

- Success: mode=cropped, verification.result=match, comparedBytes=196608, differentBytes=0, firstMismatchByte=null. Full read count remains1 while crop count advances. First sample hash belongs to the checked frame's retained VideoFrame timestamp; later frames need not share it.
- Mismatch or exception: mode=full with a reason. Counts show the one probe and then only full reads. The first valid returned image remains the original full-read image.
- No benefit: mode=full, reason=full-frame-rectangle-no-byte-saving, verification=null.
- Source/epoch/segment/size/layout change or stop/cancel: old verification is gone. Another valid capture may start a new bounded check.

Read counters are attempts; returnedReadbackBytes counts data actually returned by getImageData. A later crop failure can make one exceptional crop+full retry before sticking to full mode. The verification record is historical evidence for one same-Canvas frame only, never an all-frame pixel guarantee.

Actual browser execution, measured GPU/Canvas cost and publication remain parent responsibilities. The checkpoint's mounted evidence is controlled and must not be presented as an actual browser run.

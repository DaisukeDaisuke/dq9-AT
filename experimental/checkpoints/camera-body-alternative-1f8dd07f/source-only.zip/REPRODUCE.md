# Local reproduction

Run from the shared workspace root. Private source/video fixtures and the formal ROM remain local; no private bytes belong in the source archive or Git.

1. Copy the supplied current web tree to this task's runtime directory. Apply the three web/*.mjs candidate files only there.
2. For each of c28,long1200,long4200,long2355,long3300, run:
   node correct-video-body-proposal-1f8dd07f/scripts/rerender-camera-alternatives.mjs FIXTURE_ID
3. Run node correct-video-body-proposal-1f8dd07f/scripts/summarize-current-alternatives.mjs.
4. Run node correct-video-body-proposal-1f8dd07f/tests/test-camera-body-alternative.mjs.
5. Run node correct-video-body-proposal-1f8dd07f/tests/test-camera-at-consumer.mjs.

Earlier negative diagnostic scripts remain in scripts/:replay-thumbnail-fit.mjs,compare-source-geometry.mjs,replay-quantized-thumbnail.mjs,replay-all-stored.mjs. They are diagnostic only and do not constitute proposed renderer/ranking changes. Their fixed fixture paths and finite domains are explicit in their source.

Current renderer hashes are recorded in CURRENT_RENDERER_MANIFEST.json. The old source-native debug adapter is a separate inactive debug-only task and is neither imported nor used here.

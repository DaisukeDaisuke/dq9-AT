// Experimental single-seed shadow. Source-owned coverage is a conditional
// renderer hypothesis, not measured video membership or a new segmentation.
import{unpackBackgroundMask}from'./background-branch-support.mjs';
import{videoTrackingFrameKey}from'./video-patch-correspondence.mjs';
import{correspondVideoComponent}from'./video-component-correspondence.mjs';
const W=256,N=W*192,sha=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),x=>x.toString(16).padStart(2,'0')).join(''),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const uncertified={identityCertified:false,bodyExtentCertified:false,currentSegmentationKnown:false,currentVideoMembershipCertified:false,birthCertified:false,absenceCertified:false,minimumProvenATCalls:0};
export async function prepareVideoOwnedFootprintSupport(input,{maximumSamples=1024}={}){
 if(!Number.isSafeInteger(maximumSamples)||maximumSamples<1)throw Error('Positive support work budget required');
 // Own all bytes/metadata before digest yields, so asynchronous mutation cannot
 // attach a verified mask to a different recipe or source frame.
 const {stamp,image,body,hypothesis:h,mask,knownMask}=structuredClone(input),no=reason=>({ready:false,reason,...uncertified});
 const video=body?.source?.video,bg=body?.source?.background,pts=stamp?.mediaTime??stamp?.videoTime;
 if(!video||!h?.ready||!['sourceId','sourceEpoch','timelineSegment','fullRGBA_SHA256','gameplayRGBA_SHA256'].every(k=>video[k]!==undefined&&video[k]===stamp?.[k])||video.mediaTime!==pts)return no('owned-support-source-frame-differs');
 if(image?.width!==256||image?.height!==192||image.rgba?.length!==N*4||await sha(image.rgba)!==stamp.gameplayRGBA_SHA256)return no('owned-support-source-pixels-differ');
 const expectedFrame={romSHA256:bg.romSHA256,recordKey:h.recordKey,...Object.fromEntries(['sourceId','sourceEpoch','timelineSegment','mediaTime','fullRGBA_SHA256'].map(k=>[k,video[k]]))};
 if(!Object.keys(expectedFrame).every(k=>expectedFrame[k]!==undefined&&expectedFrame[k]===h.frame?.[k]))return no('owned-support-render-frame-differs');
 const branches=bg.backgroundBranchSupport?.branches?.filter(b=>b.branchId===h.branchId&&b.recordKey===h.recordKey&&b.romSHA256===bg.romSHA256&&b.fullRGBA_SHA256===video.fullRGBA_SHA256);
 if(branches?.length!==1||!same(branches[0].alignment,h.alignment))return no('owned-support-camera-branch-differs');
 const sight=body.sightings?.find(s=>s.originalProposalId===String(h.originalResidualId)),best=sight?.classificationEvidence?.[0]?.rankings?.find(r=>r.modelId===h.modelId)?.sourceNativeSupport?.branches?.find(b=>b.branchId===h.branchId&&b.recordKey===h.recordKey)?.best,extent=best?.nativeBodyExtent?.bodyColorOwnership;
 if(!best||best.proposalId!==h.proposalId||!same(best.pose,h.pose)||!same(best.positionFx,h.positionFx)||best.fit?.pixelErrorReduction!==h.savedGain)return no('owned-support-original-hypothesis-differs');
 if(h.sourceAcceptedSubset!=='isolated-opaque-binary-body-polygons'||h.sceneOcclusionApplied!==false||h.ownershipKind!=='isolated-source-opaque-binary-body-coverage')return no('owned-support-render-subset-unavailable');
 if(!(mask instanceof Uint8Array)||!(knownMask instanceof Uint8Array)||mask.length!==N||knownMask.length!==N||mask.some(v=>v!==0&&v!==1)||knownMask.some(v=>v!==0&&v!==1)||await sha(mask)!==h.maskSHA256||await sha(knownMask)!==h.knownMaskSHA256)return no('owned-support-mask-binding-differs');
 const valid=unpackBackgroundMask(branches[0].knownMask),indices=[];let count=0,x0=256,y0=192,x1=-1,y1=-1;
 for(let i=0;i<N;i++){if(knownMask[i]!==Number(Boolean(mask[i]&&valid[i])))return no('owned-support-known-intersection-differs');if(mask[i]){count++;x0=Math.min(x0,i%W);x1=Math.max(x1,i%W);y0=Math.min(y0,Math.floor(i/W));y1=Math.max(y1,Math.floor(i/W));}if(knownMask[i])indices.push(i);}
 const roi=count?{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}:null;
 if(!extent||!same(roi,h.roi)||!same(roi,extent.roi)||count!==h.pixels||count!==extent.pixels||indices.length!==h.knownPixels||indices.length!==extent.knownPixels||h.outsideFramePixels!==extent.outsideFramePixels)return no('owned-support-original-extent-differs');
 if(!roi)return no('owned-support-empty');const stride=Math.ceil(indices.length/maximumSamples)||1,points=Uint16Array.from(indices.filter((_,i)=>i%stride===0).map(i=>(Math.floor(i/W)-roi.y)*W+(i%W-roi.x)));
 return{ready:true,kind:'conditional-source-owned-footprint-support-v1',sourceFrameKey:videoTrackingFrameKey(stamp),sourcePTS:pts,romSHA256:bg.romSHA256,recordKey:h.recordKey,branchId:h.branchId,modelId:h.modelId,proposalId:h.proposalId,originalResidualId:h.originalResidualId,pose:h.pose,positionFx:h.positionFx,alignment:h.alignment,roi,pixels:count,knownPixels:indices.length,outsideFramePixels:h.outsideFramePixels,maskSHA256:h.maskSHA256,knownMaskSHA256:h.knownMaskSHA256,points,sampledPoints:points.length,samplingStride:stride,maximumSamples,sceneOcclusionApplied:false,...uncertified};
}
/** Bounded single-hypothesis chain for shadow use. A failed/missing pair ends
 * the chain. Another seed needs a new instance; there is no mask replenishment. */
export function createOwnedFootprintCorrespondence(template,{trackId}={}){
 if(!template?.ready||!(template.points instanceof Uint16Array)||typeof trackId!=='string')throw Error('Verified source footprint and seed track required');
 const t=structuredClone(template);let points=t.points,expected=t.sourceFrameKey,roi=t.roi,stopped=false;
 return(previous,current,actualROI,meta={})=>{
  const fail=reason=>{stopped=true;return{ready:false,reason,...uncertified};};
  if(stopped)return fail('owned-support-chain-stopped');
  if(meta.trackId!==trackId||previous.key!==expected||previous.key!==videoTrackingFrameKey(previous.stamp)||current.key!==videoTrackingFrameKey(current.stamp)||!same(roi,actualROI))return fail('owned-support-chain-binding-differs');
  const r=correspondVideoComponent(previous,current,actualROI,{supportPoints:points,maximumSamples:t.maximumSamples});
  if(r.ready){points=r.retainedSupportPoints.slice();expected=current.key;roi=structuredClone(r.roi);}else stopped=true;
  return{...r,kind:'tentative-bidirectional-prior-owned-footprint-correspondence',hypothesis:{modelId:t.modelId,branchId:t.branchId,proposalId:t.proposalId,sourceFrameKey:t.sourceFrameKey,maskSHA256:t.maskSHA256},...(r.supportPolicy?{supportPolicy:{...r.supportPolicy,kind:'transported-prior-conditional-source-ownership',sceneOcclusionApplied:false}}:{}),...uncertified};
 };
}

# Exact quantized residual connected-component topology; not a threshold choice.
import json,base64,hashlib
import numpy as np
from scipy.ndimage import label,find_objects
from pathlib import Path
root=Path('correct-false-body-4200-63c7feaa');cmp=json.loads(Path('inspect-map-video-publication-20261005/BROWSER_LONG4200_COMPARISON_df40cb.json').read_text());s=cmp['background']['backgroundBranchSupport'];b=next(b for b in s['branches'] if b['rowIndex']==s['selectedPreviewRowIndex']);bg=np.frombuffer(base64.b64decode(b['alignedBackgroundRGBA']['data']),np.uint8).reshape(192,256,4);v=np.array(cmp['nativeVideo']['rgba']).reshape(192,256,4);valid=bg[:,:,3]==255;res=np.floor(abs(v[:,:,:3].astype(int)-bg[:,:,:3].astype(int)).sum(2)/3+.5);cut=cmp['stats']['residualThreshold'];seeds,num=label((res>cut)&valid);assert num==len(cmp['components']);rows=[];prev=None
for cut in range(cut,-1,-1):
 labels,n=label((res>cut)&valid);island=labels[seeds==26][0];ys,xs=np.where(labels==island);ids=sorted(set(int(x)-1 for x in seeds[labels==island] if x));key=tuple(ids)
 if key!=prev:rows.append({'cut':cut,'seedIds':ids,'roi':{'x':int(xs.min()),'y':int(ys.min()),'w':int(xs.max()-xs.min()+1),'h':int(ys.max()-ys.min()+1)},'activePixels':len(xs)});prev=key
out={'rows':rows,'scope':'All exact 4-neighbour topology changes for residual25. No selected cut or claimed body grouping.'};(root/'evidence/RESIDUAL_TOPOLOGY_4200.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

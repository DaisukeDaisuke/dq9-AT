import fs from'node:fs';
export function fixture(){
 const original=JSON.parse(fs.readFileSync('inspect-map-video-publication-20261005/BROWSER_1NINN_AUTOPLAY_BODY_c28bcdf.json')),comparison=JSON.parse(fs.readFileSync('inspect-map-video-publication-20261005/BROWSER_1NINN_AUTOPLAY_COMPARISON_c28bcdf.json')),fresh=JSON.parse(fs.readFileSync('correct-video-body-proposal-1f8dd07f/evidence/CURRENT_CAMERA_c28.json'));
 const appearance={...original,videoObservations:[],worldAssociations:[],sightings:original.sightings.map(s=>({...s,classificationEvidence:s.classificationEvidence.map(e=>({...e,rankings:e.rankings.map(({sourceNativeSupport,...r})=>r)}))}))};
 const input={regionIds:fresh.rows.map(r=>r.regionId),regions:comparison.components,videoEvidence:appearance.source.video,backgroundEvidence:appearance.source.background};
 const result={kind:'automatic-source-native-body-support',budgetStopped:false,regions:fresh.rows.map(row=>{const groups=[];for(const branch of row.sourceBranches){let group=groups.find(g=>g.frame.recordKey===branch.frame.recordKey);if(!group){group={frame:branch.frame,branchIds:[],bundle:{kind:'per-candidate-source-native-body-support',renderer:branch.renderer,frame:branch.frame,branches:[]}};groups.push(group);}group.branchIds.push(branch.branchId);group.bundle.branches.push(branch);}return{regionId:row.regionId,groups};})};
 return{appearance,input,result};
}

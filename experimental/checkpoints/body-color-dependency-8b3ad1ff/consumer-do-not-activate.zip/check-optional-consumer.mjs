import fs from 'node:fs';import assert from 'node:assert/strict';
import {compareCameraBodyAlternative as newCompare} from './optional-consumer/web/monster-camera-body-alternative.mjs';
import {compareCameraBodyAlternative as oldCompare} from '../integrate-geometry-display-75457234/web/monster-camera-body-alternative.mjs';
const root=new URL('../',import.meta.url),here=new URL('./',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,root))),newBest=read('track-body-contributions-8b3ad1ff/evidence/PRIVATE_REPLAYED_BEST.json'),rows=[],mutationInputs=[];
for(const label of ['1215','MOVING']){
 const body=read(`observe-restored-long-video-0930/INTEGRATED_a0bf_${label}_BODY.json`),support=body.source.background.backgroundBranchSupport,appearanceFrame={...support.frame,romSHA256:body.source.background.romSHA256},expectedModelIds=body.source.modelPlan.models.map(m=>m.modelId);
 for(const sighting of body.sightings){
  const rankings=sighting.classificationEvidence[0].rankings,sourceBranches=support.branches.map(saved=>({branchId:saved.branchId,renderer:'source-integer-original-GX-body-subset',frame:{...appearanceFrame,recordKey:saved.recordKey},candidates:rankings.map(r=>{const b=r.sourceNativeSupport.branches.find(b=>b.branchId===saved.branchId);return{modelId:r.modelId,testedProposals:b.testedProposals??0,best:b.best??null,unsupported:b.unsupported??[],candidateSource:b.candidateSource??null};})})),input={appearanceFrame,rankings,legacyPrediction:sighting.conditionalBodyPrediction,backgroundBranchSupport:support,sourceBranches,expectedModelIds};
  const before=oldCompare(input);assert.deepEqual(newCompare(input),before,'Unannotated composition and all legacy paths unchanged');
  for(const b of sourceBranches)for(const c of b.candidates){const r=newBest.find(r=>r.label===label&&r.regionId===sighting.originalProposalId&&r.modelId===c.modelId&&r.branchId===b.branchId);if(r)c.best=r.best;}
  const after=newCompare(input);assert.deepEqual(after.legacyPrediction,before.legacyPrediction);assert.equal(after.minimumProvenATCalls,0);assert.equal(after.identityCertified,false);const row={label,regionId:sighting.originalProposalId,roi:body.rawRegions.find(r=>String(r.id)===sighting.originalProposalId).roi,appearance:after.appearanceModelId,oldSupported:before.supportedModelId,newSupported:after.supportedModelId,branches:after.branches.map(b=>({status:b.status,bestTestedModelId:b.bestTestedModelId,reasons:b.reasons,candidates:b.candidates.map(c=>({modelId:c.modelId,ready:c.ready,gain:c.pixelErrorReduction,reasons:c.reasons,dependencyPixels:c.bodyColorDependency?.pixels??null}))}))};rows.push(row);if(sourceBranches.some(b=>b.candidates.some(c=>c.best?.nativeBodyExtent?.bodyColorDependency?.pixels>0)))mutationInputs.push(structuredClone(input));
 }
}
const input=mutationInputs[0],source=input.sourceBranches[0],index=source.candidates.findIndex(c=>c.best?.nativeBodyExtent?.bodyColorDependency?.pixels>0),target=source.candidates[index];assert(newCompare(input).branches[0].candidates.find(c=>c.modelId===target.modelId).ready);
const mutations=[
 c=>delete c.best.nativeBodyExtent.bodyColorDependency,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.fixedAcceptanceTrace=false,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.integerBlendAndFogQuantizationIncluded=false,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.displayProfile='rgb666-expanded',
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.bodyRGBInputDomain=[0,255],
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.camera.viewFx[0]++,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.frame.mediaTime++,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.alignment.dx++,
 c=>c.best.nativeBodyExtent.bodyColorDependency.capability.bodyRemovalDifferenceCertified=true,
 c=>c.best.nativeBodyExtent.bodyColorDependency.knownSpatialSupportRank=1,
 c=>c.best.nativeBodyExtent.bodyColorDependency.knownBodySpatiallyDegenerate=true,
 c=>c.best.nativeBodyExtent.bodyColorDependency.knownPixels--,
 c=>c.best.nativeBodyExtent.bodyColorDependency.unavailablePixels=1,
 c=>c.best.nativeBodyExtent.bodyColorDependency.outsideFramePixels=1,
 c=>c.best.nativeBodyExtent.bodyColorDependency.roi.x=-1,
 c=>c.best.nativeBodyExtent.bodyColorDependency.preFogRGB6Extent.pixels=0,
 c=>c.best.nativeBodyExtent.bodyColorDependency.observedBodyCertified=true,
 c=>c.best.sceneComposition.partialBodyNotScored=true,
 c=>c.best.sceneComposition.stats.unknownOrderPixels=1,
 c=>c.best.sceneComposition.stats.unknownDestinationPixels=1,
 c=>c.best.sceneComposition.stats.opaqueDepthTiePixels=1,
 c=>c.best.sceneComposition.sourceOrder.kind='unknown',
 c=>c.best.sceneComposition.binding.camera.viewFx[0]++,
 c=>c.best.sceneComposition.binding.frame.mediaTime++,
 c=>c.best.fit.unavailableBodyPixels=1,
 c=>c.best.fit.bodyPixels++,
 c=>c.best.fit.pixelErrorReduction++,
 c=>c.best.nativeBodyExtent.identityCertified=true,
 c=>c.testedProposals=0,
];
for(const mutate of mutations){const a=structuredClone(input);mutate(a.sourceBranches[0].candidates[index]);assert.equal(newCompare(a).branches[0].candidates.find(c=>c.modelId===target.modelId).ready,false);}
const report={passed:true,consumerActivationApproved:false,currentFrameComparisons:rows.length,unannotatedOutputsExact:true,mutationsRejected:mutations.length,rows};fs.writeFileSync(new URL('evidence/OPTIONAL_CONSUMER_CONTROLS.json',here),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:true,regions:rows.length,mutations:mutations.length,positives:rows.filter(r=>r.newSupported),UI:rows.filter(r=>r.regionId==='1')},null,2));

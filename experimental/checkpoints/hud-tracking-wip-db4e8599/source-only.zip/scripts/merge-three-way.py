from pathlib import Path
import re,json
r=Path('merge-hud-measured-tracking-db4e8599');s=(r/'private-evidence/THREE_WAY_RAW.mjs').read_text();rx=r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n';out=[]
def resolve(m):
 a,b,c=m.groups();item={'index':len(out),'leftLines':len(a.splitlines()),'baseLines':len(b.splitlines()),'rightLines':len(c.splitlines())};out.append(item)
 if a.startswith('import{measuredClassificationView}'):item['resolution']='Both import sets';return a+c
 if a.startswith('export function mountMapVideoComparison'):item['resolution']='Keep tracking view and state; add HUD argument/state';return a.replace('mountMapVideoComparison({renderBackground,','mountMapVideoComparison({conditionalHud=null,renderBackground,').replace('let latestTracking=null;','let latestTracking=null;let hudWork=null;')
 if a.startswith(' function cancelClassifications'):item['resolution']='Keep tracking view reset; add independent HUD cancellation/preparation';return a+'\n'.join(c.splitlines()[1:])+'\n'
 if a.startswith(' const pump='):item['resolution']='Await HUD queue on full analysis only; preserve fastCapture stop cancellation';return a.replace('if(comparison?.components?.length)queueClassification();','if(comparison?.components?.length)await queueClassification();')
 if a.lstrip().startswith('const measuredContinuity='):item['resolution']='Keep raw measured continuity and raw seed; launch HUD after original record';return a.replace("comparisonRecord=record;$('comparison-details')", "comparisonRecord=record;void prepareHudFrame(frozen,background,comparison);$('comparison-details')")
 raise Exception('Unexpected conflict')
merged=re.sub(rx,resolve,s,flags=re.M|re.S);assert len(out)==5;assert not any(mark in merged for mark in ['<<<<<<<','|||||||','>>>>>>>']);(r/'web/map-browser-preview/map-video-comparison.mjs').write_text(merged)
(r/'MERGE_RESOLUTION.json').write_text(json.dumps({'common':'126d5dfd207ce2dbf144ce196c48dd84f5ef5828','mechanism':'GNU diff3, explicit five conflict resolutions','conflicts':out},indent=2)+'\n')

// Separate component-tree grouping hypotheses from one frozen residual field.
// No threshold selection, distance merge, body identity, replacement or AT event.
const need=(x,m)=>{if(!x)throw Error(m);};
export function residualComponentTreeAlternatives({width,height,residualLevels,validMask,originalThreshold,originalRegions,frame,backgroundFrame,getCurrentFrame}){
 const n=width*height;need(Number.isInteger(width)&&Number.isInteger(height)&&width>0&&height>0&&n<=49152,'Bounded native frame required');
 need(residualLevels instanceof Uint8Array&&residualLevels.length===n&&validMask instanceof Uint8Array&&validMask.length===n&&validMask.every(x=>x===0||x===1),'Matching integer residual field and known mask required');
 need(Number.isInteger(originalThreshold)&&originalThreshold>=0&&originalThreshold<=255&&Array.isArray(originalRegions),'Original residual split and complete raw components required');
 need(/^[a-f0-9]{64}$/.test(frame?.romSHA256??'')&&/^[a-f0-9]{64}$/.test(frame?.fullRGBA_SHA256??'')&&typeof frame.sourceId==='string'&&Number.isInteger(frame.sourceEpoch)&&Number.isInteger(frame.timelineSegment)&&Number.isFinite(frame.mediaTime)&&typeof frame.recordKey==='string'&&typeof frame.branchId==='string','Frozen video/ROM/background branch identity required');
 const frameKeys=['romSHA256','fullRGBA_SHA256','sourceId','sourceEpoch','timelineSegment','mediaTime','recordKey','branchId'],sameFrame=f=>frameKeys.every(k=>f?.[k]===frame[k]);need(sameFrame(backgroundFrame)&&typeof getCurrentFrame==='function','Same-frame background and current-source guard required');const guard=()=>{if(!sameFrame(getCurrentFrame()))throw new DOMException('Residual tree source changed','AbortError');};guard();
 const queue=new Int32Array(n),originalLabels=new Int32Array(n).fill(-1);
 function components(cut,withSeeds){const seen=new Uint8Array(n),rows=[];for(let start=0;start<n;start++){
  if(seen[start]||!validMask[start]||residualLevels[start]<=cut)continue;let head=0,tail=1,x0=width,x1=-1,y0=height,y1=-1;const seeds=new Set();queue[0]=start;seen[start]=1;
  while(head<tail){const i=queue[head++],x=i%width,y=Math.floor(i/width);x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);if(withSeeds&&originalLabels[i]>=0)seeds.add(originalLabels[i]);else if(!withSeeds)originalLabels[i]=rows.length;
   for(const j of[x?i-1:-1,x+1<width?i+1:-1,y?i-width:-1,y+1<height?i+width:-1])if(j>=0&&!seen[j]&&validMask[j]&&residualLevels[j]>cut){seen[j]=1;queue[tail++]=j;}
  }
  rows.push({id:rows.length,roi:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1},pixels:tail,seedIds:[...seeds].sort((a,b)=>a-b)});
 }return rows;}
 const original=components(originalThreshold,false),byId=new Map(originalRegions.map(r=>[r.id,r]));need(byId.size===originalRegions.length&&original.length===originalRegions.length,'Complete distinct original component domain required');
 for(const r of original){const saved=byId.get(r.id);need(saved&&saved.pixels===r.pixels&&['x','y','w','h'].every(k=>saved.roi?.[k]===r.roi[k]),'Original components differ from frozen residual pixels');}
 const groups=[],keys=new Map();for(let cut=originalThreshold-1;cut>=0;cut--){guard();for(const r of components(cut,true)){
  if(r.seedIds.length<2)continue;const key=r.seedIds.join(',');if(keys.has(key))continue;
  const childGroupIds=groups.filter(g=>g.originalResidualIds.every(id=>r.seedIds.includes(id))&&!groups.some(h=>h!==g&&h.originalResidualIds.length>g.originalResidualIds.length&&h.originalResidualIds.every(id=>r.seedIds.includes(id))&&g.originalResidualIds.every(id=>h.originalResidualIds.includes(id)))).map(g=>g.id);
  const row={id:'residual-merge:'+key,kind:'conditional-residual-component-tree-group',roi:r.roi,pixels:r.pixels,originalResidualIds:r.seedIds,mergeThreshold:cut,childGroupIds,frame:structuredClone(frame),bodyCertified:false,groupMembershipCertified:false,speciesKnown:false,identityCertified:false,minimumProvenATCalls:0,noEventPossible:true,unknownNonEnemyPossible:true,playerPossible:true,backgroundErrorPossible:true,scope:'First connected residual superlevel containing this exact set of original components. Weak residual/background pixels may connect different objects; grouping is only a competing proposal.'};groups.push(row);keys.set(key,row.id);
 }}guard();
 return{kind:'residual-component-tree-alternatives-v1',frame:structuredClone(frame),originalThreshold,originalRegions:structuredClone(originalRegions),groups,originalComponentsReplaced:false,allMergeSetsBelowOriginalThresholdEnumerated:true,allSpatialExtentsEnumerated:false,independentDrawsAdded:0,minimumProvenATCalls:0,unknownAlternativeRetained:true,scope:'Every distinct original-component merge set below the unchanged data-derived split. Only the first extent per merge set is emitted. No selected grouping, new cutoff, species decision, exclusion or complete body-domain claim.'};
}

// Separate compute admission only. The raw-component request queue is untouched.
// A caller-supplied budget cannot turn uncomputed groups into negative evidence.
export function budgetResidualMergeAlternatives(tree,{maxGroups}){
 need(tree?.kind==='residual-component-tree-alternatives-v1'&&tree.originalComponentsReplaced===false&&tree.unknownAlternativeRetained===true&&Array.isArray(tree.groups),'Complete component-tree alternative result required');
 need(Number.isSafeInteger(maxGroups)&&maxGroups>=0&&maxGroups<=49152,'Explicit bounded optional group budget required');
 need(new Set(tree.groups.map(g=>g.id)).size===tree.groups.length&&tree.groups.every(g=>g.kind==='conditional-residual-component-tree-group'&&g.groupMembershipCertified===false&&g.minimumProvenATCalls===0&&g.noEventPossible===true),'Distinct provisional merge domain required');
 const requested=tree.groups.slice(0,maxGroups).map(g=>structuredClone(g)),uncomputed=tree.groups.slice(maxGroups).map(g=>({id:g.id,originalResidualIds:g.originalResidualIds.slice(),roi:{...g.roi},frame:structuredClone(g.frame),reason:'Not evaluated: explicit optional group budget',unknownAlternativeRetained:true,noEventPossible:true}));
 return{kind:'bounded-residual-merge-request-plan-v1',frame:structuredClone(tree.frame),maxGroups,fullGroupDomain:tree.groups.map(g=>g.id),requested,uncomputed,ordering:'Descending residual merge level, then source pixel scan order; no score/species sorting',originalComponentQueueChanged:false,modelClassificationsComplete:false,groupMembershipCertified:false,independentDrawsAdded:0,unknownAlternativeRetained:true};
}

// A single candidate-independent comparison domain for the whole source frame.
// Missing observed background pixels remain outside the computed domain.
const need=(x,message)=>{if(!x)throw Error(message);},domains=new WeakMap();
export function buildCommonObservedDomain(background){
 need(background?.schema==='dq9-local-no-overlay-background-rival-v1'&&background.valid.length===background.width*background.height&&background.errors.length===background.valid.length,'Full-frame background rival required');
 let pixelCount=0,baselineErrorSum=0;
 for(let i=0;i<background.valid.length;i++)if(background.valid[i]){
  const e=background.errors[i];need(Number.isFinite(e)&&e>=0&&e<=1,'Invalid observed background error');pixelCount++;baselineErrorSum+=e;
 }
 need(pixelCount>0&&pixelCount===background.observedPixels,'Empty or inconsistent observed domain');
 const result={schema:'dq9-common-observed-frame-domain-v1',width:background.width,height:background.height,pixelCount,
  uncomputedPixels:background.valid.length-pixelCount,baselineErrorSum,baselineMeanError:baselineErrorSum/pixelCount,
  kind:'All observed source-radius background pixels in the complete native frame, independent of candidate support',relativeNoOverlayScore:0};
 domains.set(result,{background,snapshot:JSON.stringify(result)});return result;
}
export function compareCompositionOnCommonDomain(domain,background,{sourceErrorSum,coveredBackgroundErrorSum,sourceSupportPixels}){
 const owned=domains.get(domain);need(owned&&owned.background===background&&owned.snapshot===JSON.stringify(domain),'Unbound or changed common domain');
 need(Number.isInteger(sourceSupportPixels)&&sourceSupportPixels>0&&sourceSupportPixels<=domain.pixelCount&&Number.isFinite(sourceErrorSum)&&sourceErrorSum>=0&&Number.isFinite(coveredBackgroundErrorSum)&&coveredBackgroundErrorSum>=0&&coveredBackgroundErrorSum<=domain.baselineErrorSum+1e-9,'Invalid source-support error totals');
 const unexplainedOutsideSourceErrorSum=Math.max(0,domain.baselineErrorSum-coveredBackgroundErrorSum),candidateErrorSum=unexplainedOutsideSourceErrorSum+sourceErrorSum,
  improvementSum=coveredBackgroundErrorSum-sourceErrorSum;
 return{score:improvementSum/domain.pixelCount,commonDomainPixels:domain.pixelCount,sourceSupportPixels,
  noOverlayDomainMeanError:domain.baselineMeanError,candidateDomainMeanError:candidateErrorSum/domain.pixelCount,
  unexplainedOutsideSourceErrorSum,improvementSum,backgroundReferenceScore:0,
  scope:'Every candidate and no-overlay are compared on the same observed full-frame domain. Outside candidate source support, the background error remains; score is not a probability.'};
}

import{projectNativeBodyDestinationHandoff}from'./native-body-destination-handoff.mjs?v=native-yaw-mse-20261006-2101';
// Transport projection only. The owner keeps full original search/comparison
// evidence. Include every branch/model; never rank/filter from a transport limit.
const pick=(value,keys)=>value?Object.fromEntries(keys.map(k=>[k,value[k]])):null;
const frame=value=>pick(value,['sourceId','sourceEpoch','timelineSegment','frameSerial','mediaTime','videoTime','fullRGBA_SHA256']);
const fog=value=>pick(value,['parameters','source','timeIndependent','discreteOrdinaryHypothesis']);
const environment=value=>value?{fogApplied:value.fogApplied,fog:fog(value.fog),mode1:value.mode1??null,mode2Inputs:value.mode2Inputs??null}:null;
export function nativeBodyRequestPayload(request){
 const bg=request.backgroundEvidence,support=bg?.backgroundBranchSupport,hasBranches=support?.ready===true&&Array.isArray(support.branches),backgroundEvidence={romSHA256:bg?.romSHA256,recordKey:bg?.recordKey};
 // Preserve the producer count verbatim: deriving it from surviving rows would
 // hide truncated/mismatched domains and erase the continuation guard.
 if(hasBranches)backgroundEvidence.backgroundBranchSupport={ready:true,kind:support.kind,frame:frame(support.frame),passingBranchCount:support.passingBranchCount,branches:support.branches.map(b=>({branchId:b.branchId,recordKey:b.recordKey,mapId:b.mapId,romSHA256:b.romSHA256,fullRGBA_SHA256:b.fullRGBA_SHA256,viewFx:b.viewFx,projectionFx:b.projectionFx,alignment:b.alignment,alignedBackgroundRGBA:b.alignedBackgroundRGBA,alignedBackgroundRGBA_SHA256:b.alignedBackgroundRGBA_SHA256,knownMask:b.knownMask,sourceEnvironment:environment(b.sourceEnvironment),...reuse(b,support.frame,bg.romSHA256)}))};
 else{const search=bg?.automaticSearch,index=search?.selectedIndex??0,selected=search?.backgroundCandidates?.[index],mode2=selected?.mode2Inference?.automaticMode2;backgroundEvidence.mapId=bg?.mapId;backgroundEvidence.viewFx=bg?.viewFx;backgroundEvidence.projectionFx=bg?.projectionFx;backgroundEvidence.fogApplied=bg?.fogApplied;backgroundEvidence.rendererEvidence={integer:{fog:fog(bg?.rendererEvidence?.integer?.fog)}};backgroundEvidence.automaticSearch={acceptedCount:search?.acceptedCount,inputFrame:frame(search?.inputFrame),selectedIndex:0,backgroundCandidates:mode2?[{mode2Inference:{automaticMode2:{photometry:{inputs:mode2.photometry?.inputs}}}}]:[]};}
 const comparison=hasBranches?null:request.nativeComparison,hints=request.appearancePoseHints;
 return{continuationToken:request.continuationToken,videoEvidence:frame(request.videoEvidence),backgroundEvidence,nativeVideo:pick(request.nativeVideo,['width','height','rgba']),nativeComparison:hasBranches?null:comparison?{alignedBackground:comparison.alignedBackground,validMask:comparison.validMask,alignment:{applied:comparison.alignment?.applied}}:null,regions:request.regions?.map(r=>pick(r,['id','roi','kind','minimumProvenATCalls'])),candidates:request.candidates?.map(c=>pick(c,['modelId','variant','origins','matchedSpeciesIds'])),variant:request.variant,appearancePoseHints:hints?{romSHA256:hints.romSHA256,frame:frame(hints.frame),regions:hints.regions?.map(r=>({regionId:r.regionId,candidates:r.candidates?.map(c=>({modelId:c.modelId,bestPose:pick(c.bestPose,['clip','frame','variant','yaw','pitch'])}))}))}:undefined};
}

function reuse(branch,frame,romSHA256){const envelope=projectNativeBodyDestinationHandoff(branch,{frame,romSHA256});return envelope?{nativeBodyDestinationReuse:envelope}:{};}

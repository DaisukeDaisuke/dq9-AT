import assert from'node:assert/strict';import fs from'node:fs';
import{buildLocalBackgroundRival,backgroundErrorAt,jointContrastScore}from'../web/local-background-rival.mjs';
import{scoreExactJointRaster}from'../web/joint-touch-search-core.mjs';
let assertions=0;const eq=(a,b)=>{assert.deepEqual(a,b);assertions++;},bad=(f,re)=>{assert.throws(f,re);assertions++;};
const W=32,H=24,make=kind=>({width:W,height:H,rgba:Uint8ClampedArray.from({length:W*H*4},(_,i)=>{if(i%4===3)return 255;const x=Math.floor(i/4)%W,y=Math.floor(Math.floor(i/4)/W);return kind==='constant'?[80,160,240][i%4]:20+x+2*y+(i%4)*17;})});
for(const kind of['constant','affine']){const image=make(kind),before=image.rgba.slice(),b=buildLocalBackgroundRival(image,3);eq(b.observedPixels,(W-6)*(H-6));eq(b.uncomputedPixels,W*H-b.observedPixels);eq([...b.errors].every(e=>e===0),true);eq(image.rgba,before);eq(backgroundErrorAt(b,0,0),null);eq(backgroundErrorAt(b,16,12),0);eq(b.relativeReferenceScore,0);}
const image=make('constant');image.rgba[(12*W+16)*4]=255;const b=buildLocalBackgroundRival(image,3);eq(backgroundErrorAt(b,16,12)>0,true);
eq(jointContrastScore([0,0,0,0],[1,1,1,1]),1);eq(jointContrastScore([1,1,1,1],[0,0,0,0]),-1);eq(jointContrastScore([0,0],[0,0]),0);eq(jointContrastScore([.2,.2,.2,.2],[.1,.1,.1,.1]),-.1);
bad(()=>jointContrastScore([0],[0]),/Normalized/);bad(()=>jointContrastScore([NaN,0],[0,0]),/Normalized/);bad(()=>buildLocalBackgroundRival(image,0),/radius/);
const rgba=new Uint8ClampedArray(image.rgba.length),owner=new Int32Array(W*H).fill(-1);for(let role=0;role<4;role++){const i=12*W+12+role;rgba.set(image.rgba.subarray(i*4,i*4+4),i*4);owner[i]=role;}
const raster={isolatedRasterReady:true,width:W,height:H,rgba,owner};const r=scoreExactJointRaster(image,raster,{backgroundModel:b});eq(r.complete,true);eq(r.roleErrors,[0,0,0,0]);eq(r.roleCounts,[1,1,1,1]);eq(r.backgroundReferenceScore,0);
owner[12*W+15]=0;eq(scoreExactJointRaster(image,raster,{backgroundModel:b}).complete,false);owner[12*W+15]=3;
bad(()=>scoreExactJointRaster(image,raster),/background/);
const blank=make('constant');blank.rgba[(12*W+19)*4+3]=0;const bb=buildLocalBackgroundRival(blank,3);eq(backgroundErrorAt(bb,16,12),null);
fs.writeFileSync('derive-touch-common-domain-ad3e0e26/evidence/BACKGROUND_RIVAL_TESTS.json',JSON.stringify({assertions,constantAndAffineBackgroundPredictedExactly:true,incompletePerimetersRetained:true,scope:'Local-rival arithmetic and exact-role scoring mechanics only'},null,2));console.log({assertions});

// ROM-dependent bounded verification. Never run before restored producer approval.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {openMapRom} from '../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/static-scene.mjs';
import {readArm9Overlay} from '../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/rom-overlay.mjs';
import {loadTouchOverlayComposition,produceTouchOverlayPolygons} from '../web/rom-touch-overlay-composition.mjs';
import {rasterTouchOverlayValidation} from '../web/rom-touch-overlay-raster.mjs';
import {loadJointTouchVideoSource,registerJointTouchVideoCandidates,snapshotJointCandidateRaster} from '../web/rom-touch-video-candidates.mjs';
const root='derive-video-touch-d55dc6f9/',hash=b=>crypto.createHash('sha256').update(b).digest('hex');
let assertions=0;const eq=(a,b)=>{assert.deepEqual(a,b);assertions++;};
const bad=(fn,re)=>{assert.throws(fn,re);assertions++;};const reject=async(fn,re)=>{await assert.rejects(fn,re);assertions++;};
const rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds');
eq(hash(rom),'3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7');
const opts={...openMapRom(rom),romSHA256:hash(rom),fieldOverlay:readArm9Overlay(rom,17)};
const composition=await loadTouchOverlayComposition(opts),source=await loadJointTouchVideoSource(opts);
const validation={schema:'dq9-touch-vector-validation-candidate-v1',provenance:'synthetic-source-validation',origin:[64,48],endpoint:[96,80]};
const geometry=produceTouchOverlayPolygons(composition,validation);
eq(geometry.sourceValidationOnly,true);
bad(()=>produceTouchOverlayPolygons(composition,{schema:'dq9-touch-vector-video-candidate-v1',provenance:'automatic-full-scene-video-search',origin:[64,48],endpoint:[96,80]}),/unbound/);
bad(()=>rasterTouchOverlayValidation(composition,geometry,{profile:'isolated-video-candidate-native1x-Z-pre-fog'}),/provenance/);
const cases=[{origin:[64,48],endpoint:[96,80],background:'flat'},{origin:[151,83],endpoint:[91,35],background:'procedural'}];
const evaluations=[];
let saved=null;
for(let id=0;id<cases.length;id++) {
  const c=cases[id],g=produceTouchOverlayPolygons(composition,{...validation,origin:c.origin,endpoint:c.endpoint});
  const raster=rasterTouchOverlayValidation(composition,g,{profile:'isolated-source-validation-native1x-Z-pre-fog'});
  eq(raster.isolatedRasterReady,true);
  const rgba=Uint8ClampedArray.from({length:256*192*4},(_,i)=>i%4===3?255:c.background==='flat'?48:(Math.floor(i/4)*17+(i%4)*41)%256);
  for(let i=0;i<256*192;i++) if(raster.rgba[i*4+3])rgba.set(raster.rgba.subarray(i*4,i*4+4),i*4);
  const image={width:256,height:192,rgba},frame={romSHA256:opts.romSHA256,sourceId:'generated-source-mechanics',sourceEpoch:0,timelineSegment:0,mediaTime:id,nativeRGBA_SHA256:hash(rgba)};
  const start=performance.now(),r=await registerJointTouchVideoCandidates(source,image,{frame});
  const exactRank=r.candidates.findIndex(p=>JSON.stringify(p.candidate.origin)===JSON.stringify(c.origin)&&JSON.stringify(p.candidate.endpoint)===JSON.stringify(c.endpoint));
  evaluations.push({id,...c,exactRank,top:r.candidates[0]?{origin:r.candidates[0].candidate.origin,endpoint:r.candidates[0].candidate.endpoint,score:r.candidates[0].exact.score}:null,
    elapsedSeconds:(performance.now()-start)/1000,statistics:r.statistics});
  // Localization observations remain data, not assertions silently rewritten to pass.
  eq(r.admitted,false);eq(r.threshold,null);eq(r.excludedPixels,0);eq(r.unknownAlternatives.some(x=>x.kind==='absent-overlay'),true);
  eq(hash(image.rgba),frame.nativeRGBA_SHA256);eq(r.candidates.every(p=>p.admitted===false&&p.safeForHardPruning===false),true);
  saved={image,frame,r};
  fs.writeFileSync(root+'private-evidence/SYNTHETIC_'+id+'.json',JSON.stringify({evaluation:evaluations.at(-1),registration:r},null,2));
}
const {image,frame,r}=saved;
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,playerPosition:[0,0]}),/Unexpected/);
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame:{...frame,nativeRGBA_SHA256:'0'.repeat(64)}}),/pixels differ/);
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame:{...frame,sourceEpoch:-1}}),/binding/);
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,getCurrentFrame:()=>({...frame,sourceEpoch:1})}),/stale/);
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,signal:{aborted:true}}),/Cancelled/);
await reject(()=>registerJointTouchVideoCandidates(structuredClone(source),image,{frame}),/Unknown/);
source.viewport.width++;await reject(()=>registerJointTouchVideoCandidates(source,image,{frame}),/mutated/);source.viewport.width--;
await reject(()=>snapshotJointCandidateRaster(source,structuredClone(r),0,image,frame),/unbound/);
await reject(()=>snapshotJointCandidateRaster(source,r,0,image,{...frame,mediaTime:99}),/unbound/);
if(r.candidates.length){r.candidates[0].candidate.origin[0]++;await reject(()=>snapshotJointCandidateRaster(source,r,0,image,frame),/unbound/);r.candidates[0].candidate.origin[0]--;
  const repeated=await snapshotJointCandidateRaster(source,r,0,image,frame);eq(repeated.isolatedRasterReady,true);}
let calls=0;
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,getCurrentFrame:()=>++calls>40?({...frame,sourceEpoch:1}):frame}),/stale/);
calls=0;const priorPixel=image.rgba[0];
await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,getCurrentFrame:()=>{if(++calls===40)image.rgba[0]^=1;return frame;}}),/pixels changed/);image.rgba[0]=priorPixel;
calls=0;await reject(()=>registerJointTouchVideoCandidates(source,image,{frame,getCurrentFrame:()=>{if(++calls===40)source.viewport.width++;return frame;}}),/mutated/);source.viewport.width--;
if(r.candidates.length){await reject(()=>snapshotJointCandidateRaster(source,r,-1,image,frame),/index/);
  image.rgba[0]^=1;await reject(()=>snapshotJointCandidateRaster(source,r,0,image,frame),/pixels/);image.rgba[0]^=1;}
const summary={assertions,evaluations,scope:'Two source-native generated full scenes and binding mechanics; not capture/native framebuffer parity, exhaustive input coverage or detection calibration',
 threshold:null,unknownAlternativesRetained:true,productionFilesTouched:false};
fs.writeFileSync(root+'evidence/ROM_VIDEO_TESTS.json',JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));

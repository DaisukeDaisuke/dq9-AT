# Capture gate and reseed runtime publication stage

This is an unpublished, source-only runtime candidate based on de68aef82e31e707da2f039dce009c6865ad7c4d. That checkout has the same runtime baseline as 4c0466568e9716a9ee4ddffe0075709d6fcc2ef3.

## Scope

Four functional files implement bounded rectangular readback guarded by a first-frame, same-Canvas full-versus-cropped byte comparison; target-frame measured-history ordering before reseed; and cancellation of old pending work when decoded video dimensions change. The 15 other publication files change only cache query versions. All 39 affected import edges, including normal and GPU entry points, use capture-gate-reseed-20261006-0850.

No HUD logic, matcher thresholds, production input requirements, or DST/RAM paths change. Display/CSS size does not count as decoded input size. The gate uses existing observation callbacks and adds no manual parameter input.

PUBLISH_FILES.json is the exact 19-file source allowlist with SHA256 and Git blob SHA1. UPLOAD_PATHS.json is the minimal upload list. Generated WASM, extracted assets, media, pixels, private input files, and toolchain files are excluded. PUBLICATION.patch is the corresponding diff against the recovered baseline.

## Recovery provenance

The original 115-entry integration ZIP and the first validated publication stage were lost during a workspace replacement. All four functional source files were reconstructed from saved source checkpoints and match their retained pre-loss SHA256 values exactly. Their code was then overlaid into this new stage and import versions revised. This is a new archive; it does not claim the lost ZIP's hash or identity.

The first pre-loss stage completed build.sh and all 32 expected regression outcomes. Those logs are no longer available; this candidate uses newly rerun validation, separately identified in VALIDATION_RECEIPT.json.

## Completed validation

The standard scripts/build.sh was rerun with Debian Clang/LLD 19.1.7 from the restored toolchain. It exited 0, including 50 direct Node test invocations and the standard build/verification steps. All 17 changed JavaScript modules pass node --check. Four functional sources match the original recovered source after normalizing import query versions; all 15 remaining files are cache-query-only changes. The baseline was verified unchanged before the root subsequently staged authorized publication edits in its own checkout. This task did not modify that checkout.

Fifteen unchanged saved-checkpoint regression processes were rerun against the final cache-revised source. Fourteen passed. The original overlapping-duplicate fixture retains its known exit 1 and exact failure (1 !== 0). The test was not weakened or rewritten. Capture resources and clock binding used the restored original saved-frame JSON.

The final recovery suite completed32 expected outcomes:31 exit0 and the unchanged duplicate fixture exit1. It contains13 unchanged saved tests,6 path-relocated saved tests,2 receipt-derived input checks, and11 reconstructed controlled tests. Coverage includes22 same-Canvas checks,111 synthetic ROI cases,5 native buffers,1 restored full frame, and4×12 restored decoded frames with unchanged sample hashes and tracking outcomes. All25 saved gate/original test files were independently matched byte-for-byte against published checkpoint ZIPs.

The original full-source provenance JSON and full-movie file-size checks are NOT reported as rerun. Their derived replacements bind restored raw/log/COMPARISON/YUV bytes to saved digest receipts. The initial missing-fixture failure is retained in validation-attempt1. No missing provenance JSON was fabricated. The latest original joined/terminal test bytes were lost; reconstructed replacements are explicitly labelled.

## Limits

No browser, Canvas/GPU performance, real-time responsiveness, or publication verification was performed here. One-frame equality is not proof of all future frames, inputs, browsers, or GPUs. Source recovery and these bounded tests do not establish actor truth, complete map coverage, or full automation.

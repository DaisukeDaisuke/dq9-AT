# Direct contribution consumer experiment: do not promote

Task UUID:9968a009-15a2-4ba1-be68-fd0426dac514. New isolated checkpoint. Production was untouched; prior producer/checkpoint archives remain unchanged. Protocol was read without adopting external bindings or generating credentials.

## Result

Implemented a distinct complete-direct-RGB-contribution route in `monster-camera-body-alternative.mjs`. The two frozen contribution-producer modules are copied unchanged. No score, appearance ranking, threshold, final-writer meaning or legacy prediction is replaced.

The experiment is not suitable for activation: it introduces a false z002b candidate on the observed top-right command UI in the full-resolution query domain. This failure is retained and is not repaired by fitting a threshold or choosing a favorable node.

## Consumer contract

Opaque/source-only predictions retain the previous path exactly. A composed raster can instead use the separate `source-direct-body-rgb-coefficient-lineage-v1` capability when its complete nondegenerate known contribution support is valid, its frame/alignment match, and the existing same-draw sceneComposition binding matches the retained branch's frame, record, exact FX camera and alignment. The source order must be the admitted map-before-natural-body route; partial composition, unknown operations/pixels and malformed count contracts remain unsupported.

The final-writer ownership object remains present and unchanged. The new route reports a distinct bodyEvidenceCapability and direct contribution evidence. Numerical color-difference certification, indirect depth/occlusion influence, shadow influence and observed-body certification must remain false. This does not claim direct RGB coefficient lineage establishes objectness or species.

The existing source service validates background pixels and the reconstruction before producing the bound destination. Its serialized binding carries frame, record, camera, alignment and mismatch counts, but not a background-pixel hash or complete photometric-input fingerprint. The consumer does not independently reconstruct all background operands. This limitation is explicit; no independent full-source-binding claim is made.

## Five-frame exact rerender corpus

All125 regions and803 retained best proposals were rerendered with the frozen producer and new consumer. All803 gains equal the previous saved gains exactly.

- c28:32 regions,256 replays. Existing residual12/z019b camera alternative unchanged.
-1200:22 regions,218 replays,2 missing recipes.22 composed candidate records now carry direct contribution evidence; no new camera alternative. Legacy residual58/z061c remains unchanged.
-4200:10 regions,26 retained-recipe replays,24 missing recipes. No new alternative from this retained-recipe corpus.
-2355:29 regions,15 replays,420 missing recipes. No new alternative.
-3300:32 regions,288 replays. No new alternative; existing legacy false predictions remain.

All446 missing retained recipes remain explicit unknowns, not tested negatives. Original appearance scores, models, legacy predictions and every failure are preserved. These are fixed-input proposal replays, not exhaustive new pose searches or a fresh full DINO pass.

## Fixed4200 component-tree cases

The four previously fixed native-query agreement groups were evaluated with all five models and their complete retained camera domain. The producer's exact20-draw witness supplies the new same-recipe contribution summaries; proposal IDs, pose, position, old extent and gain equality are checked before binding each summary.

Native256×192 query domain:

- Command UI group0/2: unknown, because appearance prefers z038a while source-body fits prefer z002b.
- Background group6/9/10: tested background preferred.
- Body-sized group25/26/27/30/31/32/34/39: separate conditional z002b alternative.
- Background group46/47: tested background preferred.

Full-resolution exact-I420-source-frame query domain:

- Command UI group0/2 falsely becomes a z002b alternative.
- Body-sized group remains unknown because its appearance prefers z005b, while body fit prefers z002b.
- Both small background groups remain background-preferred.

The full-resolution source I420 hash exactly matches the saved decoded frame. Its FFmpeg RGB conversion is explicitly different from the saved browser-canvas RGB domain. All10 original raw top-model controls agree with their saved browser rankings, though scores differ. The native256 and full-resolution descriptor outcomes remain separate; no favorable domain is substituted for production evidence.

The false UI group's native ROI is(214,15,29,20); its full-resolution source crop is(1762,56,110,76). Appearance ranks z002b0.4766048 ahead of z038a0.4629709. The camera-conditioned source winner is z002b with gain1,388,920, ahead of z043a1,346,735 and z038a1,214,309. Its root-on-floor/emitted-envelope placement is a conditional world geometry hypothesis behind screen-space UI, not evidence that those observed pixels belong to a world actor. Exact recipe, pose/root/floor/camera/source hashes are retained privately in PRIVATE_FALSE_UI_SOURCE_TRACE.json. No UI exclusion rule was invented.

All37 grouping nodes remain in the previous component-tree checkpoint; only the same four previously fixed agreement cases have this native check. The remaining native group cases are uncomputed, not rejected.

## Additional raw4200 coverage

To avoid treating absent old z038a recipes as negatives, a separate current-source bounded service pass evaluates all10 original classified raw regions and all five models with saved browser appearance hints and all retained cameras. It keeps the production1,500ms/128-proposal slice budget and a predetermined first/emitted-outcome boundary, bounded by40 slices.

The recorded run finishes that boundary in4 slices:50/50 model/camera pairs and101 source renders. All ten separate camera alternatives remain unknown. Original false legacy regions25 and2 have tested-background-preferred source alternatives;34 instead prefers z002b in body fit but its saved appearance prefers z038a. These results do not replace or erase the original legacy predictions. Further stored-domain work remains.

This additional pass is budget-bound; its exact measured coverage ledger and final recipes are preserved. A different execution speed can admit different extra work within a final slice. No all-pose or cross-run bit-identical search-coverage claim follows.

## Tests and preserved failure

-23 mutation guards pass, including missing capability/old final-writer contract, stale source/time/ROM/map, camera/alignment mismatch, partial/unproved scene composition, certification substitutions, unknown/degenerate/inconsistent support, missing rival and missing camera.
-All32 c28 opaque-route comparison outputs are byte-identical to the prior comparator; prior rejection messages are unchanged.
-The final consumer revalidates all125 fresh-render corpus results unchanged after the final structural guards.
-The first test incorrectly expected only one new grouped positive. It failed because the full-resolution UI group also became positive. FIRST_EXPECTATION_FAILURE.log is preserved unchanged; factual outcome assertions now explicitly require both the native body candidate and the full-resolution UI false candidate. No acceptance rule was changed to hide this failure.

No live controller/AT/browser activation was performed. No full automation, calibration, species identity or observed body certification is claimed.

## Reproduce

Run from the existing private workspace:

    node consume-body-contribution-9968a009/tests/consumer-contribution.test.mjs
    node consume-body-contribution-9968a009/scripts/rerender-five-corpus.mjs
    node consume-body-contribution-9968a009/scripts/replay-raw-native-4200.mjs

The scripts name all prior source/video/ROM inputs. The grouped fixture requires the frozen contribution producer's exact20-recipe output. No new emulator state is used.

## Deliverable and privacy

Source archive contains the one changed consumer, the two unchanged producer modules, scripts/tests, patches/manifests, this report and non-pixel result summaries. ROM, video/game pixels, raw body recipes, full source placement trace and large evidence are private and must never be committed or published.

Recommendation: preserve this experimental checkpoint only. The producer supplies genuinely missing contribution evidence, but the consumer still lacks a reliable observed-pixel distinction between command UI and a world body. Do not activate this consumer merely because some false groups become background-preferred.

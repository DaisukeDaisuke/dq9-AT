# WIP checkpoint: anchor integration unresolved pending final verification

This is an isolated experiment, not approved production code. Task db4e8599-3993-411f-b5d9-7f6942edba88.
Common baseline 126d5dfd207ce2dbf144ce196c48dd84f5ef5828; exact tracking9 and HUD input hashes in INPUT_BINDINGS.json.
A mounted delayed-anchor test failed once during the combined rerun. Its source-only aggregate is preserved separately. A deterministic controlled-yield reproduction proves the same missing-target-history reseed race in the exact tracking candidate and joined-before-order variant (RESEED_RACE_CONTROL.json). No thresholds or waits were tuned.
RESEED_ORDER_FIX.patch is a HUD-independent two-file proposed fix. Deterministic same-control tests pass for matching target-history completion, cancellation, and source replacement. Complete regression tests on final code are NOT yet complete. JOINED_TEST_RESULTS.json intentionally records the interrupted/failing rerun.
The main preview.mjs entry is now wired to the HUD preparation once per ROM, correcting the prior artifact's diagnostic-entry-only wiring. Sparse remaining masks remain unknown and do not receive stale rectangular classifications. Raw tracks and classification bundles are retained.
Known risks remain: one-pixel occlusion false exclusion; blurred-scene rival; conditional HUD hypothesis is neither pixel ownership nor AT absence. Existing overlapping duplicate replay test remains a known failure.
This ZIP contains source, tests referring to private fixtures, input hashes, and numeric/metadata results only. No ROM, video, image pixels, extracted assets, masks, model weights, or WASM. It does not contain baseline runtime dependencies; apply source to the bound baseline or use the isolated working tree.

// Frozen source/procedural controls only. No fixed actual frame is read here.
import fs from'node:fs';import crypto from'node:crypto';import assert from'node:assert/strict';
import{openMapRom}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/static-scene.mjs';
import{readArm9Overlay}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/rom-overlay.mjs';
import{loadTouchOverlayComposition,produceTouchOverlayPolygons,snapshotTouchCompositionForRaster}from'../web/rom-touch-overlay-composition.mjs';
import{rasterTouchOverlayValidation}from'../web/rom-touch-overlay-raster.mjs';
import{loadJointTouchVideoSource,registerJointTouchVideoCandidates}from'../web/rom-touch-video-candidates.mjs';
import{buildLocalBackgroundRival}from'../web/local-background-rival.mjs';import{scoreExactJointRaster}from'../web/joint-touch-search-core.mjs';
const root='derive-touch-common-domain-ad3e0e26/',hash=b=>crypto.createHash('sha256').update(b).digest('hex'),rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds');
assert.equal(hash(rom),'3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7');
const options={...openMapRom(rom),romSHA256:hash(rom),fieldOverlay:readArm9Overlay(rom,17)},composition=await loadTouchOverlayComposition(options),source=await loadJointTouchVideoSource(options),W=source.viewport.width,H=source.viewport.height;
let state=0x7139ac25;const random=()=>{state^=state<<13;state^=state>>>17;state^=state<<5;return(state>>>0)/4294967296;};
const vectors=[];while(vectors.length<3){const origin=[24+Math.floor(random()*(W-48)),24+Math.floor(random()*(H-48))],endpoint=[24+Math.floor(random()*(W-48)),24+Math.floor(random()*(H-48))];if(Math.hypot(endpoint[0]-origin[0],endpoint[1]-origin[1])>=composition.constants.minimumDistanceFx/4096)vectors.push({origin,endpoint});}
const candidate=c=>({schema:'dq9-touch-vector-validation-candidate-v1',provenance:'synthetic-source-validation',...c}),probe=produceTouchOverlayPolygons(composition,candidate(vectors[0])),sprites=snapshotTouchCompositionForRaster(composition,probe).sprites;
let sourceN=0,sourceSum=[0,0,0];for(const s of sprites)for(let i=0;i<s.rgba.length;i+=4)if(s.rgba[i+3]===255){sourceN++;for(let c=0;c<3;c++)sourceSum[c]+=s.rgba[i+c];}
const cyan=sourceSum.map(v=>Math.round(v/sourceN));
function background(kind){const rgba=new Uint8ClampedArray(W*H*4);let noiseState=0xacf98153;const noise=()=>{noiseState=(Math.imul(noiseState,1664525)+1013904223)>>>0;return noiseState>>>24;};
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){let rgb;if(kind==='uniform cyan')rgb=cyan;else if(kind==='uniform white')rgb=[255,255,255];else if(kind==='linear RGB gradient')rgb=[30+x/2,40+y/2,60+x/4+y/4];else if(kind==='checker')rgb=((x>>>2)^(y>>>2))&1?[220,240,250]:[20,40,80];else if(kind==='deterministic RGB noise')rgb=[noise(),noise(),noise()];else rgb=[100+70*Math.sin(x/17),120+60*Math.cos(y/11),130+80*Math.sin(x/23+y/19)];rgba.set([...rgb,255],(y*W+x)*4);}return{width:W,height:H,rgba};}
let epoch=0;const frameOf=image=>({romSHA256:source.romSHA256,sourceId:'independent-source-procedural-contrast-controls',sourceEpoch:epoch++,timelineSegment:0,mediaTime:0,nativeRGBA_SHA256:hash(image.rgba)});
const positives=[],negatives=[];
for(let vi=0;vi<vectors.length;vi++)for(const kind of['uniform cyan','linear RGB gradient','checker']){
 const vector=vectors[vi],image=background(kind),raster=rasterTouchOverlayValidation(composition,produceTouchOverlayPolygons(composition,candidate(vector)),{profile:'isolated-source-validation-native1x-Z-pre-fog'});assert.equal(raster.isolatedRasterReady,true);
 for(let i=0;i<W*H;i++)if(raster.rgba[i*4+3]===255)image.rgba.set(raster.rgba.subarray(i*4,i*4+4),i*4);
 const model=buildLocalBackgroundRival(image,source.backgroundRadiusSourceDerived),reference=scoreExactJointRaster(image,raster,{backgroundModel:model}),frame=frameOf(image),result=await registerJointTouchVideoCandidates(source,image,{frame});
 const midpoint={origin:vector.origin.slice(),endpoint:vector.endpoint.map((v,i)=>Math.round((v+vector.origin[i])/2))};
 const halfRaster=rasterTouchOverlayValidation(composition,produceTouchOverlayPolygons(composition,candidate(midpoint)),{profile:'isolated-source-validation-native1x-Z-pre-fog'});
 const midpointComparison=scoreExactJointRaster(image,halfRaster,{backgroundModel:model});
 const rank=result.candidates.findIndex(c=>JSON.stringify(c.candidate.origin)===JSON.stringify(vector.origin)&&JSON.stringify(c.candidate.endpoint)===JSON.stringify(vector.endpoint));
 const row={vectorIndex:vi,background:kind,...vector,reference,midpointVector:midpoint,midpointComparison,fullReferenceBeatsMidpoint:reference.complete&&midpointComparison.complete?reference.score>midpointComparison.score:null,exactVectorRank:rank,top:result.candidates[0]?{origin:result.candidates[0].candidate.origin,endpoint:result.candidates[0].candidate.endpoint,score:result.candidates[0].exact.score}:null,statistics:result.statistics};
 positives.push(row);console.log(JSON.stringify({kind:'positive',...row}));fs.writeFileSync(root+'private-evidence/CONTROL_POSITIVE_'+vi+'_'+kind.replaceAll(' ','_')+'.json',JSON.stringify(result));
}
for(const kind of['uniform cyan','uniform white','linear RGB gradient','checker','deterministic RGB noise','smooth colored wave']){
 const image=background(kind),frame=frameOf(image),result=await registerJointTouchVideoCandidates(source,image,{frame}),row={background:kind,top:result.candidates[0]?{origin:result.candidates[0].candidate.origin,endpoint:result.candidates[0].candidate.endpoint,score:result.candidates[0].exact.score}:null,statistics:result.statistics};
 negatives.push(row);console.log(JSON.stringify({kind:'negative',...row}));fs.writeFileSync(root+'private-evidence/CONTROL_NEGATIVE_'+kind.replaceAll(' ','_')+'.json',JSON.stringify(result));
}
const positiveMinimum=Math.min(...positives.filter(p=>p.reference.complete).map(p=>p.reference.score)),negativeMaximum=Math.max(...negatives.filter(n=>n.top).map(n=>n.top.score));
const result={schema:'dq9-source-common-domain-controls-v1',planSHA256:hash(fs.readFileSync(root+'evidence/SEARCH_PLAN.json')),sourceNativeSampleOffset:source.sourceNativeSampleOffset,backgroundRadius:source.backgroundRadiusSourceDerived,uniformColorSourceMean:cyan,vectors,positives,negatives,positiveMinimum,negativeMaximum,referenceScoreSeparation:positiveMinimum>negativeMaximum,
 exactVectorRetrieved:positives.filter(p=>p.exactVectorRank>=0).length,positiveCases:positives.length,negativeCases:negatives.length,admissionThreshold:null,
 scope:'Independent fixed source/procedural controls only; exact reference-score separation does not establish detector recall, actual-frame calibration or ownership. No control is discarded or used to alter the frozen algorithm.'};
fs.writeFileSync(root+'evidence/CALIBRATION_CONTROLS.json',JSON.stringify(result,null,2));console.log(JSON.stringify({summary:{positiveMinimum,negativeMaximum,separated:result.referenceScoreSeparation,retrieved:result.exactVectorRetrieved}}));

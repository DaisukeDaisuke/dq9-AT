# Native source reuse integration

Ready for publication review against verified commit 04435ef312975a0e7ec9f50615a5adec4fdc96d0. This stage was made from the published source stage, then the reviewed patch was applied cleanly. All sixteen available entries in the prior publication receipt matched their Git blob identities. Three archive-only checkpoints listed by that receipt were not present in the source stage; they are neither runtime/build inputs nor changed paths.

## Integration result

- Standard repository build passed: restored Debian LLVM 19.1.7, exit 0, all 53 Node validation commands.
- All five rebuilt WASM files are byte-identical to the baseline. No binary changes are proposed.
- Actual integrated client/worker held-frame replay passed, with the same 80 pair outcomes / 79 tested proposals and identical region evidence as the original baseline. Broader pose coverage remains incomplete and AT lower bound remains zero.
- Focused actual-worker tests passed for cancellation, mismatched-ROM rejection, changed-pixel continuation rejection, fresh-job recovery, release, optional expiry, late-result isolation and worker preservation.
- Actual native service source-ownership test completed the 80-pair first sweep, disposed the service, then verified unchanged ROM bytes, unchanged bytes and object identities for all 7,542 source files, and continued usability of the caller-owned NitroFS.
- Generic source-reuse regression passed: isolated/shared filesystem bytes, full source catalog, tested floor plan and input contents match.
- Cache closure is complete for the changed module graph. All changed JavaScript modules parse.

## Ownership boundary

The optional low-level openMapRom filesystem argument is a caller-owned dependency, not an independently hashed proof of source identity. The production worker supplies only its own runState.nitro with that same runState.rom, after matching the request's ROM digest against the digest computed at load. Native request payloads cannot choose that source filesystem. ROM reload disposes the previous source service; ordinary cancellation preserves the same loaded source. The patch does not dispose or mutate the reused filesystem.

## Scope and current browser evidence

The measured improvement is removal of a 268,435,456-byte ROM copy and 237,708,101 bytes of duplicated extracted files. Direct cold project-open timing improved in the initial alternating test; end-to-end first-sweep timings overlap. No reliable browser-speed or timeout-resolution claim is made.

A later unpatched browser export supplied by the root has 22 classified residuals / 220 native pairs, but its native slice reports zero attempts, zero preparation steps, and zero first outcomes. It returned an unknown snapshot rather than the earlier timeout. Existing continuation gating does not schedule that zero-progress slice. This result belongs to source epoch 2; the earlier eight-region replay belongs to source epoch 3. They must not be merged as the same run.

The reuse patch preserves current scheduling, time/proposal budgets, thresholds, candidate sets, renderer branches, frozen-frame checks and unknown outcomes. The error wording now accurately states that timeout requests cancellation; a late result is not automatically attached. Root browser benefit remains unresolved and is being tested separately.

## Deliverables

- SOURCE_MANIFEST.json: exact changed source paths, current/base Git blob identities, SHA256 and byte counts.
- NATIVE_SOURCE_REUSE_INTEGRATED.patch: full thirteen-file source delta, including cache closure, generic regression and scoped documentation.
- SOURCE_CHECKPOINT.zip: the changed source plus review metadata and compact verification receipts.
- VALIDATION_RECEIPT.json, BASELINE_RECEIPT.json, OWNERSHIP_REVIEW.json and STANDARD_BUILD.log preserve the acceptance evidence.

The source checkpoint excludes ROMs, extracted game files, images, video, body/comparison exports, inference assets, full replay output, CPU profiles and local worker test fixtures. No Git, Library, browser or publication operation was performed.

# Bounded fair measured-frame replay integration (held regression)

Do not promote. This isolated integration preserves baseline outcomes but adds substantial overhead and does not extend the original orange-monster lifetime under the agreed budget. Production126d, classification/camera inputs and AT identity wiring were not edited.

## Runtime connection and work policy

The mounted measured-frame replay now executes a resumable witness search and fair scheduler for every retained actual frame pair. The original baseline forward result is shared with the conditional lane; each retained frame is converted to gray once. For every currently viable original track, the scheduler reserves the original594-cost baseline attempt before alternatives. The shared ceiling is594 × active originals, capped at32 originals/19,008 costs. A leftover quantum is one displacement cost, distributed round-robin among originals. No model or residual ID affects allocation. Search order, numeric gates and exact independent reverse uniqueness remain unchanged.

Baseline snapshot.tracks and continuityFor retain the original global-association behavior. Separate conditionalPositionSets hold multiple possible positions, verified-lineage flags and explicit omitted/unverified work. positionHypothesesFor accepts only the exact current retained pixel hash/frame and conditional map scope. It does not write classification/AT identity. An unverified earlier link is never promoted by later correspondence.

The first implementation kept advancing unverified ancestry and cost597ms versus88ms baseline on orange, with hundreds of unresolved background/UI positions. That regression and source are preserved. The revised scheduler does not allocate future work to such ancestry: next position is unknown, prior frame/count remains explicit, and neither stale coordinates nor disappearance are certified. Fully verified alternatives and baseline-live originals retain reservations. This is a general lineage rule, not targeted selection of the orange region.

## Measurements and failures

All baseline track fields, including partial extents, equal the frozen single-winner replay on four fixed actual full32-seed sequences. Original orange12 remains verified only through170.712 and is lost at170.812. The extra0.4s from the costly complete diagnostic is not reproduced. Raw region315 gains conditional image correspondence through170.712, but this is not a monster/body/species gain. Existing r17/r31/r51, fragmented99/120/126/131/141 and holdout371 failures/lifetimes remain visible.

Final full-lane timings, baseline→fair: orange86.5→276.0ms; legacy142.5→235.6ms; fragmented105.2→207.1ms; holdout166.5→273.3ms. Prior runs, including orange119→313ms and the597ms initial experiment, are retained. Headless timings vary but consistently show unacceptable overhead for no orange gain. Final pair-work slices requested8ms and reached15.55ms in actual-frame headless replay; cooperative yielding is not a hard deadline guarantee.

The mounted browser controller was exercised with controlled Canvas/VideoFrame providers in Node, not a live browser session:13 frames retained while background work was blocked,11 measured replay steps, classifier once and13/13 handles closed. Fair completion161ms versus baseline113ms. Timer gaps were38.6ms/47.1ms; fair measured source-work slice maximum9.79ms with two cooperative yields. This verifies source lifecycle and scheduling, not browser render accuracy.

The original overlapping-duplicate assertion still fails (expected0, actual1). Its input and assertion are unchanged; the preserved-suite runner reports9 passes,1 failure and a nonzero exit. It has not been renamed or repaired by altering thresholds.

## Bounds and tests

12 new runtime checks,45 existing mounted-controller checks,4 mounted capture checks,8 capture/resource checks,8 edge/source-binding checks, plus9 passing preserved replay checks and the one retained failure. Repeated mounted timing variants are not additional unique accuracy checks.

Only the current conditional bank is stored; the256-frame pixel history does not contain per-frame branch banks. The actual trials peak at563 current position hypotheses and193,756 bytes of serialized conditional metadata. Current parent edges are bounded by the19,008-cost maximum; historical unknowns retain counts/source frame keys, not growing coordinate arrays. A70-step controlled test with4 frame slots peaks at491,520 retained gray/mask bytes. The default pixel bound remains25,460,736 bytes, excluding transient Canvas/hash buffers. Old seed eviction,0.7s missing history, source/hash change, cancellation within a cost yield and superseding delayed seeds all remain explicit unknown or reset cases.

## Source and reproduction

Changed production-shaped source is limited to video-tracking-replay.mjs plus new video-witness-search.mjs and video-fair-correspondence.mjs. Bootstrap, capture, residual identity adapter, classifier and AT controller source are byte-identical to the frozen replay baseline. This is an isolated copy, not a replacement of current production files.

Run tests/measure-fair.mjs with orange, legacy, fragmented and holdout; then tests/fair-runtime.test.mjs. Existing copied tests run against this phase's web directory. tests/run-preserved-replay-suite.mjs intentionally exits1 for the retained duplicate fixture. tests/mounted-cooperative.test.mjs accepts web/fair or ../replay-lane-ce87377/web/baseline as its two arguments. Private saved comparison pixels and actual FFmpeg crops are required. First seed is exact saved browser RGBA; subsequent frames carry actual FFmpeg PTS and their own hashes, without invented source frame serials. Mixed-decoder evidence is not browser pixel parity.

The checkpoint includes full changed source, baseline replay, patch, tests, README, manifests, scalar summaries and the initial regressing scheduler source. No ROM, videos, pixels, masks, images, game assets, emulator states or credentials are included.

## Next exact overhead target

No duplicate baseline forward search or retained-frame grayscale conversion was found. The scheduler currently creates/awaits an async advance() result on every displacement cost even when no cooperative yield is due. A separate successor may make those ordinary steps synchronous while preserving cost order, reservations, actual yield conditions and cancellation checks. That would be an execution-overhead optimization, not a new tracking result; this slower checkpoint remains immutable.

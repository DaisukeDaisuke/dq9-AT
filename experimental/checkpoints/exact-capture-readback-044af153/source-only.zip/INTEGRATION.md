# Parent integration

Apply EXACT_READBACK.patch to the frozen source or review/copy its two changed files. Shared candidate was not edited. Keep unchanged capture-analysis-pixels.mjs and all classifier/replay/AT code.

Capture imports the sampler through ?v=exact-readback-20261006-0745 so its new named export cannot resolve to a cached old unversioned sampler. Parent publication must also bump map-video-comparison's video-tracking-capture import version and normal ancestor cache chain. These cache-only parent edits are deliberately not made here. Unversioned sampler consumers retain the old API unchanged.

In a permitted browser, keep the formal video/ROM file selection and existing one-button/native-play activation. Before accepting Canvas parity, compare full and rectangular reads from the SAME retained VideoFrame/canvas; re-seeking may yield different pixels. Record VideoFrame/callback timestamps, both sampled SHA values, rectangle/byte count and frame closure. Then measure real browser latency/gaps while background/classification runs. No manual map/model/seconds/JSON parameter is required by this change.

Controlled expectation: full1920×1080 canvas/draw, rectangle961,1,958,718, output256×192. Source/epoch/segment/cancel invalidates pending hash. VideoFrame closes before hashing. Full-screen cases may save zero bytes. Live browser validation remains pending parent.

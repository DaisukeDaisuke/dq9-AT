import fs from 'node:fs';import os from 'node:os';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import {sampleGameplayFrame as original,gameplayVideoROI} from '../../integrate-measured-replay-a9f6b3fc/web/map-browser-preview/map-video-residual.mjs';
import {sampleGameplayFrame as candidate,gameplaySampleReadbackRect as rectFor} from '../web/map-browser-preview/map-video-residual.mjs';
const rounds=101,warmup=25,sha=b=>crypto.createHash('sha256').update(b).digest('hex');let sink=0;
function crop(image,r){const out=new Uint8ClampedArray(r.w*r.h*4);for(let y=0;y<r.h;y++)out.set(image.rgba.subarray(((r.y+y)*image.width+r.x)*4,((r.y+y)*image.width+r.x+r.w)*4),y*r.w*4);return out;}
function stats(values){const a=[...values].sort((a,b)=>a-b);return{n:a.length,min:a[0],median:a[Math.floor(a.length/2)],p90:a[Math.floor(a.length*.9)],max:a.at(-1),mean:a.reduce((s,x)=>s+x,0)/a.length};}
function run(fn){const t=performance.now(),v=fn();sink^=typeof v==='string'?v.charCodeAt(0):v.rgba?.[0]??v[0]??0;return performance.now()-t;}
function pair(a,b){for(let i=0;i<warmup;i++){run(a);run(b);}const aa=[],bb=[];for(let i=0;i<rounds;i++){if(i%2){bb.push(run(b));aa.push(run(a));}else{aa.push(run(a));bb.push(run(b));}}return{original:stats(aa),candidate:stats(bb),medianRatio:stats(bb).median/stats(aa).median};}
const rgba=new Uint8ClampedArray(fs.readFileSync('correct-false-body-4200-63c7feaa/evidence/ffmpeg4200.rgba')),source={width:1920,height:1080,rgba},roi=gameplayVideoROI(1920,1080,'obs-side-1920'),r=rectFor(source.width,source.height,roi),cropped=crop(source,r),old=original(source,roi);assert.deepEqual(candidate({...source,rgba:cropped},roi,{sourceRect:r}),old);
const sources=[{label:'real-1920x1080-OBS',source,roi},{label:'same-real-sample-native-256x192-single-zero-savings',source:old,roi:{x:0,y:0,w:256,h:192}},{label:'synthetic-1024x768-single-small-savings',source:{width:1024,height:768,rgba:new Uint8ClampedArray(1024*768*4).fill(127)},roi:{x:0,y:0,w:1024,h:768}}],results=[];
for(const {label,source,roi}of sources){const r=rectFor(source.width,source.height,roi),cropped=crop(source,r),sample=original(source,roi),readFull=()=>source.rgba.slice(),readCrop=()=>crop(source,r);results.push({label,fullBytes:source.rgba.byteLength,regionBytes:cropped.byteLength,sourceRect:r,
 copyOnly:pair(readFull,readCrop),
 sampleOnly:pair(()=>original(source,roi),()=>candidate({...source,rgba:cropped},roi,{sourceRect:r})),
 unchangedFullSamplerAPI:pair(()=>original(source,roi),()=>candidate(source,roi)),
 copyAndSample:pair(()=>original({...source,rgba:readFull()},roi),()=>candidate({...source,rgba:readCrop()},roi,{sourceRect:r})),
 copySampleNodeSHA256:pair(()=>sha(original({...source,rgba:readFull()},roi).rgba),()=>sha(candidate({...source,rgba:readCrop()},roi,{sourceRect:r}).rgba)),
 sameSampleSHA256:sha(sample.rgba)});console.log(label,JSON.stringify(results.at(-1)));}
const result={createdAt:new Date().toISOString(),node:process.version,platform:process.platform,cpu:os.cpus()[0]?.model,warmup,rounds,alternatingPairOrder:true,results,sink,scope:'Node.js JS CPU and typed-array copy microbenchmark only. Copy-full uses slice; copy-region uses row subarray/set. Neither is browser getImageData; no drawImage/GPU synchronization, color conversion, rendering, async WebCrypto or browser responsiveness time measured. Repeated same pixels may benefit from CPU caches. Ratios are this run only.'};
fs.writeFileSync(new URL('../evidence/NODE_TIMINGS.json',import.meta.url),JSON.stringify(result,null,2)+'\n');

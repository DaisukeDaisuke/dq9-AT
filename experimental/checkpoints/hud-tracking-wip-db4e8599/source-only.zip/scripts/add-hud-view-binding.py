from pathlib import Path
r=Path('merge-hud-measured-tracking-db4e8599');p=r/'web/map-browser-preview/measured-classification-view.mjs';s=p.read_text();needle='export function measuredClassificationView({completed,replay,anchor=null,playbackPTS=null})'
helper='''// HUD policy is a conditional display/queue constraint, never a tracker reset.
function bindHudPolicy(summary,evidence,background){
 if(summary?.conditional!==true)return{bound:false,reason:'no-conditional-HUD-policy'};
 const f=summary.frame,keys=['sourceId','sourceEpoch','timelineSegment','mediaTime'];
 if(!evidence||!background||!keys.every(k=>f?.[k]===evidence[k])||f?.nativeRGBA_SHA256!==evidence.gameplayRGBA_SHA256||f?.romSHA256!==background.romSHA256||summary.source?.romSHA256!==background.romSHA256||typeof summary.conditionalBranchKey!=='string'||!summary.conditionalBranchKey||summary.minimumProvenATCalls!==0||summary.pixelOwnershipCertified!==false||summary.absenceCertified!==false||!Array.isArray(summary.fullyExplainedRegionIds)||!Array.isArray(summary.sparseRemainderRegionIds))return{bound:false,reason:'conditional-HUD-frame-binding-differs'};
 return{bound:true,branchKey:summary.conditionalBranchKey,blocked:new Set([...summary.fullyExplainedRegionIds,...summary.sparseRemainderRegionIds].map(String)),fullyExplained:new Set(summary.fullyExplainedRegionIds.map(String)),reason:summary.state};
}
'''
assert needle in s;s=s.replace(needle,helper+'export function measuredClassificationView({completed,replay,anchor=null,playbackPTS=null,conditionalHudContext=null})')
needle=' const rows=[];for(const s of completed.value.sightings??[])'
insert=''' const sourceHud=completed.value.automaticResidualSelection?.conditionalHud,sourcePolicy=bindHudPolicy(sourceHud,e,completed.background);
 if(sourceHud?.conditional===true&&!sourcePolicy.bound)return no('classification-HUD-source-binding-differs');
 const currentPolicy=bindHudPolicy(conditionalHudContext?.summary,conditionalHudContext?.frameEvidence,conditionalHudContext?.backgroundEvidence),currentPolicyIsSeed=currentPolicy.bound&&videoTrackingFrameKey(conditionalHudContext.frameEvidence)===replay.seedFrameKey&&JSON.stringify([conditionalHudContext.backgroundEvidence?.romSHA256,conditionalHudContext.backgroundEvidence?.recordKey,conditionalHudContext.backgroundEvidence?.mapId])===replay.conditionalMapScope;
 const heldHudRows=[];
 const rows=[];for(const s of completed.value.sightings??[])'''
assert needle in s;s=s.replace(needle,insert)
needle='  const track=replay.tracks.find(t=>t.id===refs[0].trackId&&t.lastSeen===positionPTS);if(!track)continue;'
insert='''  let heldReason=null,currentParent=null;
  if(sourcePolicy.bound&&(sourcePolicy.blocked.has(String(s.originalProposalId))||!completed.value.automaticResidualSelection.requestedRegionIds?.some(id=>String(id)===String(s.originalProposalId))))heldReason='classification-source-parent-HUD-held';
  if(currentPolicyIsSeed){const currentRefs=(replay.seedReferences??[]).filter(r=>r.trackId===refs[0].trackId&&r.sourceFrameKey===replay.seedFrameKey);if(currentRefs.length!==1)heldReason??='current-HUD-parent-binding-unavailable';else{currentParent=currentRefs[0].originalProposalId;if(currentPolicy.blocked.has(String(currentParent)))heldReason??='current-seed-parent-HUD-held';}}
  if(heldReason){heldHudRows.push({originalProposalId:String(s.originalProposalId),trackId:refs[0].trackId,currentSeedParentId:currentParent,reason:heldReason,classificationPTS,positionPTS,sourceConditionalBranchKey:sourcePolicy.bound?sourcePolicy.branchKey:null,currentConditionalBranchKey:currentPolicyIsSeed?currentPolicy.branchKey:null,rawAnchorRetained:true,absenceCertified:false,minimumProvenATCalls:0});continue;}
  const track=replay.tracks.find(t=>t.id===refs[0].trackId&&t.lastSeen===positionPTS);if(!track)continue;'''
assert needle in s;s=s.replace(needle,insert)
s=s.replace("reason:rows.length?'exact-seed-tentative-patch-positions':'no-current-correspondence-for-classified-source',rows,", "reason:rows.length?'exact-seed-tentative-patch-positions':heldHudRows.length?'conditional-HUD-label-transport-held':'no-current-correspondence-for-classified-source',rows,...(sourceHud||conditionalHudContext?{conditionalHudTransport:{sourcePolicyBound:sourcePolicy.bound,currentPolicyBound:currentPolicyIsSeed,currentPolicyIgnoredReason:currentPolicyIsSeed?null:currentPolicy.reason,heldRows:heldHudRows,rawAnchorsUnchanged:true,classificationSourceUnchanged:true,absenceCertified:false,minimumProvenATCalls:0}}:{}),")
p.write_text(s)
p=r/'web/map-browser-preview/map-video-comparison.mjs';s=p.read_text();s=s.replace('return measuredClassificationView({completed,replay:state,anchor,playbackPTS:video.currentTime});','return measuredClassificationView({completed,replay:state,anchor,playbackPTS:video.currentTime,conditionalHudContext:conditionalHud?{summary:comparison?.conditionalHud??null,frameEvidence:frozen?.evidence??null,backgroundEvidence:background?.evidence??null}:null});')
s=s.replace('timeline.update(frame.id,{conditionalHud:summary});if(summary?.conditional)', 'timeline.update(frame.id,{conditionalHud:summary});renderMeasuredPreview();if(summary?.conditional)')
s=s.replace('同一個体・身体全体・出生・AT消費は未確定。`;','同一個体・身体全体・出生・AT消費は未確定。${view.conditionalHudTransport?.heldRows?.length?` HUD条件付き保留${view.conditionalHudTransport.heldRows.length}件（元anchorは保持）。`:""}`;',1)
p.write_text(s)

import fs from'node:fs';import crypto from'node:crypto';
import{openMapRom}from'../../inspect-at-connection-20261004-2203/parent-camera-alternative-integration-0523/web/map-browser-preview/static-scene.mjs';
import{readArm9Overlay}from'../../inspect-at-connection-20261004-2203/parent-camera-alternative-integration-0523/web/map-browser-preview/rom-overlay.mjs';
import{loadRomTouchOriginOverlay}from'../web/rom-touch-origin-overlay.mjs';
export const root='explain-player-ring-ab633c61/',hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export async function source(){const rom=fs.readFileSync('recovery-20261004-2203/verified/dq9_new2.nds'),p=openMapRom(rom),opts={romSHA256:hash(rom),...p,fieldOverlay:readArm9Overlay(rom,17)};return{resource:await loadRomTouchOriginOverlay(opts),opts};}

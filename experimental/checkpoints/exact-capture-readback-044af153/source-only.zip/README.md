# Exact bounded capture readback

Task UUID: `044af153-3b93-46c0-96f8-1fbc9e4b9610` (parent-generated Python UUID4).
Baseline: frozen `integrate-measured-replay-a9f6b3fc/web`.
Status: isolated source candidate and controlled evidence only; not published.

## Result and changes

For existing OBS1920×1080, getImageData changes from `(0,0,1920,1080)` to the derived minimum `(961,1,958,718)`: **8,294,400 → 2,751,376 RGBA bytes per capture, 66.83% fewer**. At an actually achieved10Hz this would be82.94→27.51 MB/s of returned RGBA. This is byte accounting, not measured GPU bandwidth, CPU savings, heap usage or achieved cadence.

Only two production files change:

- `web/map-browser-preview/map-video-residual.mjs`: exported readback bounds and optional `sourceRect` path. Calls without sourceRect retain the original complete sampling loop. The cropped loop reuses exact column coordinates and row offsets.
- `web/map-browser-preview/video-tracking-capture.mjs`: requests the derived rectangle and supplies its global origin to that sampler, through a cache-versioned import.

The full-size Canvas, VideoFrame construction/draw, drawImage dimensions, RGBA interpolation/quantization, hash input, timestamp binding, cadence, source identity, cancellation and frame closure remain unchanged. Slow frozen captures still read their full image because other consumers need it. No GPU resize, color normalization, manual game parameter, new pixel history or inference policy is introduced.

## Rectangle derivation and exactness

Each axis uses the original pixel-center expression in GLOBAL source coordinates, clamps to the integer ROI, floors it, and includes the same +1 neighbor capped at the ROI edge. With positive integer span these addressed positions are monotone. The first sample's first address and last sample's +1 address give the extrema. All addressed points are inside; each rectangle edge is addressed, even if a neighbor coefficient is zero.

Only buffer addresses change after global coordinates/weights are computed. The crop origin is never subtracted before the pixel-center expression. The four channel terms retain their arithmetic order and Uint8ClampedArray assignment. Reusing exact column results does not reassociate interpolation.

The previous contract allows only integer in-bounds ROIs. Fractional, out-of-bounds, empty and nonfinite ROIs still fail; no new clipping policy is invented. Existing edge clamping, one-pixel axes, odd spans and fractional sample positions retain their behavior. Bounds code has no OBS/layout coordinates.

## Evidence

-111 deterministic synthetic dimensions/ROIs compare every196,608 output bytes in normal and cropped calls. An independent oracle enumerates all256×192 samples and four addressed neighbors to check minimal bounds. Cases cover all edges, shifted/odd ROIs, one-pixel axes, upsampling, native sampling and downsampling. These finite tests are not an all-game-input completion claim.
-All four layout types preserve valid/invalid dimensions. Single4×3,256×192 and512×384 have **zero readback-byte savings**. Single1024×768 removes just14,320 bytes(0.455%). Two-screen layouts save the unused screen too.
-Five fixed saved COMPARISON native buffers retain recorded gameplay SHA exactly.
-Existing real1920×1080 `ffmpeg4200.rgba` verifies against `TREE_DINO_4200_FULL_SOURCE.json`: source SHA `47bef83ea442738d888c45448af13189a956fdaabb43088196124618d66b2c0f`. I420 SHA `3dff4cff3e5aa9cf4c99fbf157c12c921e08f8f99c7bf8ad4bf4361f5b1b3d85` also matches fixed COMPARISON analysis provenance. Old/new sampled SHA is `68b112d3a98f8d5e13fece8b7370455904c0f1f4e2d5cb06ec4b189bf8f8c76b`.
-That FFmpeg sample remains DIFFERENT from saved browser-Canvas SHA `9d78efefd78245c0a005ca12f255fd431605d8d62e70418eaac9a93486c6aaf8`. Converter differences are not fixed or concealed.
-Four existing actual decoded sequences(orange,legacy5306.5,fragmented3300,holdout5330),12 frames each, preserve every sampled SHA, replay tracks and failures. Exact saved browser seeds remain separate from FFmpeg pixels. Existing orange loss remains unchanged.
-Controlled lifecycle uses actual unchanged createFrozenAnalysisCapture with controlled VideoFrame and rectangle-correct Canvas. Old/new images and complete stamps deeply match, including callback/pixel timestamp disagreement. Tests cover pending hash, cadence, source ID/epoch/segment changes with/without layout, recovery, unknown layout, callback clocks, cancel/reset, invalid/unbound PTS, HTMLVideoElement fallback, draw/read/sync-hash/async-hash failures and exact frame closure.
-Eight unchanged original suites pass. Preserved replay suite keeps its expected0/actual1 overlapping-duplicate failure; no fixture, threshold or expectation changes.
-Three original mounted mocks return full1920×1080 regardless of getImageData arguments. Unchanged fixtures pass on frozen code and fail with bounded reads(the delayed fixture uses its existing handoff assertion mode). Separately named tests change only the Canvas mock's rectangle semantics. Original assertions pass, including three seed handoffs, classificationPTS0/positionPTS0.36, zero certified draws and closure on stop. Production still rejects malformed pixel dimensions.
-Final immutability check verified all405 frozen source/test files and byte-for-byte copied original tests unchanged.

## JS measurements, including rejected work

`evidence/NODE_TIMINGS.json`: Node v24.19.0,25 warmups,101 alternating before/after rounds per case. Full copy uses typed-array slice; region copy uses row subarray/set. Neither is getImageData.

Real OBS medians:

| Work | Frozen | Candidate |
|---|---:|---:|
| Typed-array copy |1.064ms|0.361ms|
| Sampler only |1.557ms|1.447ms|
| Copy + sample |2.636ms|1.866ms|
| Copy + sample + Node SHA256 |2.744ms|2.004ms|
| Ordinary full-buffer sampler |1.533ms|1.551ms|

The ordinary API difference is small run noise, not an improvement. At256×192, row-copy alone worsens0.016→0.022ms with zero byte saving. At1024×768, row-copy worsens0.294→0.333ms despite tiny byte reduction. Including sampling yields1.527→1.426ms and1.793→1.734ms in this run. Do not generalize machine/cache-sensitive results.

First implementation subtracted origins in every channel lookup, regressing sampler time40–49%; total OBS copy+sample barely changed, and native/full-screen cases worsened. Exact initial sources/timings remain in `experiments/v1-slow-offset-index/`. Final version restores the old ordinary loop and reuses exact cropped indices. A first regression driver expected the delayed test's nonasserting mode to fail; that driver failure is in `experiments/v2-regression-harness-label-mistake/`. Final driver invokes the existing handoff assertions without rewriting them.

## Unmeasured and scope

No actual browser was operated. Real getImageData latency, GPU sync, Canvas converter parity under rectangular reads, WebCrypto, long tasks, responsiveness and total memory remain unmeasured. No route bypassed the parent's recorded browser block. This is not all-map automation, actor identity, classifier accuracy or AT draw certification.

Parent owns integration/browser checks/publication. Inputs use the frozen scripts' exact paths and retained digest evidence. No DST/RAM/state truth, media, pixels, ROM/SAV, extracted assets/models or credentials are packaged. No Git publication, external worker or outside communication occurred.

## Reproduce from shared workspace root

1. `node reduce-exact-readback-044af153/tests/readback-parity.test.mjs`
2. `node reduce-exact-readback-044af153/tests/capture-readback-lifecycle.test.mjs`
3. `node reduce-exact-readback-044af153/tests/actual-sequence-parity.test.mjs`
4. `node reduce-exact-readback-044af153/scripts/run-regression-comparison.mjs`
5. `node reduce-exact-readback-044af153/scripts/measure-readback.mjs`

Original source/input paths must exist. Source-only ZIP cannot run private-video tests without separately authorized inputs. Regression driver succeeds only if expected passes AND retained failures match.

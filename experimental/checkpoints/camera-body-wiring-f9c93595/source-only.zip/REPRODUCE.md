# Reproduce from the existing private workspace

Run from the workspace root. Node 24 was used; no package install is required.

The source checkpoint is an overlay, not a standalone web distribution. To reconstruct the isolated folder, copy the baseline web directory stated in FIVE_FILE_MANIFEST.json, overlay the five candidate files, and retain the test directory at its given relative path. The isolated folder already exists in this workspace.

Commands, in order:

    node wire-camera-body-alternative-f9c93595/scripts/verify-source.mjs
    node wire-camera-body-alternative-f9c93595/tests/test-producer.mjs
    node wire-camera-body-alternative-f9c93595/tests/test-consumer-guards.mjs
    node wire-camera-body-alternative-f9c93595/tests/test-cancellation.mjs
    node wire-camera-body-alternative-f9c93595/tests/test-real-controller.mjs
    node wire-camera-body-alternative-f9c93595/tests/test-legacy-and-repeat.mjs

Producer must run first; later tests read its generated private evidence/WIRED_C28_BUNDLE.json. Tests write private result JSONs under evidence/. Inputs remain unchanged.

Required existing private fixtures:

- inspect-map-video-publication-20261005/BROWSER_1NINN_AUTOPLAY_BODY_c28bcdf.json
- inspect-map-video-publication-20261005/BROWSER_1NINN_AUTOPLAY_COMPARISON_c28bcdf.json
- inspect-map-video-publication-20261005/BROWSER_LONG1200_BODY_57f3f0.json
- correct-video-body-proposal-1f8dd07f/evidence/CURRENT_CAMERA_c28.json
- correct-video-body-proposal-1f8dd07f/web/ (frozen source, for allowed delta verification)
- inspect-at-connection-20261004-2203/parent-production-input-correction-0415/web/ (baseline source, data/enc.json and wasm/at_identify.wasm)

The current integration test does not rerender ROM again. Its current-source proposal input was produced in the prior frozen five-frame experiment, whose executable renderer script is correct-video-body-proposal-1f8dd07f/scripts/rerender-camera-alternatives.mjs. No private input is packaged in the source checkpoint.

For root-stage independent testing, copying the five candidates into the root's staging web directory is a separate parent-owned action. The tests here import the isolated folder directly. WIRING.patch contains the three changed existing files; both new modules are provided as full files. Cache/version updates and deployment are intentionally left to the parent.

# Fixed-trace body RGB dependency

Task UUID: 8b3ad1ff-6206-45ae-8510-3168173a63ec. Baseline: a0bf408712e9a4288fb7080a46a30430340bf992, restored integrate-geometry-display-75457234 source. Producer-only implementation; both producer and consumer remain isolated checkpoints. Production activation is not recommended for this measured version.

## Result

The admitted mixed compositor now follows all accepted body RGB contributions through later map color writes, integer blending, fog, and RGB555 presentation. It exposes a separate `source-fixed-trace-body-rgb555-dependency-v1` capability. The original final-writer mask, ownership extent, RGB, depth, IDs, flags, scores, legacy predictions, and certification fields are unchanged.

This addresses a producer evidence gap. It does not establish observed object membership or reliable species recognition. The implementation does not call this body-removal coverage or change the old `allVisibleContributionsCapturedWithinComposition: false` final-writer field.

## Exact meaning and derivation

The variables are the accepted, already-shaded body fragment RGB6 inputs, independently ranging over 0..63. The map RGB values and the accepted alpha/depth/ID/facing/order/fog trace remain fixed. The domain is deliberately stated at the compositor input, not as all possible ROM texture or lighting states.

For each pixel and channel, keep lower and upper RGB6 endpoints. Initially both equal the source opaque map destination. At an accepted body replacement, use endpoints 0 and63. At an accepted map replacement, both equal its fixed RGB6. At an accepted alpha1..30 blend with nonzero prior alpha and enabled blending:

    endpoint' = floor(((alpha5+1)*sourceEndpoint + (31-alpha5)*endpoint)/32)

Disabled blending or zero prior alpha replaces the destination exactly. Alpha31 always replaces it. Alpha0, depth rejects and duplicate translucent IDs never call the tracker. The tracker also requires its retained alpha to equal the actual prior alpha supplied by the compositor.

Post-raster RGB fog uses the existing source implementation:

    endpoint' = floor(((128-w)*endpoint + w*fogRGB6)/128)

Disabled or alpha-only fog does not change RGB endpoints. Enabled source fog weights outside0..128 do not receive a capability. Full RGB fog replacement has identical endpoints. The final mask compares the endpoints after the actual RGB555 truncation (`RGB6 >>> 1`). The RGB555-to8-bit expansion is injective, so it introduces no further ambiguity.

All these operations are coordinate-wise monotone. Lower and upper endpoints are attainable in this precisely defined domain by setting every accepted body RGB input to its minimum or maximum. Equal final endpoints mean no allowed body color assignment can alter the displayed color; different endpoints mean at least one displayed channel depends on body RGB. The result is exact for this fixed trace, including integer truncation. Floating coefficients, heuristic thresholds and final-alpha inference are unnecessary.

A boolean nonzero-coefficient mask is insufficient: one alpha30 black map blend can reduce a body RGB6 range0..63 to0..1, which is constant at RGB555 display precision. Two such writes can make even RGB6 constant. Both are retained regression cases.

The tracker keeps two temporary RGBA6665 endpoint planes; only two binary masks survive on the compositor result: `preFogBodyColorDependency` and `bodyColorDependency`. A private same-result capability registry validates identities and bytes of the actual RGBA/coverage/depth/native-state arrays, dimensions, stats, frame and alignment before the extent reader accepts those masks. Cloning or serializing the raster does not clone this capability.

## Source boundaries

This analysis is attached only at the existing accepted write branches in monster-native-scene-composition.mjs. Fog is evaluated with the unchanged map-browser-preview/native/fog-raster.mjs, and presentation matches static-mode0-rgb.mjs's rgb555-expanded profile. These modules declare the pinned DeSmuME535f676 derivation. This task validates equivalence to those admitted source modules; it did not run a new external native C++ oracle or establish whole-native-frame parity.

The producer requires the existing guarded source-ordinary-map-before-natural-body route, same-frozen-source-destination binding, fixed frame/camera/alignment, and supported mode0 ordinary depth operations. Existing unknown destination, map/MSE order and opaque depth tie rejection happens before capability creation. Unsupported source geometry, shadow/depth-only branches, unobserved live bindings, other actors and callbacks remain unknown.

The proof is direct color-input dependence. It excludes changes caused only by removing geometry, changing depth acceptance, changing a fog depth, changing alpha or changing source ordering. It does not say an actual ROM color differs from the background. An opaque body that happens to match a background color still has body color-input dependence; this is also why ordinary opaque source coverage alone does not prove observed-body membership.

## Current fixed-input evidence

Both supplied current captures were used: INTEGRATED_a0bf_1215 and INTEGRATED_a0bf_MOVING. The actual1215 native screenshot was inspected. All retained best recipes were replayed without searching or changing any camera, pose, root, model list, gain, or appearance ranking.

- 395 retained best draws replayed; 5 absent best recipes remain unknown.
- Every previous RGBA/native-state/output field is exact, every previous extent field is exact, and all395 saved gains match.
- 35 composed draws provide the new dependency capability.
- In these35 draws, the dependency masks equal their final-writer masks. No new real-capture hidden-color pixels or mask expansion are claimed.
- 1215 region60/z060a:185 dependency pixels, unchanged gain1,299,778. The z061c rival's existing isolated result remains311 pixels/gain788,938.
- 1215 region176/z060a:zero dependency pixels, unchanged gain0. Empty remains distinct from unsupported.

Private full per-draw records and exact recipes remain in the task's evidence directory. They are not application assets or Git inputs. The source-only archive contains aggregate results rather than ROM/video pixels or model assets.

## Optional consumer: keep isolated

optional-consumer/web/monster-camera-body-alternative.mjs is a separately reviewable additive experiment. It accepts only the exact new producer contract plus matched frame/camera/alignment/source-order binding, complete known nondegenerate support, valid in-frame bounds/counts, zero unknown-order/depth-tie stats, and the unchanged fit/model/camera-domain guards. Old unannotated composition retains exactly the prior output. No existing flag is relabeled or guard broadly removed.

The dependency mask satisfies the limited rendered-color-support predicate: it enumerates all pixels whose displayed RGB can depend on accepted body color inputs in the fixed supported trace. It does not satisfy an observed-object-membership predicate. Fit gains can also contain indirect depth/occlusion effects; those are not represented as direct color provenance. Therefore this capability alone is insufficient for safe recognition activation.

Current optional-consumer controls cover40 regions. UI region1 stays unsupported by appearance/body disagreement in both captures. Party regions46/61 and moving11 remain unknown because the z060a alternative has empty support. Region60 has source-fit z060a versus appearance z061c and still yields no supported model. Region176 stays unknown.

Two separate positives appear:1215 region92→z060a and moving region22→z061c. Region92's3×6 ROI at(54,105) is on/near the white-body edge in the inspected frame and has no reliable world-body/species membership proof. This unresolved small-region outcome blocks consumer activation. The parent independently reported that the historical thumbnail gain for region92 was borrowed from region60; correcting that separate legacy attribution does not establish that this native z060a alternative is valid.

The preserved historical contribution-consumer-negative-9968a009 experiment also recorded a false command-UI candidate on a different4200 input. It is kept as historical negative context, not treated as a current code defect. This task does not generalize the current UI negatives to all inputs, domains or poses.

## Validation and integration

See VALIDATION_SUMMARY.json for the final build status and counts. Focused tests include:

- Exact unchanged-output comparisons at each admitted layer, replacement/blend, duplicate/depth/alpha skip and fog branch.
- 4,096 layered cases, each exhaustively enumerating64 possible body RGB6 inputs.
- All129 source fog weights, each exhaustively enumerating64×64 values for two independent body RGB6 inputs.
- Same-result/frame/alignment/output/mask/stat mutation guards.
- Unchanged15 legacy extent checks and1,000 legacy mixed composition sequences; external C++ oracle not run.
- 395 current fixed best-draw replays; optional consumer old-output equality on all40 regions and mutation guards.

These producer files form a separately reviewable patch, not a production activation:

1. web/monster-native-color-dependency.mjs (new)
2. web/monster-native-scene-composition.mjs
3. web/monster-native-extent-evidence.mjs

The scene-composition import URL, including its query, must stay identical in monster-native-body.mjs and monster-native-extent-evidence.mjs so their same-result capability registry is shared. Tests are new files; existing fixed-input tests and build script are unchanged. The optional consumer is outside web/ and has no production import. No Git refs, deployments, browser state, user computer, DST/RAM production paths, thresholds, minimum-size rules or legacy prediction changes were made here.

## Runtime cost: producer also remains isolated

A complete fixed-proposal evaluation benchmark includes raster, unchanged fit scoring, and extent/capability processing. It evaluates all35 current composed recipes in8 alternating-order rounds after one warmup (560 evaluations), without forced GC, new searches or budget changes. Source preparation is excluded. Median35-proposal batch time is169.41ms baseline versus802.41ms producer, a4.736× ratio on this executor. Every gain and unknown destination/order/tie counter remains exact.

The earlier single-pass raster-only totals were nearly equal but omitted expensive capability readback and extent verification. They are not evidence of low end-to-end overhead. The complete measurement supersedes that impression. This cost could materially reduce work within unchanged1.5-second slices. The producer adds accurate provenance but no demonstrated new-mask benefit in these current draws, and the consumer remains unsafe to activate. Preserve both as isolated source checkpoints. A future performance change must preserve the exact capability and unchanged-render guards before any activation decision.

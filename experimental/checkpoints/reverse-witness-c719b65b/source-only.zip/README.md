# Exact independent-reverse rejection witnesses

Isolated source checkpoint. This optimizes the held complete-reverse diagnostic; it does not change the production lane, classification/controller/AT input, or the equal594-cost negative checkpoint.

## Exact change

Before an independent reverse search, calculate the cost of the exact-return offset as an auxiliary probe. This probe does not select the coarse minimum, change fine-search placement, count as a scheduled visit, or establish correspondence. Its cost is charged explicitly.

Run the original scheduled reverse search in its unchanged order and domain. If an actually visited different offset has finite cost lower than or equal to the exact-return cost, the return can no longer be the unique reverse best. Reject immediately with that competing-offset witness. This is an exact rejection proof; it does not infer acceptance from partial search. If no witness appears, finish the original reverse procedure. Acceptance still requires its unique best to be the exact return, the return offset actually visited by that procedure, and the existing single-patch association gate. Ties are never accepted. Nonfinite/unavailable return costs cannot fabricate finite rejection witnesses.

Every forward-feasible candidate receives either the complete independent reverse check or a rejection witness. No answer-based ordering or threshold changes were made. A rejection records actual competing/return costs, the scheduled search prefix and a remaining-work upper bound. Independent oracle tests reconstruct the full unoptimized search and record exact omitted work. Auxiliary probes outside the visited prefix are included in measured costs. Original unsearched forward-domain alternatives remain unknown; complete refers only to the original forward search's tested candidates.

## Actual-frame parity

Four fixed real-video sequences pass byte-for-byte equality of current original-track states, accepted positions and parent references against the complete-reverse diagnostic.405 rejection witnesses reproduce exactly from actual pixel costs, and every reverse trace is a prefix of the original scheduled order. Every accepted reverse trace is complete and includes its exact return. All four source-state hashes are in SUMMARY.json.

Orange residual12 retains eight measured0.1s patch steps through171.112, versus four through170.712 in the original single-best lane. The additional boxes remain on the visible orange monster in pixel review. This is the same limited gain as the complete diagnostic, not a new gain from optimization. The top-edge partial extent and the loss at171.212 while the monster remains partly visible are unchanged.

Fixed negatives remain unchanged: r17/r31 zero, r51 seven steps, fragmented r99 six and r120/r126/r131/r141 zero, holdout r371 four. No species, actor identity, births/deaths or AT draws are certified. These are selected single-original headless trials, not a full production capture/controller or multiple-actor validation.

## Work and time

- Orange:20,787→14,330 displacement costs.53 witnesses skip6,502 scheduled costs and add45 auxiliary probe costs outside the actually visited prefixes.
- Legacy r51:100,053→5,534 costs with the same seven-step lifetime. The whole legacy fixture, including r17/r31, is100,350→5,831;322 witnesses skip94,839 scheduled costs and add320 probe costs.
- Fragmented fixture:11,286→7,172;24 witnesses skip4,131 costs and add17 probes.
- Holdout:4,455→4,190;6 witnesses skip267 costs and add2 probes.

The finite diagnostic bound includes one extra probe per candidate: priorPositionCount *297*(2+297). This is not a production budget proposal. The equal594-cost experiment remains a negative.

Both initial and final headless timings are preserved. Final orange witness127ms versus complete162ms and original44ms. Final r51 witness89ms versus complete809ms and original61ms. Holdout cost decreases slightly but final timing is worse: witness64.6ms versus complete62.3ms, with initial witness76ms also retained. Warmup and bookkeeping affect these small runs; no general speedup or realtime guarantee is claimed.

## Checks and reproduction

Nine checks pass: four fixture state-byte parity and reverse-prefix checks; all witness costs and oracle rejection soundness; full reverse acceptance/return visitation; equal-cost tie rejection; unavailable-return handling; immutable complete/equal-budget ZIPs. The full oracle also accounts exactly for skipped scheduled evaluations minus added probe work.

From the authorized workspace root, run this directory's `tests/measure-witness.mjs` with orange, legacy, fragmented and holdout, then `tests/witness-parity.test.mjs`. Requires original authorized browser comparison snapshots, previously retained actual FFmpeg crops/logs, and the frozen complete and baseline replay source. First seed pixels are exact browser RGBA; later frames have actual FFmpeg PTS with their own gameplay hashes, without borrowed seed serial/full-frame hashes. Mixed-decoder evidence is not browser pixel parity.

Full changed source, baseline helper, patch, tests, README, summary and hashes are included. Private pixels, masks, images, videos, ROM, game assets, emulator states and credentials are excluded. Keep this checkpoint isolated; no production promotion is implied.

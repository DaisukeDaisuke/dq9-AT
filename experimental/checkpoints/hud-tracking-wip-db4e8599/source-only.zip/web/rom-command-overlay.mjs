// Runtime ROM-derived command sprite. No sprite bytes, palette, screen box or video is embedded.
// Isolated checkpoint: approximate registration is diagnostic; only a complete exact
// native-color match can create an exclusion. Lossy/scaled captures remain unknown.
const need=(v,m)=>{if(!v)throw Error(m);};
const u16=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint16(p,true);
const u32=(b,p)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p,true);
const range=(b,p,n)=>need(Number.isSafeInteger(p)&&p>=0&&Number.isSafeInteger(n)&&n>=0&&p+n<=b.length,'SPR range outside resource');
const sha=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');
const ownedSources=new WeakMap(),ownedRegistrations=new WeakMap();
const CODE_BINDINGS=[
 ['sdk',0x02048960,916,'461049c5382d56535ef6ed41e38b82d821bd17a2a0e21e0c9a08b1e9aa605d27','SPR loader'],
 ['sdk',0x02048538,352,'419a40763c1a7fd9493afda7050441c0e7b53f602444e2b1a37af6a338ec06a2','GX texture/alpha/quad draw'],
 ['sdk',0x02047fbc,148,'c75b636c831017ac27f197be7b08a60917d13a385a62e88323b16ce871a562a3','sprite defaults'],
 ['fieldOverlay',0x0219c258,92,'b7ef9b12144ca451f2372fda6cce55199f8e7a956fd9b81895a2476e0542c696','field slot resource load'],
 ['fieldOverlay',0x0219bb38,80,'095072124f0ac5ad2674d96566e40e71660e82f2c51a84255f327927303ce0d8','slot-zero screen draw'],
 ['fieldOverlay',0x0218ce2c,24,'dd3a0f51e32a8212dc2672ae0e3a0fa54b957340a18ecf104ca5a263e5819a24','conditional default placement'],
];
function ascii(read,address){let s='';for(let i=0;i<256;i++){const b=read(address+i,1)[0];if(!b)return s;need(b>=32&&b<127,'Unsupported source resource name');s+=String.fromCharCode(b);}throw Error('Unterminated source name');}
function armImmediate(word){need((word&0x0fe00000)===0x03a00000,'Expected ARM immediate MOV');const imm=word&255,rot=((word>>>8)&15)*2;return ((imm>>>rot)|(imm<<(32-rot)))>>>0;}

/** Decode the exact image/piece format used by ARM9 02048960; no guessed pixel dimensions. */
export function decodeSPRImages(bytes){
 need(bytes instanceof Uint8Array,'SPR bytes required');range(bytes,0,4);const imageCount=u16(bytes,0),format=u16(bytes,2);need(imageCount>0&&format===3,'Only source format3 (4bpp) supported');
 const images=[];let at=4;
 for(let i=0;i<imageCount;i++){
  range(bytes,at,8);const width=u16(bytes,at),height=u16(bytes,at+2),pieces=u32(bytes,at+4);at+=8;
  need(width>0&&width<=255&&height>0&&height<=255&&pieces>0&&pieces<=255,'Unsupported source image dimensions/piece count');const parts=[];
  for(let j=0;j<pieces;j++){
   range(bytes,at,8);const x=u16(bytes,at),y=u16(bytes,at+2),wx=u16(bytes,at+4),hy=u16(bytes,at+6);at+=8;need(wx<=7&&hy<=7,'Texture exponent outside NDS format');const w=8<<wx,h=8<<hy,size=w*h/2;
   need(x+w<=width&&y+h<=height,'Clipped or padded SPR piece requires source draw implementation');range(bytes,at,size);parts.push({x,y,w,h,offset:at,bytes:bytes.slice(at,at+size)});at+=size;
  }images.push({width,height,parts});
 }
 range(bytes,at,4);const paletteCount=u32(bytes,at);at+=4;need(paletteCount>=1&&paletteCount<=16,'Unsupported source4bpp palette');range(bytes,at,paletteCount*2);const palette=Array.from({length:paletteCount},(_,i)=>u16(bytes,at+i*2));need(palette.every(c=>c<0x8000),'Palette high bit requires interpretation');const paletteOffset=at;at+=paletteCount*2;
 const frames=images.map(({width,height,parts})=>{const rgba=new Uint8ClampedArray(width*height*4),coverage=new Uint8Array(width*height);for(const part of parts)for(let p=0;p<part.w*part.h;p++){const value=(part.bytes[p>>>1]>>>((p&1)*4))&15;need(value<palette.length,'SPR palette index outside resource');const x=part.x+p%part.w,y=part.y+Math.floor(p/part.w),i=y*width+x;need(!coverage[i],'Overlapping SPR pieces require source depth/ordering');coverage[i]=1;if(!value)continue;const color=palette[value];for(let c=0;c<3;c++){const q=(color>>>(c*5))&31;rgba[i*4+c]=(q<<3)|(q>>>2);}rgba[i*4+3]=255;}return{width,height,rgba,parts:parts.map(({bytes,...x})=>x)};});
 return{format,imageCount,frames,paletteCount,paletteOffset,decodedPixelDataEnd:at,uninterpretedTrailingBytes:bytes.length-at,scope:'Image/piece/palette payload only; animation footer not executed.'};
}

/** nfs/Narc are the already authorized ROM filesystem/archive adapters. */
export async function loadRomCommandOverlay({romSHA256,nfs,Narc,sdk,fieldOverlay}){
 need(/^[a-f0-9]{64}$/.test(romSHA256??'')&&nfs?.readFile&&Narc?.load&&sdk?.read&&fieldOverlay?.read&&fieldOverlay.id===17,'Bound ROM filesystem, SDK and overlay17 required');
 for(const[k,address,length,expected]of CODE_BINDINGS)need(await sha(({sdk,fieldOverlay})[k].read(address,length))===expected,'Unsupported command-overlay source code: '+k+' '+address.toString(16));
 const read=(a,n)=>fieldOverlay.read(a,n),word=a=>u32(read(a,4),0),pathFormat=ascii(read,word(0x0219c408)),archiveName=ascii(read,word(0x0219c40c));need(pathFormat==='data/bin/%s'&&!archiveName.includes('/'),'Unsupported source archive path');
 const archivePath=pathFormat.replace('%s',archiveName),table=word(0x0219c418);let memberName=null,terminated=false;
 for(let i=0;i<256;i++){const slot=word(table+i*8)|0;if(slot<0){terminated=true;break;}if(slot===0){need(memberName===null,'Duplicate command sprite slot');memberName=ascii(read,word(table+i*8+4));}}
 need(terminated&&memberName&&!memberName.includes('/'),'No unique source command sprite slot');const archive=new Uint8Array(nfs.readFile(archivePath)),narc=Narc.load(archive),hits=[];narc.files.forEach((bytes,i)=>{if(narc.fnt.getFilenameOf(i)===memberName)hits.push(new Uint8Array(bytes));});need(hits.length===1,'Command sprite archive member absent/ambiguous');
 // The supported source is an uncompressed SPR. A different member encoding fails
 // its header validation rather than taking a speculative decompression fallback.
 const bytes=hits[0],decoded=decodeSPRImages(bytes);need(decoded.imageCount===1&&decoded.frames[0].parts.length===1,'Command source requires explicit single-frame/single-piece support');
 const frame=decoded.frames[0],source={schema:'dq9-rom-command-overlay-source-v1',romSHA256,archivePath,archiveSHA256:await sha(archive),memberName,memberSHA256:await sha(bytes),resourceSlot:0,frameIndex:0,width:frame.width,height:frame.height,rgba:frame.rgba,
  defaultPlacement:{x:armImmediate(word(0x0218ce2c)),y:armImmediate(word(0x0218ce38)),scope:'ROM initialization when source mode is neither6 nor9. Current mode/visibility remains unknown; this is never a search gate.'},
  sourceSemantics:{textureFormat:3,transparentPaletteIndex:0,defaultModulation:0x7fff,defaultAlpha:31,drawMethod:'screen-relative GX quad',visibility:'conditional source guards unresolved from video',support:'Only opaque index-nonzero pixels; never the sprite rectangle'},
  sourceCode:CODE_BINDINGS.map(([image,address,length,sha256,purpose])=>({image,address,length,sha256,purpose})),footer:{bytes:decoded.uninterpretedTrailingBytes,executed:false},scope:'Single source sprite, ordinary default pose only. No assertion it is currently drawn; no hardware/capture photometry parity claim.'};
 ownedSources.set(source,{romSHA256:source.romSHA256,archivePath:source.archivePath,memberName:source.memberName,memberSHA256:source.memberSHA256,width:source.width,height:source.height,rgba:source.rgba.slice()});return source;
}
function validateImage(image){need(Number.isInteger(image?.width)&&image.width>0&&Number.isInteger(image?.height)&&image.height>0&&(image.rgba instanceof Uint8Array||image.rgba instanceof Uint8ClampedArray),'Byte RGBA frame required');need(image.rgba.length===image.width*image.height*4,'RGBA dimensions differ');}
function identity(frame){need(frame&&['romSHA256','sourceId','sourceEpoch','timelineSegment','mediaTime','nativeRGBA_SHA256'].every(k=>frame[k]!==null&&frame[k]!==undefined),'Exact ROM/video frame binding required');need(/^[a-f0-9]{64}$/.test(frame.nativeRGBA_SHA256),'Native pixel hash required');return JSON.stringify(Object.fromEntries(['romSHA256','sourceId','sourceEpoch','timelineSegment','mediaTime','nativeRGBA_SHA256'].map(k=>[k,frame[k]])));}

/** Every fully-contained integer placement is evaluated. No preset box, selected
 * region, learned descriptor, fitted color transform or acceptance tolerance. */
export async function registerRomCommandOverlay(source,image,{frame,getCurrentFrame=()=>frame}={}){
 need(ownedSources.has(source),'Runtime source must be loaded from supported ROM code');source=ownedSources.get(source);validateImage(image);const key=identity(frame);need(frame.romSHA256===source.romSHA256,'ROM source binding differs');need(await sha(image.rgba)===frame.nativeRGBA_SHA256,'Frame pixels differ from binding');need(identity(getCurrentFrame())===key,'Stale current frame');
 const support=[];for(let i=0;i<source.width*source.height;i++)if(source.rgba[i*4+3]===255)support.push({x:i%source.width,y:Math.floor(i/source.width),rgb:[...source.rgba.subarray(i*4,i*4+3)]});need(support.length>0,'Empty command source');
 const W=image.width,H=image.height,sw=source.width,sh=source.height,placements={count:0};let best=null,runnerUp=null,exactCount=0,exact=null;
 for(let y=0;y<=H-sh;y++){need(identity(getCurrentFrame())===key,'Source frame changed during registration');for(let x=0;x<=W-sw;x++){
  let sse=0,mae=0,maxError=0,exact5Pixels=0,valid=true;
  for(const p of support){const i=((y+p.y)*W+x+p.x)*4;if(image.rgba[i+3]!==255){valid=false;break;}let q=true;for(let c=0;c<3;c++){const d=image.rgba[i+c]-p.rgb[c];sse+=d*d;mae+=Math.abs(d);maxError=Math.max(maxError,Math.abs(d));q&&=(image.rgba[i+c]>>>3)===(p.rgb[c]>>>3);}if(q)exact5Pixels++;}
  if(!valid)continue;const row={x,y,sse,rgbMAE:mae/(support.length*3),maximumChannelError:maxError,exact5Pixels,opaquePixels:support.length};placements.count++;
  if(!best||sse<best.sse){runnerUp=best;best=row;}else if(!runnerUp||sse<runnerUp.sse)runnerUp=row;
  if(sse===0){exactCount++;exact=row;}
 }}
 // Approximate best-match uniqueness is diagnostic only. Even a large cost gap
 // cannot prove presence when the HUD is absent, clipped, filtered or occluded.
 const verified=exactCount===1,mask=new Uint8Array(W*H);if(verified)for(const p of support)mask[(exact.y+p.y)*W+exact.x+p.x]=1;
 const result={schema:'dq9-rom-command-overlay-registration-v1',frame:structuredClone(frame),source:{romSHA256:source.romSHA256,archivePath:source.archivePath,memberName:source.memberName,memberSHA256:source.memberSHA256},width:W,height:H,search:{domain:'all fully-contained integer translations',placements:placements.count,sourceWidth:sw,sourceHeight:sh,sourceOpaquePixels:support.length,locationPrior:false},best,runnerUp,exactCount,exclusionState:verified?'exact-native-raster-match':exactCount>1?'ambiguous-exact-matches':'unverified-capture-transform',verifiedPixelMask:mask,excludedPixels:verified?support.length:0,unknown:!verified,safeForHardPruning:verified,scope:'Exact equality to source default unfiltered RGB888 raster only. Approximate ranking never creates an exclusion. Unmodeled modulation, alpha, projection, scaling, clipping, video encoding and resampling remain unknown.'};
 need(identity(getCurrentFrame())===key,'Source frame changed after registration');ownedRegistrations.set(result,{key,mask:mask.slice(),imageHash:frame.nativeRGBA_SHA256});return result;
}

/** Partition already-produced residual pixels; never recompute Otsu from a mask.
 * Keep the complete raw domain and exact IDs. A consumer can inspect withheld
 * pixel support without relabeling an unchanged region as a different actor. */
export async function partitionResidualsByCommandOverlay({registration,image,frame,residualMask,regions,getCurrentFrame=()=>frame}){
 const owned=ownedRegistrations.get(registration),key=identity(frame);need(owned&&owned.key===key&&identity(getCurrentFrame())===key,'Registration does not own current frame');validateImage(image);need(await sha(image.rgba)===owned.imageHash,'Changed frame pixels');need(registration.width===image.width&&registration.height===image.height,'Registration image dimensions differ');const N=image.width*image.height;need(residualMask instanceof Uint8Array&&residualMask.length===N&&residualMask.every(v=>v===0||v===1),'Binary residual mask required');need(Array.isArray(regions),'Original region domain required');
 const verifiedMask=owned.mask,worldResidualMask=residualMask.slice(),rawResidualMask=residualMask.slice(),excludedResidualMask=new Uint8Array(N),affected=[];for(let i=0;i<N;i++)if(verifiedMask[i]&&residualMask[i]){worldResidualMask[i]=0;excludedResidualMask[i]=1;}
 for(const r of regions){const q=r.roi;need(q&&[q.x,q.y,q.w,q.h].every(Number.isInteger)&&q.x>=0&&q.y>=0&&q.w>0&&q.h>0&&q.x+q.w<=image.width&&q.y+q.h<=image.height,'Original region outside image');let overlapping=0;for(let y=q.y;y<q.y+q.h;y++)for(let x=q.x;x<q.x+q.w;x++)overlapping+=excludedResidualMask[y*image.width+x];if(overlapping)affected.push({originalRegionId:r.id,excludedPixelsInsideROI:overlapping,reason:'exact-rom-overlay-pixels',bodyMembership:'not-inferred'});}
 need(identity(getCurrentFrame())===key,'Frame changed during residual partition');return{schema:'dq9-rom-overlay-residual-partition-v1',frame:structuredClone(frame),originalRegions:structuredClone(regions),rawResidualMask,worldResidualMask,excludedResidualMask,affected,excludedResidualPixels:excludedResidualMask.reduce((s,v)=>s+v,0),unknown:registration.unknown,rawDomainRetained:true,thresholdRecomputed:false,scope:'Mask-level alternative only. Bounding-box overlap never excludes a whole body/region. Reconnected world components and downstream production wiring are not implemented.'};
}

/** Reconstruct the existing four-neighbour residual membership, validating the
 * full original domain. ROI intersections are not component pixel ownership. */
export function indexResidualMembership({width:W,height:H,residualMask,regions}){
 need(Number.isInteger(W)&&Number.isInteger(H)&&W>0&&H>0&&residualMask instanceof Uint8Array&&residualMask.length===W*H,'Residual dimensions required');const labels=new Int32Array(W*H).fill(-1),queue=new Int32Array(W*H),found=[];
 for(let start=0;start<labels.length;start++){if(!residualMask[start]||labels[start]>=0)continue;const id=found.length;let head=0,tail=1,x0=W,y0=H,x1=-1,y1=-1;queue[0]=start;labels[start]=id;while(head<tail){const p=queue[head++],x=p%W,y=Math.floor(p/W);x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);for(const q of[x?p-1:-1,x+1<W?p+1:-1,y?p-W:-1,y+1<H?p+W:-1])if(q>=0&&residualMask[q]&&labels[q]<0){labels[q]=id;queue[tail++]=q;}}found.push({id,roi:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1},pixels:tail});}
 need(Array.isArray(regions)&&regions.length===found.length&&new Set(regions.map(r=>r.id)).size===found.length,'Incomplete/duplicate original residual domain');for(const r of regions){const f=found[r.id];need(f&&r.pixels===f.pixels&&['x','y','w','h'].every(k=>r.roi?.[k]===f.roi[k]),'Original residual membership differs');}return labels;
}

export async function indexResidualMembershipAsync({width:W,height:H,residualMask,regions,cooperative}){
 need(Number.isInteger(W)&&Number.isInteger(H)&&W>0&&H>0&&residualMask instanceof Uint8Array&&residualMask.length===W*H,'Residual dimensions required');const labels=new Int32Array(W*H).fill(-1),queue=new Int32Array(W*H),found=[];
 for(let start=0;start<labels.length;start++){if(start%W===0)await cooperative.checkpoint();if(!residualMask[start]||labels[start]>=0)continue;const id=found.length;let head=0,tail=1,x0=W,y0=H,x1=-1,y1=-1;queue[0]=start;labels[start]=id;while(head<tail){if(head%256===0)await cooperative.checkpoint();const p=queue[head++],x=p%W,y=Math.floor(p/W);x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);for(const q of[x?p-1:-1,x+1<W?p+1:-1,y?p-W:-1,y+1<H?p+W:-1])if(q>=0&&residualMask[q]&&labels[q]<0){labels[q]=id;queue[tail++]=q;}}found.push({id,roi:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1},pixels:tail});}
 need(Array.isArray(regions)&&regions.length===found.length&&new Set(regions.map(r=>r.id)).size===found.length,'Incomplete/duplicate original residual domain');for(const r of regions){const f=found[r.id];need(f&&r.pixels===f.pixels&&['x','y','w','h'].every(k=>r.roi?.[k]===f.roi[k]),'Original residual membership differs');}return labels;
}

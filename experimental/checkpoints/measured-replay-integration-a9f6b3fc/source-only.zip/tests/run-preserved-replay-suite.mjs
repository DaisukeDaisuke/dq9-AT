// Keep the original suite, original inputs and original expected results.
// Continue after a failure to expose the remaining lifecycle cases; report
// each failed original assertion and retain a nonzero exit code.
import fs from'node:fs';import{pathToFileURL}from'node:url';
const root=new URL('./',import.meta.url),path=new URL('replay-lane.test.mjs',root),lines=fs.readFileSync(path,'utf8').split('\n');
const wrapped=lines.map((line,i)=>/^\{(?:const|let) /.test(line)?`try ${line} catch(error){preservedFailures.push({originalLine:${i+1},message:error.message,actual:error.actual,expected:error.expected});console.log('FAIL original line ${i+1}: '+error.message);}`:line).join('\n').replace("const checks=[]",'const preservedFailures=[],checks=[]').replace('{passed:checks.length,checks,scope:', '{passed:checks.length,checks,failures:preservedFailures,scope:')+'\nif(preservedFailures.length)process.exitCode=1;\n';
const target=new URL('preserved-replay-suite.generated.mjs',root);fs.writeFileSync(target,wrapped);await import(target);

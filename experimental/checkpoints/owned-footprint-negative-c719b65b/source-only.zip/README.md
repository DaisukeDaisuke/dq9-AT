# Conditional source-owned footprint tracking shadow (held negative)

No production integration or promotion. The original raw-bbox replay remains the control. This is a separate source-only checkpoint above the frozen component-support and measured-video replay checkpoints.

## What ran

The existing saved video/ROM inverse hypotheses were rerendered with the current source renderer. No emulator memory, actor truth, privileged seed, manually picked mask, tuned gate, or new camera was used. c28 residual12 has four model hypotheses in each of its two original retained camera branches. All eight remain separate, including negative appearance fits. The cameras happen to produce identical ownership masks for each model in this fixture, but they are not collapsed into certified identities.

`rasterNativeBody().sourceCoverage` is unaligned. The producer shifts it by the branch alignment exactly once. For the admitted opaque/binary subset this is isolated source body-color ownership, not actual video membership or scene occlusion. The known mask is that coverage intersected with the original branch known mask. Every mask's count, bounds and fit gain reproduced its saved hypothesis. Each hypothesis runs independently with its own bbox control as well as the original raw residual bbox control.

The new `video-owned-footprint-support.mjs` binds mask hashes, original actual pixels, source ID/epoch/segment/PTS/full-frame and gameplay hashes, ROM/map, branch/alignment, model, original pose/root, proposal and extent. It returns bounded raster-ordered prior support (at most 1024 points), never a current segmentation. Its single-hypothesis correspondence closure refuses another track, ROI or previous-frame key, owns its inputs across asynchronous hashing, and stops after any failed pair. Reinitialization requires a new explicit seed. It calls the byte-identical sparse SAD matcher from the held component experiment. Original minimum150 samples, texture2, residual14, clip40, radius16, exact forward/backward inverse and 0.5s gap remain unchanged. Missing/edge points only erode after successful correspondence; no replenishment or offscreen support.

## Measured results

c28 uses the exact browser seed at170.312 and eleven subsequent actual FFmpeg frames at0.1s intervals. This is mixed-decoder headless evidence, not browser pixel parity. Subsequent frames do not inherit the seed frame serial or full-frame hash. The original bbox lasts through170.712 and fails at170.812 while the orange monster remains visible.

- z019b, both cameras:152 points; support through170.512, loss170.612. Forward(-5,+3) vs backward(+6,-3),151 known overlap. Its own bbox fails on the first pair.
- z021a, both cameras:174 points; support through170.512, loss170.612 with residual15.7365. Its own bbox lasts through170.712. Saved model fit gains are negative and are retained.
- z064a, both cameras:333 points, eroding to315; support through170.712, loss170.812 with residual14.2381. Its own bbox lasts through170.512.
- z000c, both cameras:75 points, below150; support and its110-pixel bbox both fail on the first pair.

No hypothesis improves original-bbox retention. The model-specific bbox comparisons show two better support shapes, one worse and one unchanged, twice across cameras. This is not an improvement in detection, classification, identity, or AT information.

The fixed5306.5 negative rows17/31/51 supplied twelve exactly reproducible opaque/binary masks. All were compared against their own bbox and raw residual bbox on the existing actual twelve-frame sequence. Neither r17 nor r31 survives the first pair under ownership support. No r51 support exceeds its original raw bbox lifetime, which reaches5307.2. Negative model fits remain negative even if image correspondence lasts. Three z068a hypotheses need a pre-fog translucent scene destination; no binary/final-RGB substitute was used. They remain unavailable in this shadow. The existing3300 fragmented rows99/120/126/131/141 and5330 holdout371 contain saved best poses and roots, but no saved nativeBodyExtent/ownership summaries. All58 model entries remain untested in this strict saved-extent shadow. A fresh renderer receipt could produce their extents; no claim of impossibility is made. This is not full coverage of those scenes.

## Verification and costs

29 binding, actual-pixel chain and unchanged-source checks pass. Bbox matcher, sparse matcher and optional-callback replay source hashes match frozen baselines exactly. The new helper has no production caller, no timer and no persistent global mask cache. Separate per-hypothesis replay instances in this offline experiment are not a bounded production hypothesis bank. There is no browser overhead result or promotion claim. Per-run headless timings are in SUMMARY.json and include warmup/scheduling variability; smaller runtime after earlier loss is not a speed gain.

Earlier failures remain preserved in their own checkpoints, including the measured replay's overlapping-duplicate fixture assertion failure and170.812 raw-bbox loss, and the worse418-pixel component experiment.

## Reproduction and checkpoint contents

From the authorized workspace root, with the original local evidence present:

1. `node connect-moving-tracks-c719b65b/owned-footprint-shadow-0534/scripts/render-owned-footprints.mjs`
2. `node connect-moving-tracks-c719b65b/owned-footprint-shadow-0534/scripts/render-legacy-owned-footprints.mjs`
3. Run `tests/measure-owned.mjs`, `tests/measure-legacy-owned.mjs`, and `tests/owned-support.test.mjs` at that same prefix.

The renderer scripts import the sibling's frozen current renderer in `correct-video-body-proposal-1f8dd07f/runtime`; its manifest is included as a source dependency manifest. Measurement scripts use the previously retained video crops; generating new crops is not implicit. The source checkpoint contains the full new helper, unchanged sparse matcher and optional-callback replay, scripts, tests, summaries, patch and baseline/dependency hashes. The baseline video-patch matcher is included for review. Apply the new-file patch only above the held component checkpoint, never as a production promotion.

No ROM, video, raw pixels, ownership masks, game assets, emulator states, credentials or private raw snapshots are included. Private `.bin` masks and full evidence JSON remain local and are intentionally not source checkpoint members. Hashes establish transport integrity; exact render agreement was checked separately. Complete general ROM/video automation remains unproved.

import hashlib,json,subprocess
from pathlib import Path
root=Path('compare-appearance-sampling-12deb83d');video=Path('recovery-20261004-2203/new-video-received/verified/00.23-1.45.41-0x32741.mkv');rows=[]
for seconds,suffix in [(1200,'57f3f0'),(4200,'df40cb'),(2355,'df40cb'),(3300,'84747e3')]:
 cmp=Path(f'inspect-map-video-publication-20261005/BROWSER_LONG{seconds}_COMPARISON_{suffix}.json');c=json.loads(cmp.read_text());rgba=root/f'evidence/decoded-{seconds}.rgba';yuv=root/f'evidence/decoded-{seconds}.yuv';cmd=['ffmpeg','-hide_banner','-loglevel','info','-threads','1','-ss',str(seconds),'-i',str(video),'-map','0:v:0','-frames:v','1','-pix_fmt','rgba','-f','rawvideo',str(rgba),'-map','0:v:0','-frames:v','1','-pix_fmt','yuv420p','-f','rawvideo',str(yuv)];hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 if rgba.exists() or yuv.exists():
  assert rgba.exists() and yuv.exists(),'Incomplete prior decode retained; use a new isolated output directory'
  prior=json.loads((root/'evidence/CONTROLLED_FRAME_MANIFEST.json').read_text());saved=next(x for x in prior if x['fixture']==str(seconds));assert hash(rgba)==saved['fullRGBA_SHA256'] and hash(yuv)==saved['decodedI420SHA256'],'Prior decoded pixels changed'
 else:
  done=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(root/f'evidence/decode-{seconds}.log').write_bytes(done.stdout);assert done.returncode==0
 assert rgba.stat().st_size==1920*1080*4;assert hash(yuv)==c['video']['analysisInput']['copiedYuvSHA256'];rows.append({'fixture':str(seconds),'decodedI420SHA256':hash(yuv),'savedI420SHA256':c['video']['analysisInput']['copiedYuvSHA256'],'exactSourceFrameI420':True,'fullRGBA_SHA256':hash(rgba),'savedBrowserFullRGBA_SHA256':c['video']['fullRGBA_SHA256'],'browserRGBIdentical':hash(rgba)==c['video']['fullRGBA_SHA256'],'rgbaFile':str(rgba)})
rows.append({'fixture':'c28','exactSourceFrameI420':None,'freshSourceResolutionUnavailable':True,'reason':'Saved frame has exact native RGBA but no I420 fingerprint. Do not substitute a seek-time guess for the captured source frame.'});(root/'evidence/CONTROLLED_FRAME_MANIFEST.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))

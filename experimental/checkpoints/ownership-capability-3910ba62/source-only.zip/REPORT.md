# Narrow final-body ownership capability

Task UUID:3910ba62-333a-4a20-baff-3763e6d2c45d. Isolated two-module producer change. No production edits, comparator changes, threshold changes, DST/RAM input or actor identity assertion.

## Result

Implemented a compositor-owned capability for the narrow case where no opaque actor fragment was accepted before the guarded map translucent stream. In that case every accepted actor fragment executes afterward, with no later non-body fragment, so final-body-writer ownership captures all body contributions within this admitted conditional composition.

The capability is withheld whenever there was any earlier accepted opaque actor write, even if a later actor fragment appears to overwrite it. Missing source order/frame binding, rejected unknown footprints, stale bindings, cloned/forged render results, or mutated ownership/coverage masks retain the existing incomplete contract. Empty accepted body support remains empty; no observed body is fabricated.

## Exact actual witness is negative

The actual z038a source command path selects its visible opaque material9 for shape17. Each of the four saved camera/pose/root hypotheses emits20 opaque source polygons. They accept13,1,43 and74 opaque actor writes before map translucency respectively. Thus none meets the narrow capability. All four retain allVisibleContributionsCapturedWithinComposition:false, and the existing unknown classification is preserved.

Twenty exact retained candidate recipes across those four grouped regions and all five source models were rerendered before/after. All pixels, depth/native state, renderer result metadata and gains match exactly. No actual witness was upgraded. The16 opaque-path extents and four ineligible mixed extents are byte-for-byte equal. This is a valid conditional producer implementation, not an actual4200 recognition fix or reason to relax a gate.

The exact ROM command extraction and all pose/root/camera recipes remain in private evidence. They come from ROM plus retained video-derived inverse hypotheses, never emulator memory.

## Files

- web/monster-native-scene-composition.mjs: count accepted early opaque actor writes without changing raster operations; retain an ephemeral per-result proof; expose a guarded capability reader and a read-only source execution ordering trace.
- web/monster-native-extent-evidence.mjs: upgrade only the matching compositor-created capability; otherwise return the original incomplete metadata unchanged.

The result proof is held in a WeakMap keyed by the exact renderer result. It cannot be supplied through serialized JSON. Frame and alignment must match, ownership/coverage array identities and snapshots must remain unchanged, and the source destination must have the guarded map-before-natural-body ordering. The source ordering trace is diagnostic metadata only, not a substitute for the guarded capability.

The compositor import URL, including its version query, must match between monster-native-body.mjs and the extent reader. Both use the current same query in this checkpoint. A mismatched module instance fails conservatively to the old incomplete contract rather than granting capability. Any future cache bump must update those imports consistently.

## Source reasoning

The unchanged compositor processes actor opaque polygons first, map translucent fragments second, then actor translucent-list polygons in source order. Alpha31 texels in a translucent-list polygon remain in that final actor phase. The existing early opaque acceptance branch is the immediate writer counted by the new producer. If the count is zero, all accepted actor color writes occur after every admitted map translucent write. No non-body fragment runs afterward. Post-composition fog does not introduce a later actor-independent fragment writer. This establishes completeness only inside the existing admitted renderer subset and conditional source-order assumptions.

An earlier accepted opaque actor write prevents the proof because later map blending may retain actor color while replacing final writer identity. No broad lineage assumption, whole-scene equality, live actor state or visible object membership is inferred.

## Validation

-165 new assertions pass, including100 deterministic layered old/new pixel/native-state equivalence cases.
-15 existing extent-contract tests pass unchanged.
-Existing scene-composition tests pass, including1,000 deterministic mixed fragment sequences; the optional external C++ oracle executable was not invoked in this run.
-20 exact actual-source proposal replays pass, with zero pixel/state/gain changes and zero actual capability upgrades.
-Synthetic cases cover ordinary translucent writes, alpha31 texels in the translucent list, map-then-body blend, rejected opaque geometry, alpha-zero geometry, opaque depth ties, earlier opaque contributions, unknown map order, missing/malformed/stale bindings, disabled blending, cloned/forged results, and mask mutation.

## Reproduce

From the workspace root, with the existing baseline/private inputs retained:

    node correct-body-ownership-capability-3910ba62/tests/ownership-capability.test.mjs
    node correct-body-ownership-capability-3910ba62/tests/legacy-scene-composition.test.mjs
    node correct-body-ownership-capability-3910ba62/tests/legacy-native-extent.test.mjs
    node correct-body-ownership-capability-3910ba62/scripts/replay-exact-owned-proposals.mjs

The exact replay reads the prior frozen GROUPED_NATIVE_4200.json and same saved BODY/COMPARISON source, ROM and geometry WASM documented in its executable script. It does not choose new poses or headings. No browser, Worker/IndexedDB UI or deployment was executed.

## Recommendation and privacy

Keep this as an isolated source checkpoint. It safely represents a proven narrow capability but does not qualify the actual z038a cases or improve current classification. No gate or source-composition raster label was widened.

The source archive contains only the two changed sources, tests/scripts, patch, hashes, this report and aggregate validation. Raw ROM commands, video/game pixels, source recipes and native arrays remain private and must never be committed or published.

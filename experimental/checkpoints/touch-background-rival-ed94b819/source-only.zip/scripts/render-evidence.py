from pathlib import Path
from PIL import Image,ImageDraw
import json
root=Path(__file__).resolve().parents[1]
ids=['4200','1200','c28','2355','3300']
canvas=Image.new('RGB',(256*5,192*3+24*3),(35,35,35));draw=ImageDraw.Draw(canvas)
for col,key in enumerate(ids):
 image=Image.frombytes('RGBA',(256,192),(root/'private-evidence'/('VIDEO_'+key+'.rgba')).read_bytes())
 data=json.loads((root/'private-evidence'/('REGISTRATION_'+key+'.json')).read_text())['registration']
 rasterPath=root/'private-evidence'/('TOP_RASTER_'+key+'.rgba')
 layer=Image.frombytes('RGBA',(256,192),rasterPath.read_bytes()) if rasterPath.exists() else Image.new('RGBA',(256,192))
 gray=Image.new('RGBA',(256,192),(60,60,60,255));gray.alpha_composite(layer)
 marked=image.copy();p=ImageDraw.Draw(marked)
 for rank,r in reversed(list(enumerate(data['candidates']))):
  x,y=r['candidate']['origin'];color=(255,0,255,255) if rank==0 else (255,230,40,255)
  p.ellipse((x-1,y-1,x+1,y+1),fill=color)
 if data['candidates']:
  c=data['candidates'][0]['candidate'];p.line(tuple(c['origin']+c['endpoint']),fill=(255,0,255,255),width=1)
 for row,im,label in [(0,image,key+' original'),(1,gray,'top source hypothesis'),(2,marked,'ranked origins; magenta top')]:
  canvas.paste(im.convert('RGB'),(col*256,row*216+24));draw.text((col*256+3,row*216+4),label,fill='white')
canvas.save(root/'private-evidence'/'FIVE_FRAME_CANDIDATES.png')

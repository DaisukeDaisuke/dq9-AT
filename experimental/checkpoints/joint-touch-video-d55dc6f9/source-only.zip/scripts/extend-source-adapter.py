"""Copy the restored immutable prior source into the new isolated task, then add
only the bound automatic-video candidate entry. No prior source is modified.
Run after the parent confirms restoration; this script never creates stand-ins.
"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
workspace=root.parent
old=workspace/'restore-touch-geometry-4d501e2a'/'web'
names=['rom-touch-origin-overlay.mjs','rom-touch-overlay-composition.mjs','rom-touch-overlay-raster.mjs']
for name in names:
    if not (old/name).is_file(): raise SystemExit('Missing restored source dependency: '+str(old/name))
original={name:(old/name).read_bytes() for name in names}
composition=original[names[1]].decode()
raster=original[names[2]].decode()
def replace_once(text,old,new):
    if text.count(old)!=1: raise SystemExit('Source adaptation anchor missing or nonunique: '+old[:120])
    return text.replace(old,new,1)
composition=replace_once(composition,
"const need=(x,m)=>{if(!x)throw Error(m);},sources=new WeakMap(),outputs=new WeakMap();",
"import{snapshotJointVideoCandidate}from'./rom-touch-video-candidates.mjs';\nconst need=(x,m)=>{if(!x)throw Error(m);},sources=new WeakMap(),outputs=new WeakMap();")
composition=replace_once(composition,
"export function produceTouchOverlayPolygons(source,candidate){const d=own(source);need(candidate&&Object.keys(candidate).every(k=>['schema','provenance','origin','endpoint'].includes(k)),'Unexpected candidate state fields');need(candidate?.schema==='dq9-touch-vector-validation-candidate-v1'&&candidate.provenance==='synthetic-source-validation','Only explicitly labelled validation candidates are connected');",
"export function produceTouchOverlayPolygons(source,candidate){const d=own(source),video=candidate?.schema==='dq9-touch-vector-video-candidate-v1';if(video){candidate=snapshotJointVideoCandidate(source,candidate);}else{need(candidate&&Object.keys(candidate).every(k=>['schema','provenance','origin','endpoint'].includes(k)),'Unexpected candidate state fields');need(candidate?.schema==='dq9-touch-vector-validation-candidate-v1'&&candidate.provenance==='synthetic-source-validation','Only explicitly labelled validation candidates are connected');}")
if composition.count('sourceValidationOnly:true')!=2: raise SystemExit('Unexpected source validation flag count')
composition=composition.replace('sourceValidationOnly:true','sourceValidationOnly:!video')
composition=replace_once(composition,
"scope:'Four ordinary source GX polygons from a synthetic validation hypothesis, not observed input or complete video pixels.'",
"scope:video?'Four ordinary source GX polygons from a bound automatic video candidate, not observed input or complete video pixels.':'Four ordinary source GX polygons from a synthetic validation hypothesis, not observed input or complete video pixels.'")
raster=replace_once(raster,
" need(profile==='isolated-source-validation-native1x-Z-pre-fog','Explicit isolated validation raster profile required');",
" need(['isolated-source-validation-native1x-Z-pre-fog','isolated-video-candidate-native1x-Z-pre-fog'].includes(profile),'Explicit isolated validation or video candidate raster profile required');")
raster=replace_once(raster,
" const{output:r,sprites}=snapshotTouchCompositionForRaster(source,output),participants=[],failures=[];",
" const{output:r,sprites}=snapshotTouchCompositionForRaster(source,output),participants=[],failures=[];need(profile==='isolated-source-validation-native1x-Z-pre-fog'?r.sourceValidationOnly===true:r.sourceValidationOnly===false&&r.candidate?.schema==='dq9-touch-vector-video-candidate-v1','Candidate provenance differs from explicit raster profile');")
written={names[0]:original[names[0]],names[1]:composition.encode(),names[2]:raster.encode()}
for name,data in written.items():
    dst=root/'web'/name
    if dst.exists() and dst.read_bytes()!=data: raise SystemExit('Refusing to overwrite different existing isolated source: '+str(dst))
    dst.write_bytes(data)
record={'scope':'Isolated copies only; unchanged geometry/math/source bindings; automatic video tokens privately verified by owning adapter',
        'originals':[{'path':str(old/name),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in original.items()],
        'isolated':[{'path':'web/'+name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in written.items()]}
(root/'evidence'/'SOURCE_ADAPTER_DIFF.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

import fs from'node:fs';import assert from'node:assert/strict';import{groupedFixtures}from'./actual-fixtures.mjs';import{compareCameraBodyAlternative as candidate}from'../web/monster-camera-body-alternative.mjs';import{compareCameraBodyAlternative as prior}from'../../inspect-at-connection-20261004-2203/parent-camera-alternative-integration-0523/web/monster-camera-body-alternative.mjs';
const root='consume-body-contribution-9968a009/',native=groupedFixtures(),full=groupedFixtures('full'),reports=[];for(const[domain,rows]of[['native',native],['full',full]])for(const row of rows){const before=JSON.stringify(row.args),a=prior(row.args),b=candidate(row.args);assert.equal(JSON.stringify(row.args),before);assert.equal(a.supportedModelId,null);assert.equal(b.legacyPrediction,a.legacyPrediction);assert(b.unknownNonEnemyPossible&&b.playerPossible&&b.backgroundErrorPossible&&b.noEventPossible&&!b.identityCertified);for(const branch of b.branches){assert(branch.candidates.every(c=>c.ready));for(const c of branch.candidates){const old=a.branches.find(x=>x.branchId===branch.branchId).candidates.find(x=>x.modelId===c.modelId);assert.deepEqual(c.bodyOwnership,old.bodyOwnership);}}reports.push({domain,regionId:row.regionId,oldModelId:a.supportedModelId,newModelId:b.supportedModelId,branches:b.branches.map(x=>({branchId:x.branchId,status:x.status,bestTestedModelId:x.bestTestedModelId,candidates:x.candidates.map(c=>({modelId:c.modelId,ready:c.ready,gain:c.pixelErrorReduction,capability:c.bodyEvidenceCapability??'legacy-opaque-ownership'}))}))});}
assert.equal(reports.filter(r=>r.newModelId).length,2);assert.deepEqual(reports.filter(r=>r.newModelId).map(r=>[r.domain,r.regionId,r.newModelId]),[['native','residual-merge:25,26,27,30,31,32,34,39','z002b'],['full','residual-merge:0,2','z002b']]);
const body=native.find(x=>x.regionId.includes('25,26')),pick=a=>a.sourceBranches[0].candidates.find(c=>c.modelId==='z038a').best,mutations=[
 ['missing-final-writer-contract',a=>delete pick(a).nativeBodyExtent.bodyColorOwnership],
 ['missing-capability',a=>delete pick(a).nativeBodyExtent.directBodyColorContribution],
 ['capability-stale-time',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.frame.mediaTime++],
 ['capability-other-ROM',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.frame.romSHA256='0'.repeat(64)],
 ['capability-other-source',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.frame.sourceEpoch++],
 ['capability-other-map',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.frame.recordKey='wrong'],
 ['capability-alignment',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.alignment.dx++],
 ['scene-camera',a=>pick(a).sceneComposition.binding.camera.viewFx[0]++],
 ['retained-camera',a=>a.backgroundBranchSupport.branches[0].projectionFx[0]++],
 ['scene-frame',a=>pick(a).sceneComposition.binding.frame.fullRGBA_SHA256='0'.repeat(64)],
 ['scene-partial',a=>pick(a).sceneComposition.partialBodyNotScored=true],
 ['scene-order',a=>pick(a).sceneComposition.sourceOrder.kind='unproved'],
 ['scene-subset',a=>pick(a).sceneComposition.sourceAcceptedSubset='unknown'],
 ['extent-record',a=>pick(a).nativeBodyExtent.frame.recordKey='other'],
 ['numeric-change-certification',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.numericalColorDifferenceCertified=true],
 ['indirect-effects-substitution',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.indirectDepthOcclusionInfluenceIncluded=true],
 ['shadow-substitution',a=>pick(a).nativeBodyExtent.directBodyColorContribution.capability.shadowEffectsIncluded=true],
 ['unknown-pixels',a=>pick(a).nativeBodyExtent.directBodyColorContribution.unavailablePixels=1],
 ['inconsistent-known-count',a=>pick(a).nativeBodyExtent.directBodyColorContribution.knownPixels--],
 ['degenerate-contribution',a=>pick(a).nativeBodyExtent.directBodyColorContribution.knownSpatialSupportRank=1],
 ['postfog-expands-prefog',a=>pick(a).nativeBodyExtent.directBodyColorContribution.preFogExtent.pixels=0],
 ['missing-rival',a=>a.sourceBranches[0].candidates.pop()],
 ['missing-camera',a=>a.sourceBranches=[]]
];for(const[name,fn]of mutations){const a=structuredClone(body.args);fn(a);assert.equal(candidate(a).supportedModelId,null,name);}
// Source-only opaque comparisons keep exactly the prior result and errors.
const c28=JSON.parse(fs.readFileSync('correct-video-body-proposal-1f8dd07f/evidence/CURRENT_CAMERA_c28.json')),saved=JSON.parse(fs.readFileSync('inspect-map-video-publication-20261005/BROWSER_1NINN_AUTOPLAY_BODY_c28bcdf.json'));let opaqueExact=0;for(const row of c28.rows){const sight=saved.sightings.find(s=>s.originalProposalId===String(row.regionId)),args={appearanceFrame:row.alternative.frame,rankings:sight.classificationEvidence[0].rankings,legacyPrediction:sight.conditionalBodyPrediction,backgroundBranchSupport:saved.source.background.backgroundBranchSupport,sourceBranches:row.sourceBranches,expectedModelIds:sight.classificationEvidence[0].rankings.map(r=>r.modelId)};assert.deepEqual(candidate(args),prior(args));opaqueExact++;}for(const change of[a=>a.expectedModelIds.push(a.expectedModelIds[0]),a=>a.backgroundBranchSupport.passingBranchCount++]){const a=structuredClone(body.args);change(a);let x,y;try{prior(a);}catch(e){x=e.message;}try{candidate(a);}catch(e){y=e.message;}assert.equal(y,x);assert(x);}
const out={passed:true,mutationGuards:mutations.length,opaqueC28ComparisonsByteIdentical:opaqueExact,priorErrorsIdentical:true,legacyFinalWriterMeaningsUnchanged:true,nativeBodyCandidateOnly:true,fullResolutionFalseUICandidate:true,fullResolutionBodyCandidate:false,reports};fs.writeFileSync(root+'evidence/CONSUMER_CONTRIBUTION_TESTS.json',JSON.stringify(out,null,2));console.log({passed:true,mutationGuards:mutations.length,opaqueExact,reports:reports.map(r=>({domain:r.domain,region:r.regionId,model:r.newModelId,branch:r.branches[0].status}))});

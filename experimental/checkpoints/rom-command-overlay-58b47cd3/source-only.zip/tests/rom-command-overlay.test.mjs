import fs from'node:fs';import assert from'node:assert/strict';
import{decodeSPRImages,loadRomCommandOverlay,registerRomCommandOverlay,partitionResidualsByCommandOverlay}from'../web/rom-command-overlay.mjs';
import{source,hash,root}from'../scripts/fixtures.mjs';
let checks=0;const equal=(a,b)=>{assert.deepEqual(a,b);checks++;},reject=async(f,re)=>{await assert.rejects(f,re);checks++;};
// Synthetic standalone parser case: one8x8 tile, two palette entries, no asset bytes.
const b=new Uint8Array(60),v=new DataView(b.buffer);[[0,1],[2,3],[4,8],[6,8]].forEach(([p,x])=>v.setUint16(p,x,true));v.setUint32(8,1,true);b.fill(0x11,20,52);v.setUint32(52,2,true);v.setUint16(58,0x7fff,true);const parsed=decodeSPRImages(b);equal(parsed.frames[0].rgba.length,256);equal(parsed.frames[0].rgba.every(x=>x===255),true);equal(parsed.uninterpretedTrailingBytes,0);
for(const mutate of [z=>z.subarray(0,3),z=>{z[2]=4;return z;},z=>{z[6]=0;return z;},z=>{z[8]=0;return z;},z=>{z[16]=8;return z;},z=>{z[12]=1;return z;},z=>{z[20]=0x22;return z;},z=>{z[52]=17;return z;},z=>{z[59]=255;return z;}]){assert.throws(()=>decodeSPRImages(mutate(b.slice())));checks++;}
const{resource,opts}=await source();equal(resource.width,32);equal(resource.height,32);equal(resource.sourceSemantics.transparentPaletteIndex,0);equal(resource.memberName,'wing1.spr');
await reject(()=>loadRomCommandOverlay({...opts,fieldOverlay:{...opts.fieldOverlay,read(a,n){const r=opts.fieldOverlay.read(a,n).slice();if(a===0x0219bb38)r[0]^=1;return r;}}}),/Unsupported/);
function image(){const width=96,height=80,rgba=new Uint8ClampedArray(width*height*4);for(let i=0;i<width*height;i++){rgba.set([(i*31+17)%197,(i*53+33)%211,(i*97+3)%223,255],i*4);}return{width,height,rgba};}
function paste(im,x,y){for(let j=0;j<resource.height;j++)for(let i=0;i<resource.width;i++){const p=(j*resource.width+i)*4;if(resource.rgba[p+3]===255)im.rgba.set(resource.rgba.subarray(p,p+4),((y+j)*im.width+x+i)*4);}return im;}
let serial=0;const frame=im=>({romSHA256:resource.romSHA256,sourceId:'synthetic-rom-source',sourceEpoch:1,timelineSegment:1,mediaTime:serial++,nativeRGBA_SHA256:hash(im.rgba)});
const records=[];
async function run(name,im){const f=frame(im),r=await registerRomCommandOverlay(resource,im,{frame:f});records.push({case:name,best:r.best,exactCount:r.exactCount,excludedPixels:r.excludedPixels,state:r.exclusionState});return{r,f,im};}
const absent=await run('HUD-absent independent generated field',image());equal(absent.r.excludedPixels,0);equal(absent.r.exactCount,0);equal(absent.r.best!==null,true);
for(const[x,y]of [[0,0],[41,33],[64,48]]){const{r}=await run('exact translated sprite '+x+','+y,paste(image(),x,y));equal(r.exactCount,1);equal([r.best.x,r.best.y],[x,y]);equal(r.excludedPixels,347);for(let i=0;i<r.verifiedPixelMask.length;i++)if(r.verifiedPixelMask[i]){const tx=i%96-x,ty=Math.floor(i/96)-y;assert.equal(resource.rgba[(ty*32+tx)*4+3],255);}checks++;}
const present=await run('exact-presence partition control',paste(image(),17,21)),first=resource.rgba.findIndex((x,i)=>i%4===3&&x===255)>>>2,fx=first%32,fy=Math.floor(first/32);
const occluded=paste(image(),17,21);occluded.rgba[((21+fy)*96+17+fx)*4]^=1;const o=await run('one source-pixel modified (partial occlusion/photometry)',occluded);equal(o.r.excludedPixels,0);equal(o.r.exactCount,0);
const clipped=paste(image(),0,0);for(let y=0;y<80;y++)clipped.rgba.copyWithin(y*96*4,y*96*4+16*4,(y+1)*96*4);const c=await run('sprite clipped at image edge',clipped);equal(c.r.excludedPixels,0);
const dup=await run('two exact appearances remain ambiguous',paste(paste(image(),0,0),60,40));equal(dup.r.exactCount,2);equal(dup.r.excludedPixels,0);
const blur=paste(image(),17,21),raw=blur.rgba.slice();for(let y=1;y<79;y++)for(let x=1;x<95;x++)for(let c=0;c<3;c++){let s=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)s+=raw[((y+dy)*96+x+dx)*4+c];blur.rgba[(y*96+x)*4+c]=Math.round(s/9);}const bb=await run('source-generated box-filtered capture, no chosen tolerance',blur);equal(bb.r.excludedPixels,0);
const residualMask=new Uint8Array(96*80).fill(1),regions=[{id:0,roi:{x:0,y:0,w:96,h:80},pixels:96*80}];const part=await partitionResidualsByCommandOverlay({registration:present.r,image:present.im,frame:present.f,residualMask,regions});equal(part.excludedResidualPixels,347);equal(part.worldResidualMask.reduce((s,v)=>s+v,0),96*80-347);equal(part.rawResidualMask,residualMask);equal(part.originalRegions,regions);equal(part.thresholdRecomputed,false);equal(part.worldResidualMask[21*96+17],1); // transparent source corner retains possible body
present.r.verifiedPixelMask.fill(1);const safe=await partitionResidualsByCommandOverlay({registration:present.r,image:present.im,frame:present.f,residualMask,regions});equal(safe.excludedResidualPixels,347);
await reject(()=>partitionResidualsByCommandOverlay({registration:{...present.r},image:present.im,frame:present.f,residualMask,regions}),/Registration/);
await reject(()=>registerRomCommandOverlay({...resource},present.im,{frame:present.f}),/Runtime source/);
await reject(()=>registerRomCommandOverlay(resource,present.im,{frame:{...present.f,nativeRGBA_SHA256:'a'.repeat(64)}}),/Frame pixels/);
await reject(()=>registerRomCommandOverlay(resource,present.im,{frame:{...present.f,romSHA256:'a'.repeat(64)}}),/ROM source/);
await reject(()=>registerRomCommandOverlay(resource,present.im,{frame:present.f,getCurrentFrame:()=>({...present.f,sourceEpoch:2})}),/Stale/);
let calls=0;await reject(()=>registerRomCommandOverlay(resource,present.im,{frame:present.f,getCurrentFrame:()=>++calls<3?present.f:{...present.f,sourceEpoch:2}}),/changed/);
await reject(()=>partitionResidualsByCommandOverlay({registration:present.r,image:occluded,frame:present.f,residualMask,regions}),/Changed frame/);
await reject(()=>partitionResidualsByCommandOverlay({registration:present.r,image:present.im,frame:present.f,residualMask:new Uint8Array(1),regions}),/Binary/);
await reject(()=>registerRomCommandOverlay(resource,{width:-96,height:-80,rgba:present.im.rgba},{frame:present.f}),/Byte/);
// Public resource mutation must not change privately bound source pixels or dimensions.
resource.rgba.fill(0);resource.width=1;const again=await registerRomCommandOverlay(resource,present.im,{frame:present.f});equal(again.excludedPixels,347);equal(again.search.sourceWidth,32);
const result={passed:true,assertions:checks,source:'Synthetic inputs plus current formal ROM, no real-frame tuned parameter',cases:records};fs.writeFileSync(root+'TEST_RESULTS.json',JSON.stringify(result,null,2));console.log(result);

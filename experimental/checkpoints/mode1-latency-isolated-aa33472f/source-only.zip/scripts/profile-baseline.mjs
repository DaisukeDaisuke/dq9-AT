import fs from 'node:fs';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {prepareNativeIntegerCompute} from '../baseline/web/map-browser-preview/native-integer-compute-input.mjs';
import {openMapRom} from '../baseline/web/map-browser-preview/static-scene.mjs';
import {buildRomMapCatalog} from '../baseline/web/map-browser-preview/rom-map-catalog.mjs';
import {loadAutomaticScene} from '../baseline/web/map-browser-preview/automatic-scene.mjs';
import {createRendererSourceArchives} from '../baseline/web/map-browser-preview/renderer-source-archives.mjs';
import {prepareMode1PhotometricBasis,renderMode1PhotometricBasis,inferMode1OrdinaryColor} from '../baseline/web/map-browser-preview/mode1-photometric-inverse.mjs';
const root='reduce-background-latency-aa33472f/',inputRoot='recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005/';
const rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds'),archives=createRendererSourceArchives(),project=archives.forProject(openMapRom(rom),rom),records=buildRomMapCatalog(project).maps;
const fixtures=[['long1200','BROWSER_LONG1200_BODY_57f3f0.json','BROWSER_LONG1200_COMPARISON_57f3f0.json'],['long3300','BROWSER_LONG3300_BODY_84747e3.json','BROWSER_LONG3300_COMPARISON_84747e3.json'],['long2355','BROWSER_LONG2355_BODY_df40cb.json','BROWSER_LONG2355_COMPARISON_df40cb.json'],['c28','BROWSER_1NINN_AUTOPLAY_BODY_c28bcdf.json','BROWSER_1NINN_AUTOPLAY_COMPARISON_c28bcdf.json']];
for(const [id,bodyPath,comparisonPath] of fixtures){
 const body=JSON.parse(fs.readFileSync(inputRoot+bodyPath)),cmp=JSON.parse(fs.readFileSync(inputRoot+comparisonPath)),branch=body.source.background.backgroundBranchSupport.branches[0],record=records.find(r=>r.key===branch.recordKey),timings={};
 const timed=(name,fn)=>{const t=performance.now(),r=fn();timings[name]=performance.now()-t;return r;};
 const timedAsync=async(name,fn)=>{const t=performance.now(),r=await fn();timings[name]=performance.now()-t;return r;};
 console.log(id,'start',record.key);
 try {
 const automatic=timed('sceneMs',()=>loadAutomaticScene(project,record)),model=timed('prepareMs',()=>prepareMode1PhotometricBasis({project,rom,record,automatic,camera:branch.camera}));
 console.log(id,'prepared',timings,model.inventory.polygons.length);
 const gpuBasis=timed('gpuBasisPreparationMs',()=>prepareNativeIntegerCompute(model.inventory,model.translucent,model.controls,{...model.read.hypotheses[0].fogParameters,enabled:false})),gpuWeights=timed('gpuWeightsPreparationMs',()=>prepareNativeIntegerCompute(model.weightInventory,model.weightTranslucent,model.controls,{...model.read.hypotheses[0].fogParameters,enabled:false}));
 const basis=await timedAsync('basisMs',()=>renderMode1PhotometricBasis(model)),weights=await timedAsync('weightsMs',()=>renderMode1PhotometricBasis(model,{weights:true}));
 const video={...cmp.analysisVideo,rgba:Uint8Array.from((cmp.analysisVideo?.rgba?cmp.analysisVideo:cmp.nativeVideo).rgba)};
 const result=timed('inferenceMs',()=>inferMode1OrdinaryColor({model,basis,weights,video}));
 const data={id,timings,source:{bodyPath,comparisonPath,romSHA256:crypto.createHash('sha256').update(rom).digest('hex'),recordKey:record.key},model:{basisOnly:model.basisOnly,kind:model.kind,colors:[...model.colors],zeroFog:[...model.zeroFog],read:{hypotheses:model.read.hypotheses.map(e=>({discreteOrdinaryHypothesis:e.discreteOrdinaryHypothesis}))}},basis:Object.fromEntries(Object.entries(basis).map(([k,v])=>[k,ArrayBuffer.isView(v)?[...v]:v])),weights:Object.fromEntries(Object.entries(weights).map(([k,v])=>[k,ArrayBuffer.isView(v)?[...v]:v])),video,result};
 data.video={...video,rgba:[...video.rgba]};fs.writeFileSync(root+'evidence/'+id+'-profile.json',JSON.stringify(data));console.log(id,timings,JSON.stringify(result));
 }catch(error){console.log(id,'ERROR',error.message);fs.writeFileSync(root+'evidence/'+id+'-error.json',JSON.stringify({id,timings,error:error.message,stack:error.stack}));}
}

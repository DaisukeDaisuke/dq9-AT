# Exact functional-source recovery after environment replacement

Recovery UUID: ce0bdaa3-d68e-4fae-a462-eb550c2ed029, generated with Python uuid.uuid4().

The prior115-entry integration archive, SHA2569911052b6622538e818237bb5b8e19ea65a8b0dc8c0d83aeedca298d25df73fa, was not retained in this worker's functions stores and is not claimed recovered. This is a NEW checkpoint, not that archive's byte-for-byte restoration.

All four final functional files WERE restored exactly, verified against their pre-loss SHA256 values retained in the parent/worker conversation:

- map-video-residual.mjs:5e8e4d1c00a3c6cd457d71a1def16241d4a7ffb17576f18bd86c88c6878a3a55
- video-tracking-capture.mjs:6ff71713e2abe8dd8ba3c49077f00ff7783b7a945aee6d87aeea3ef4eda8a53c
- video-tracking-replay.mjs:2636f2b77d06a578b7aae3f066b60e67e5f097b1b3482abefff78fb04fa81ec4
- map-video-comparison.mjs:608324526b931596e1912f24013e0fe9a3f656836771f4ee0d4a77dc99a41101

Inputs were the recovered same-Canvas source archive(c6dc63c3179aa53fddc0700654cc0ccd138bf86da11c217b2a76e1e3bf96ef92), recovered HUD work-in-progress archive(faf15bb5d12c194fb3c10f38d91c3003d6aa8f9de991ff93b8e696161154cf51) and the parent's4c046656 checkout. Only the two independently bound reseed-order files were taken from the HUD archive. No HUD policy was imported. Its comparison and replay matched their previously specified independent hashes before use.

The retained integration operations were replayed: merge gate import/export/accessor with target-frame reseed ordering; update its replay import version; connect decoded input-dimension changes to existing resetSource before new work. The resulting bytes match the exact pre-loss hashes, so these four implementation files are verified recovery, not an unverified new implementation. Element/CSS/client dimensions remain irrelevant to cancellation.

## Recovery verification and provenance

The recovery runner has32 cases, all matching expected exits.31 exit0; the existing overlapping-duplicate fixture retains exit1. This was not a build or actual browser run.

- gate-tests and original-tests are unmodified files from the saved same-Canvas source archive.
- relocated-tests retain original checks while adjusting restored fixture and frozen-code paths. The two reseed tests derive their output/dependency root from their current test location, allowing the publication-stage worker to rerun them without writing into this recovery directory.
- The full old joined/terminal test files from the lost integration archive were unavailable. Explicitly labeled reconstructed harnesses cover held measured history, a simultaneously pending pixel hash, release/cancel/file replacement/decoded resize, return to original decoded dimensions and CSS-only resize. The terminal harness uses separately identified synthetic pixels and checks all five no-wait terminal cases. These test files are NOT claimed byte-identical to the lost harnesses.
- The restored real full RGBA/YUV, five native buffers and48 decoded frames are the previous inputs, verified by saved digest evidence. No new pixels or known-game parameters were substituted.

Two original input checks remain unavailable:

1. TREE_DINO_4200_FULL_SOURCE.json itself was not restored. The first recovery run preserved the resulting ENOENT after111 synthetic and five native checks passed. The derived test now binds the existing full RGBA/YUV to the prior saved READBACK_PARITY receipt and the restored fixed COMPARISON; it also checks the previous sampled SHA. It explicitly records originalProvenanceFileRevalidated=false. No replacement provenance JSON was fabricated.
2. Full movie files were not restored for the old fs.stat comparison. The derived fixed-sequence test instead verifies each restored raw buffer, decode log and COMPARISON against the prior saved ACTUAL_SEQUENCE_PARITY digests, and explicitly records that full-movie stat was not revalidated. The old full-movie assertion is retained in the original saved test.

The failed first recovery pass and its original relocated readback test are preserved under experiments/missing-original-provenance. These are input-availability differences, not product fixes or rewritten historical video failures.

## Applying and rerunning

RECOVERED_FOUR_FILES.patch applies to the parent's recovered4c baseline, with baseline byte checks and final hash verification. The source-only archive includes the exact final files and code baselines. Cache ancestry, final-stage build, browser acceptance and publication belong to the assigned integration worker/parent. No build.sh, Git operation or browser operation was performed by this recovery task.

From /workspace/scratch/4d4d74ad4379:
node recover-gate-reseed-ce0bdaa3/scripts/run-recovery-checks.mjs

The runner uses restored-fixed-captures under recovery-20261006-0852/capture-inputs. These private inputs and other repository dependencies are deliberately excluded from the source checkpoint. No media, pixels, ROM/SAV/DST/RAM, extracted models/assets, credentials or compiled binaries are bundled.

// Original capture files restored with their manifest hashes by the parent.
// The candidate search consumes only nativeVideo pixels and exact video identity.
import fs from 'node:fs';
import crypto from 'node:crypto';
export const hash = b => crypto.createHash('sha256').update(b).digest('hex');
export const cases = [['4200','LONG4200','df40cb'],['1200','LONG1200','57f3f0'],['c28','1NINN_AUTOPLAY','c28bcdf'],['2355','LONG2355','df40cb'],['3300','LONG3300','84747e3']];
export function fixture([id,code,suffix]) {
  const path = `recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005/BROWSER_${code}_COMPARISON_${suffix}.json`;
  const bytes = fs.readFileSync(path), cmp = JSON.parse(bytes);
  const image = {width:256,height:192,rgba:Uint8ClampedArray.from(cmp.nativeVideo.rgba)};
  const frame = {romSHA256:cmp.background.romSHA256,
    ...Object.fromEntries(['sourceId','sourceEpoch','timelineSegment','mediaTime'].map(k=>[k,cmp.video[k]])),nativeRGBA_SHA256:hash(image.rgba)};
  return {id,path,comparisonSHA256:hash(bytes),cmp,image,frame};
}

// Isolated proposal mechanics. This module is not a ROM reader or an ownership classifier.
// The ROM adapter must supply verified source sprites/constants and exact-raster reranking.
import {buildLocalBackgroundRival,backgroundErrorAt,jointContrastScore} from './local-background-rival.mjs';
export const JOINT_SEARCH_PLAN_SHA256 = 'fa2b40a731e9448ed3482b8642dc2d7c45560f9f9fb43e0ce11a05c2e02df0d7';
export const SEARCH_BUDGET = Object.freeze({ origins: 256, originRadius: 4, endpointStride: 4,
  perOrigin: 4, roleSamples: 32, refinementSeeds: 64, originRefineRadius: 2,
  endpointRefineRadius: 3, exactRaster: 128, displayed: 32 });
const need = (x, message) => { if (!x) throw Error(message); };
const normalizeError = 3 * 255 * 255;
const key = c => c.origin.concat(c.endpoint).join(',');
const order = (a, b) => b.score - a.score || a.origin[1] - b.origin[1] ||
  a.origin[0] - b.origin[0] || a.endpoint[1] - b.endpoint[1] || a.endpoint[0] - b.endpoint[0];
export function jointRoleScore(errors) {
  need(errors.length === 4 && errors.every(v => Number.isFinite(v) && v >= 0 && v <= 1), 'Four normalized role errors required');
  return 1 - (errors.reduce((a, b) => a + b, 0) / 4 + Math.max(...errors)) / 2;
}
function samples(sprite) {
  const points = [];
  for (let y = 0; y < sprite.height; y++) for (let x = 0; x < sprite.width; x++) {
    const i = (y * sprite.width + x) * 4;
    need(sprite.rgba[i + 3] === 0 || sprite.rgba[i + 3] === 255, 'Binary source sprite required');
    if (sprite.rgba[i + 3]) points.push({ x: x + .5, y: y + .5,
      rgb: Array.from(sprite.rgba.subarray(i, i + 3)) });
  }
  need(points.length > 0, 'Empty source support');
  const count = Math.min(points.length, SEARCH_BUDGET.roleSamples);
  return Array.from({ length: count }, (_, i) => points[Math.floor(i * points.length / count)]);
}
function pixelError(image, x, y, rgb) {
  x = Math.floor(x); y = Math.floor(y);
  if (x < 0 || y < 0 || x >= image.width || y >= image.height) return null;
  const i = (y * image.width + x) * 4;
  if (image.rgba[i + 3] !== 255) return null;
  let sum = 0;
  for (let c = 0; c < 3; c++) sum += (image.rgba[i + c] - rgb[c]) ** 2;
  return sum / normalizeError;
}
function translatedError(image, points, x, y) {
  let total = 0;
  for (const p of points) { const e = pixelError(image, x + p.x, y + p.y, p.rgb);
    if (e === null) return null; total += e; }
  return total / points.length;
}
function diverse(rows, budget, originRadius, endpointRadius = null) {
  const selected = [];
  let suppressed = 0;
  for (const c of rows) {
    if (selected.some(p => (c.origin[0] - p.origin[0]) ** 2 + (c.origin[1] - p.origin[1]) ** 2 < originRadius ** 2 &&
      (endpointRadius === null || (c.endpoint[0] - p.endpoint[0]) ** 2 + (c.endpoint[1] - p.endpoint[1]) ** 2 < endpointRadius ** 2))) {
      suppressed++; continue;
    }
    selected.push(c);
    if (selected.length === budget) break;
  }
  return { selected, suppressed, unretained: rows.length - selected.length, cutoffScore: selected.at(-1)?.score ?? null };
}
function insertTop(rows, value, count) {
  if (rows.length === count && order(value, rows.at(-1)) >= 0) return;
  rows.push(value); rows.sort(order); if (rows.length > count) rows.pop();
}
/** Pure full-scene bounded proposal search. It never accepts an origin, endpoint,
 * ROI, label, player position or answer coordinate as input. All ranking budgets
 * are fixed above. Float affine sampling is only a proposal approximation; the
 * caller must preserve its uncomputed cases and rerank using the guarded ROM raster. */
export async function searchJointTouchVectors(image, model, { checkCurrent = () => {}, yieldTask = async () => {}, backgroundModel = null } = {}) {
  need(Number.isInteger(image?.width) && Number.isInteger(image?.height) && image.width > 0 && image.height > 0 &&
    (image.rgba instanceof Uint8Array || image.rgba instanceof Uint8ClampedArray) && image.rgba.length === image.width * image.height * 4,
    'Native byte RGBA image required');
  need(model?.sprites?.length === 4 && model.originPoints?.length === 2 && model.originPoints.every(p => p.length), 'Bound four-sprite source support required');
  const W = image.width, H = image.height, c = model.constants;
  const background = backgroundModel ?? buildLocalBackgroundRival(image,model.backgroundRadius);
  const sampleOffset = model.sampleOffset ?? [0,0];
  need(Array.isArray(sampleOffset) && sampleOffset.length === 2 && sampleOffset.every(Number.isInteger), 'Source-native sample offset required');
  need([c.minimumDistanceFx, c.shaftWidthScale, c.shaftLengthBias, c.shaftLengthDivisor, c.headScaleX, c.headScaleY].every(Number.isInteger) && c.shaftLengthDivisor > 0, 'Source constants required');
  const shaft = samples(model.sprites[1]), head = samples(model.sprites[2]);
  const originRows = [], originCache = new Map();
  const stats = { originPlacements: 0, unsupportedOriginPlacements: 0, coarseVectorEvaluations: 0,
    coarseShortVectors: 0, coarseIncompleteVectors: 0, refinementVectorEvaluations: 0,
    refinementDuplicateVectors: 0, refinementUnsupportedVectors: 0 };
  function originAt(x, y) {
    if (x < 0 || y < 0 || x > 255 || y > 255) return null;
    const k = y * 256 + x;
    if (originCache.has(k)) return originCache.get(k);
    const errors = model.originPoints.map(points => translatedError(image, points, x + sampleOffset[0], y + sampleOffset[1]));
    const backgroundErrors = model.originPoints.map(points => {
      let sum=0; for(const p of points){const e=backgroundErrorAt(background,x+sampleOffset[0]+p.x,y+sampleOffset[1]+p.y);if(e===null)return null;sum+=e;}return sum/points.length;
    });
    const r = errors.concat(backgroundErrors).some(e => e === null) ? null : { origin: [x, y], endpoint: [0, 0],
      originErrors: errors, backgroundErrors, score: jointContrastScore(errors,backgroundErrors) };
    originCache.set(k, r); return r;
  }
  for (let y = 0; y < H; y++) {
    checkCurrent();
    for (let x = 0; x < W; x++) {
      const row = originAt(x, y);
      if (row) { originRows.push(row); stats.originPlacements++; }
      else stats.unsupportedOriginPlacements++;
    }
  }
  originRows.sort(order);
  const originSelection = diverse(originRows, SEARCH_BUDGET.origins, SEARCH_BUDGET.originRadius);
  function vectorAt(o, ex, ey) {
    if (!o || ex < 0 || ey < 0 || ex >= W || ey >= H || ex > 255 || ey > 255) return null;
    const ox = o.origin[0], oy = o.origin[1], dx = ex - ox, dy = ey - oy, length = Math.hypot(dx, dy);
    if (length * 4096 < c.minimumDistanceFx) return { short: true };
    const ux = dx / length, uy = dy / length;
    const scales = [[c.shaftWidthScale / 4096, (length * 4096 - c.shaftLengthBias) / c.shaftLengthDivisor],
      [c.headScaleX / 4096, c.headScaleY / 4096]];
    const errors = [o.originErrors[0], 0, 0, o.originErrors[1]], backgroundErrors = [o.backgroundErrors[0],0,0,o.backgroundErrors[1]];
    for (let part = 0; part < 2; part++) {
      const sprite = model.sprites[part + 1], points = part ? head : shaft;
      let sum = 0, backgroundSum = 0;
      for (const p of points) {
        const localX = (p.x - Math.floor(sprite.width / 2)) * scales[part][0];
        const localY = (sprite.height - p.y) * scales[part][1] + (part ? length : 0);
        const e = pixelError(image, ox + uy * localX + ux * localY + sampleOffset[0], oy - ux * localX + uy * localY + sampleOffset[1], p.rgb);
        const backgroundError = backgroundErrorAt(background,ox + uy * localX + ux * localY + sampleOffset[0],oy - ux * localX + uy * localY + sampleOffset[1]);
        if (e === null || backgroundError === null) return null;
        sum += e; backgroundSum += backgroundError;
      }
      errors[part + 1] = sum / points.length; backgroundErrors[part + 1] = backgroundSum / points.length;
    }
    return { origin: o.origin.slice(), endpoint: [ex, ey], score: jointContrastScore(errors,backgroundErrors), roleErrors: errors, backgroundErrors, roleGains:errors.map((e,i)=>backgroundErrors[i]-e),
      proposalOnly: true, sourceMathApproximation: 'Float affine sprite sampling; exact guarded raster reranking required' };
  }
  const coarse = [];
  for (let oi = 0; oi < originSelection.selected.length; oi++) {
    checkCurrent();
    const perOrigin = [], o = originSelection.selected[oi];
    for (let ey = 0; ey < H; ey += SEARCH_BUDGET.endpointStride) for (let ex = 0; ex < W; ex += SEARCH_BUDGET.endpointStride) {
      stats.coarseVectorEvaluations++;
      const row = vectorAt(o, ex, ey);
      if (row?.short) { stats.coarseShortVectors++; continue; }
      if (!row) { stats.coarseIncompleteVectors++; continue; }
      insertTop(perOrigin, row, SEARCH_BUDGET.perOrigin);
    }
    coarse.push(...perOrigin);
    if (oi % 8 === 7) await yieldTask();
  }
  coarse.sort(order);
  const seeds = diverse(coarse, SEARCH_BUDGET.refinementSeeds, 2, 4);
  const refined = new Map(coarse.map(row => [key(row), row]));
  for (let si = 0; si < seeds.selected.length; si++) {
    checkCurrent();
    const seed = seeds.selected[si];
    for (let oy = -SEARCH_BUDGET.originRefineRadius; oy <= SEARCH_BUDGET.originRefineRadius; oy++)
      for (let ox = -SEARCH_BUDGET.originRefineRadius; ox <= SEARCH_BUDGET.originRefineRadius; ox++) {
        const origin = originAt(seed.origin[0] + ox, seed.origin[1] + oy);
        for (let ey = -SEARCH_BUDGET.endpointRefineRadius; ey <= SEARCH_BUDGET.endpointRefineRadius; ey++)
          for (let ex = -SEARCH_BUDGET.endpointRefineRadius; ex <= SEARCH_BUDGET.endpointRefineRadius; ex++) {
            const endpoint = [seed.endpoint[0] + ex, seed.endpoint[1] + ey];
            const k = origin ? origin.origin.concat(endpoint).join(',') : null;
            if (k && refined.has(k)) { stats.refinementDuplicateVectors++; continue; }
            stats.refinementVectorEvaluations++;
            const row = vectorAt(origin, ...endpoint);
            if (!row || row.short) { stats.refinementUnsupportedVectors++; continue; }
            refined.set(k, row);
          }
      }
    if (si % 4 === 3) await yieldTask();
  }
  const ranked = [...refined.values()].sort(order);
  const exact = diverse(ranked, SEARCH_BUDGET.exactRaster, 2, 2);
  checkCurrent();
  return { proposals: exact.selected, originProposals: originSelection.selected,
    statistics: { ...stats, retainedOriginProposals: originSelection.selected.length,
      unretainedOrigins: originSelection.unretained, originCutoffScore: originSelection.cutoffScore,
      coarseRetained: coarse.length, refinementSeeds: seeds.selected.length, distinctRefinedCandidates: refined.size,
      exactRasterProposals: exact.selected.length, unretainedApproximateCandidates: exact.unretained,
      approximateCutoffScore: exact.cutoffScore },
    unknownAlternatives: [
      { kind: 'absent-overlay', status: 'retained-scored-reference', relativeScore:0, model:background.schema, radius:background.radius, scope:'Zero means no improvement over the explicit local smooth-background rival; not an absence posterior' },
      { kind: 'uncomputed-vectors', status: 'retained', reason: 'Bounded origin, endpoint lattice, refinement and exact-raster budgets; not exhaustive byte-domain search' },
      { kind: 'short-vector-heading', status: 'uncomputed', reason: 'No actor heading from ROM/video inferred; no zero/default substitute' },
      { kind: 'clipped-or-off-viewport', status: 'uncomputed', reason:'Includes incomplete background perimeter' },
      { kind: 'capture-and-current-display-state', status: 'uncomputed' }
    ],
    planSHA256: JOINT_SEARCH_PLAN_SHA256, threshold: null, admitted: false, unknown: true,
    pixelOwnershipVerified: false, safeForHardPruning: false, excludedPixels: 0 };
}
/** All four roles must have visible final opaque support. Missing roles are an
 * incomplete composition hypothesis, never a good score from the remaining subset. */
export function scoreExactJointRaster(image, raster, {backgroundModel} = {}) {
  need(backgroundModel?.schema === 'dq9-local-no-overlay-background-rival-v1' && backgroundModel.width===image.width && backgroundModel.height===image.height, 'Bound full-scene background rival required');
  if (!raster?.isolatedRasterReady) return { complete: false, reason: 'Unsupported exact source raster', failures: raster?.failures ?? [] };
  need(raster.width === image.width && raster.height === image.height, 'Raster/video shape mismatch');
  const sums = [0, 0, 0, 0], backgroundSums=[0,0,0,0], counts = [0, 0, 0, 0];
  for (let i = 0; i < image.width * image.height; i++) {
    if (raster.rgba[i * 4 + 3] !== 255) continue;
    const role = raster.owner[i];
    need(Number.isInteger(role) && role >= 0 && role < 4, 'Unexpected source owner role');
    if (image.rgba[i * 4 + 3] !== 255) return { complete: false, reason: 'Unobserved video support' };
    let error = 0;
    for (let c = 0; c < 3; c++) error += (image.rgba[i * 4 + c] - raster.rgba[i * 4 + c]) ** 2;
    if(!backgroundModel.valid[i])return{complete:false,reason:'Source support has incomplete background perimeter'};
    sums[role] += error / normalizeError; backgroundSums[role]+=backgroundModel.errors[i];counts[role]++;
  }
  if (counts.some(n => !n)) return { complete: false, reason: 'One or more source roles has no final opaque support', roleCounts: counts };
  const roleErrors = sums.map((sum, i) => sum / counts[i]), backgroundErrors=backgroundSums.map((sum,i)=>sum/counts[i]),roleGains=roleErrors.map((e,i)=>backgroundErrors[i]-e);
  return { complete: true, score: jointContrastScore(roleErrors,backgroundErrors), roleErrors, backgroundErrors, roleGains,backgroundReferenceScore:0,roleCounts: counts,
    scoringScope: 'Conditional native1x empty-destination pre-fog source support; source-versus-background error improvement is not posterior probability' };
}

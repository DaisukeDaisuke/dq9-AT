import fs from 'node:fs';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const root=new URL('../',import.meta.url),report=[],hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function run(file,args=[],expectedExit=0){const p=new URL(file,root),name=file.replace(/[/.]/g,'_')+(args.length?'_'+args.join('_').replace(/[^a-zA-Z0-9_-]/g,'_'):'');const result=spawnSync(process.execPath,[p.pathname,...args],{cwd:process.cwd(),encoding:'utf8',timeout:60000});fs.writeFileSync(new URL('evidence/'+name+'.log',root),result.stdout+result.stderr);const row={file,args,exit:result.status,expectedExit,match:result.status===expectedExit,signal:result.signal};report.push(row);console.log(row);fs.writeFileSync(new URL('evidence/REGRESSIONS.json',root),JSON.stringify(report,null,2)+'\n');}
for(const name of ['capture-resources.test.mjs','capture-clock-boundary.test.mjs','classification-anchor.test.mjs','edge-binding.test.mjs','test-mounted-activation.mjs','test-activation-mounted-latest.mjs','test-pause-mounted-latest.mjs','test-mounted-tracking-factors.mjs'])run('original-tests/'+name);
// Known original overlap assertion stays failed; wrapper is already frozen.
run('original-tests/preserved-replay-suite.generated.mjs',[],1);
const canvasFix="getImageData(x,y,w,h){const data=new Uint8ClampedArray(w*h*4);for(let row=0;row<h;row++)data.set(full.subarray(((y+row)*1920+x)*4,((y+row)*1920+x+w)*4),row*w*4);return {data}}";
for(const name of ['mounted-fast-lane.test.mjs','mounted-layout-startup.test.mjs','mounted-delayed-anchor.test.mjs']){
 run('original-tests/'+name,['../integrate-measured-replay-a9f6b3fc/web',name.includes('delayed-anchor')?'handoff':'frozen-original'],0);
 run('original-tests/'+name,['web',name.includes('delayed-anchor')?'handoff':'cropped-unchanged-mock'],1);
 const originalURL=new URL('original-tests/'+name,root),source=fs.readFileSync(originalURL,'utf8'),frozenHash=hash(source);
 // A separately named conforming mock: old stub ignores all getImageData args.
 // Do not make production accept malformed returned dimensions to hide this.
 assert(source.includes('getImageData(){return {data:full.slice()}}'));
 const fixed=source.replace('getImageData(){return {data:full.slice()}}',canvasFix),newName='tests/canvas-region-'+name;
 fs.writeFileSync(new URL(newName,root),'// Separate fixture: correct getImageData rectangle semantics; original source/assertions preserved.\n'+fixed);
 run(newName,name.includes('delayed-anchor')?['web','handoff']:[]);assert.equal(hash(fs.readFileSync(originalURL)),frozenHash);
}
assert(report.every(r=>r.match),'Unexpected regression result; inspect preserved logs');

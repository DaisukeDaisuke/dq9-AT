import{collectNativeTrackingBodySupport}from'./tracking-native-body-support.mjs?v=native-motion-reacquisition-20261006-0326';
import{mapHypothesisProvenance}from'./map-browser-preview/map-hypothesis-provenance.mjs?v=enc-motion-at-20261006-1156';
// Temporal information orders hypotheses, never actor identities. Only pose is
// transported: each root is solved again from the CURRENT residual/camera/floor.
const clone=x=>structuredClone(x),finite=Number.isFinite,integer=Number.isSafeInteger;
const frame=v=>({sourceId:v?.sourceId,sourceEpoch:v?.sourceEpoch,timelineSegment:v?.timelineSegment,mediaTime:v?.mediaTime??v?.videoTime,fullRGBA_SHA256:v?.fullRGBA_SHA256});
const sameSource=(a,b)=>['sourceId','sourceEpoch','timelineSegment'].every(k=>a?.[k]===b?.[k]);
const frameValid=f=>typeof f?.sourceId==='string'&&f.sourceId.length>0&&integer(f.sourceEpoch)&&f.sourceEpoch>=0&&integer(f.timelineSegment)&&f.timelineSegment>=0&&finite(f.mediaTime)&&/^[a-f0-9]{64}$/.test(f.fullRGBA_SHA256??'');
const ownKinds=new Set(['isolated-source-opaque-binary-body-coverage','source-final-body-color-ownership']);
const poseKey=p=>JSON.stringify([p.clip,p.frame,p.actorScaleFx,p.yawFx]);
const validPose=p=>p&&typeof p.clip==='string'&&(p.clip==='bind'?p.frame===null:integer(p.frame)&&p.frame>=0)&&integer(p.actorScaleFx)&&p.actorScaleFx>0&&p.actorScaleFx<32768&&integer(p.yawFx)&&p.yawFx>=-2147483648&&p.yawFx<=2147483647;
function validOwned(v){return v?.ready===true&&v.empty===false&&ownKinds.has(v.kind)&&integer(v.pixels)&&v.pixels>0&&integer(v.knownPixels)&&v.knownPixels>0&&integer(v.unavailablePixels)&&v.unavailablePixels>=0&&v.knownPixels+v.unavailablePixels===v.pixels&&v.roi&&['x','y','w','h'].every(k=>integer(v.roi[k]))&&v.roi.w>0&&v.roi.h>0&&v.roi.x>=0&&v.roi.y>=0&&v.roi.x+v.roi.w<=256&&v.roi.y+v.roi.h<=192&&v.pixels<=v.roi.w*v.roi.h;}
const owned=v=>({ready:v.ready,empty:v.empty,kind:v.kind,pixels:v.pixels,knownPixels:v.knownPixels,unavailablePixels:v.unavailablePixels,roi:v.roi?{x:v.roi.x,y:v.roi.y,w:v.roi.w,h:v.roi.h}:null});
/** Mine only completed prior observations already retained by the real timeline.
 * Hints are limited by source/map/model bindings, not a tuned age/score cutoff. */
export function captureNativeMotionPoseHints({videoTimeline,videoEvidence,backgroundEvidence,candidates},{maximumHints=32,maximumReferencesPerHint=64}={}){
 if(![maximumHints,maximumReferencesPerHint].every(n=>integer(n)&&n>0))throw Error('Positive temporal pose storage budgets required');
 const current=frame(videoEvidence),romSHA256=backgroundEvidence?.romSHA256,diagnostics={schema:'prior-native-pose-capture-v1',priorObservations:0,positiveBoundAlternatives:0,incompatibleSourceOrMapOrModel:0,omittedHints:0,omittedReferences:0,maximumHints,maximumReferencesPerHint,currentActorIdentityCertified:false,oldWorldRootReused:false,minimumProvenATCalls:0};
 const result=(hints=[],reason=null)=>({hints:hints.length?{schema:'prior-owned-native-pose-hints-v1',romSHA256,currentFrame:current,hints,oldWorldRootReused:false,currentActorIdentityCertified:false,minimumProvenATCalls:0}:null,diagnostics:{...diagnostics,retainedHints:hints.length,reason}});
 if(!frameValid(current)||!/^[a-f0-9]{64}$/.test(romSHA256??''))return result([],'current-frame-or-ROM-binding-unavailable');
 const support=backgroundEvidence.backgroundBranchSupport,branches=support?.ready===true?support.branches??[]:[],records=new Set(branches.filter(b=>b.romSHA256===romSHA256&&b.fullRGBA_SHA256===current.fullRGBA_SHA256).map(b=>b.recordKey));
 if(!records.size&&backgroundEvidence.automaticSearch?.acceptedCount===1&&sameSource(frame(backgroundEvidence.automaticSearch.inputFrame),current)&&frame(backgroundEvidence.automaticSearch.inputFrame).mediaTime===current.mediaTime&&frame(backgroundEvidence.automaticSearch.inputFrame).fullRGBA_SHA256===current.fullRGBA_SHA256)records.add(backgroundEvidence.recordKey);
 if(support?.ready===true&&JSON.stringify(frame(support.frame))!==JSON.stringify(current))return result([],'current-background-frame-binding-differs');
 const models=new Set((candidates??[]).map(c=>JSON.stringify([c.modelId,c.variant]))),rows=[];
 for(const f of videoTimeline?.frames??[]){const source=frame(f.stamp);if(!frameValid(source)||!sameSource(source,current)||source.mediaTime>=current.mediaTime||f.romSHA256!==romSHA256)continue;for(const s of f.sightings??[])rows.push({s,plan:f.modelPlan,mapProvenance:mapHypothesisProvenance(f)});}
 diagnostics.priorObservations=rows.length;const observations=collectNativeTrackingBodySupport(rows).observations.sort((a,b)=>b.sourcePTS-a.sourcePTS||a.sightingId.localeCompare(b.sightingId)),groups=new Map();
 for(const o of observations)for(const a of o.alternatives){
  if(a.binding?.ready!==true||!finite(a.ownGain)||a.ownGain<=0||!validOwned(a.extent?.bodyColorOwnership)||!validPose(a.pose))continue;diagnostics.positiveBoundAlternatives++;
  if(o.frame?.romSHA256!==romSHA256||!sameSource(o.frame,current)||o.sourcePTS>=current.mediaTime||!records.has(a.recordKey)||!models.has(JSON.stringify([a.modelId,a.variant]))){diagnostics.incompatibleSourceOrMapOrModel++;continue;}
  const key=JSON.stringify([a.recordKey,a.modelId,a.variant,poseKey(a.pose)]);
  if(!groups.has(key)){if(groups.size>=maximumHints){diagnostics.omittedHints++;continue;}groups.set(key,{recordKey:a.recordKey,modelId:a.modelId,variant:a.variant,pose:clone(a.pose),references:[],unknownOtherPosesPossible:true});}
  const hint=groups.get(key);if(hint.references.length>=maximumReferencesPerHint){diagnostics.omittedReferences++;continue;}
  hint.references.push({recordKey:a.recordKey,modelId:a.modelId,variant:a.variant,pose:clone(a.pose),sightingId:o.sightingId,frameKey:o.frameKey,frame:clone(o.frame),originalProposalId:o.originalProposalId,branchId:a.branchId,proposalId:a.proposalId,ownGain:a.ownGain,bodyColorOwnership:owned(a.extent.bodyColorOwnership)});
 }
 return result([...groups.values()],groups.size?null:'no-compatible-positive-prior-owned-body-pose');
}
/** Whitelist transport; no old root, full native pixels or caller metadata. */
export function projectNativeMotionPoseHints(value){
 if(!value)return undefined;
 return{schema:value.schema,romSHA256:value.romSHA256,currentFrame:frame(value.currentFrame),...(!Array.isArray(value.hints)?{malformedHintShape:true}:{}),hints:(Array.isArray(value.hints)?value.hints:[]).map(raw=>{const h=raw??{};return{recordKey:h.recordKey,modelId:h.modelId,variant:h.variant,pose:h.pose?{clip:h.pose.clip,frame:h.pose.frame,actorScaleFx:h.pose.actorScaleFx,yawFx:h.pose.yawFx}:null,references:(Array.isArray(h.references)?h.references:[]).map(raw=>{const r=raw??{};return{recordKey:r.recordKey,modelId:r.modelId,variant:r.variant,pose:r.pose?{clip:r.pose.clip,frame:r.pose.frame,actorScaleFx:r.pose.actorScaleFx,yawFx:r.pose.yawFx}:null,sightingId:r.sightingId,frameKey:r.frameKey,frame:{romSHA256:r.frame?.romSHA256,...frame(r.frame)},originalProposalId:r.originalProposalId,branchId:r.branchId,proposalId:r.proposalId,ownGain:r.ownGain,bodyColorOwnership:r.bodyColorOwnership?owned(r.bodyColorOwnership):null};})};}),oldWorldRootReused:false,currentActorIdentityCertified:false,minimumProvenATCalls:0};
}
export function readNativeMotionPoseHints(value,{videoEvidence,romSHA256,recordKey,modelId,variant,animations,scales,referencePose}){
 const current=frame(videoEvidence),out={ready:false,hints:[],rejected:[],currentActorIdentityCertified:false,oldWorldRootReused:false,source:'prior-positive-owned-native-pose-reacquisition'};
 if(!value)return out;
 if(value.schema!=='prior-owned-native-pose-hints-v1'||value.romSHA256!==romSHA256||!frameValid(current)||JSON.stringify(frame(value.currentFrame))!==JSON.stringify(current)){out.rejected.push({reason:'temporal-pose-current-frame-binding-differs'});return out;}
 if(!Array.isArray(value.hints)||value.malformedHintShape===true){out.rejected.push({reason:'temporal-pose-hints-array-unavailable'});return out;}
 for(const h of value.hints){
  if(!h||typeof h!=='object'){out.rejected.push({reason:'temporal-pose-hint-record-unavailable'});continue;}
  if(h.recordKey!==recordKey||h.modelId!==modelId||h.variant!==variant)continue;
  let reason=null;const p=h.pose;
  if(!validPose(p))reason='invalid-source-pose';
  else if(p.clip!=='bind'&&(!animations.has(p.clip)||p.frame>=animations.get(p.clip).numFrames))reason='pose-outside-ROM-animation';
  else if(!scales.includes(p.actorScaleFx))reason='prior-scale-not-in-current-ROM-source-domain';
  if(reason){out.rejected.push({recordKey,modelId,pose:clone(p),reason});continue;}
  const refs=(Array.isArray(h.references)?h.references:[]).filter(r=>r&&r.recordKey===recordKey&&r.modelId===modelId&&r.variant===variant&&validPose(r.pose)&&poseKey(r.pose)===poseKey(p)&&r.frame?.romSHA256===romSHA256&&frameValid(r.frame)&&sameSource(r.frame,current)&&r.frame.mediaTime<current.mediaTime&&typeof r.sightingId==='string'&&typeof r.frameKey==='string'&&typeof r.branchId==='string'&&typeof r.proposalId==='string'&&finite(r.ownGain)&&r.ownGain>0&&validOwned(r.bodyColorOwnership));
  if(!refs.length)reason??='prior-positive-owned-frame-binding-unavailable';
  if(reason){out.rejected.push({recordKey,modelId,pose:clone(p),reason});continue;}
  // A pose already first in the same-frame reference pass needs no second try.
  if(referencePose?.ready&&referencePose.clip===p.clip&&referencePose.frame===p.frame&&referencePose.yawFx===p.yawFx)continue;
  if(out.hints.some(x=>poseKey(x.pose)===poseKey(p)))continue;
  out.hints.push({pose:clone(p),references:clone(refs),rootPolicy:'re-solve-from-current-residual-camera-and-ROM-floor',unknownInterveningMovement:true,currentActorIdentityCertified:false});
 }
 out.ready=out.hints.length>0;return out;
}

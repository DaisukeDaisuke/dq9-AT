# Camera-conditioned body alternative: isolated consumer integration

Task UUID: f9c93595-ac1c-44b2-bd41-910caf9df213. Baseline main: 27b7c542657362544083483a11dbc64f34f5be0e; the subsequent 85fa archive-only publication did not change this web baseline. No root production files or Git state were modified by this worker.

## Implemented result

Five source files connect completed same-frame ROM body support to the existing video tracking controller and actual AT kernel. The original normalized-thumbnail prediction is unchanged. The new path automatically schedules a separate hypothetical singleton only after independently validating the entire retained camera/model domain, owned body evidence, frame identity and exact enc relation. A repeated sighting of the same tentative track remains one possible latent selection, never another independent draw.

The compact attachment references full evidence owned by the same sighting. It does not assume a missing camera/model was tested. The controller reconstructs all retained cameras from that sighting's background provenance, resolves each exact source support reference, and recomputes the comparison. Mutations or missing/stale evidence defer the optional alternative. Legacy unknown/error/player/background possibilities remain; the compiler's no-event unknown branch remains unconstrained. No current state or event order is inferred.

Metadata explicitly says certifiedObservation:false and conditionalHypothesisOnly:true. Automatic hypothetical scheduling is allowed; no hard/current-state constraint, identity certification or all-input claim is made. These metadata/comment clarifications affect only this integration copy. The prior frozen checkpoint ZIP remains immutable, and comparison gates are unchanged.

## Five files

See FIVE_FILE_MANIFEST.json for full baseline and candidate hashes.

- web/monster-camera-body-alternative.mjs: existing frozen comparison plus accurate live scheduling metadata/comments.
- web/tracking-camera-body-alternative.mjs: existing frozen exact-enc singleton producer plus accurate scheduling metadata/comments.
- web/monster-native-extent-evidence.mjs: frozen rank/nondegeneracy ownership fields, unchanged from frozen candidate.
- web/map-browser-preview/residual-native-support.mjs: separate compact source-bound attachment after original support processing.
- web/map-browser-preview/video-tracking-at.mjs: independent consumer recomputation, separate singleton append, cancellation epoch guard immediately before session creation.

All other 378 web files match baseline byte-for-byte. Existing production input guards remain. The current integration contains no DST/RAM truth reader or adapter.

## Current integration evidence

All five test programs passed after final metadata changes.

- Producer: all 32 c28 regions; only residual12/z019b gains the separate alternative; stripping the new field gives the exact prior bundle. Six missing/stale-domain cases remain unknown. Full unsupported records remain owned in their original fields.
- Consumer: 18 mutations rejected before preparation/session start, including claim/ref/owned-score/frame/domain/species/unknown/certification changes and existing debug/RAM input guards.
- Cancellation: cancellation or source supersession during WASM loading starts no session. Synchronous cancellation from the running-state callback also starts no session.
- Actual mounted-preview controller implementation + actual WASM: saved c28 starts one conditional table30/species31 branch with no manual options, plus the unchanged unconstrained unknown branch. Independent enumeration finds 10,241 permitted 15-bit outputs, giving 671,154,176 conditional low31 event classes. No current-state recovery/global narrowing. Retry reuses ACK without duplicate write.
- Actual legacy1200 input + actual WASM: baseline and candidate requests, identity, checkpoint key and final summary are identical. Both request hashes are 7f30fed46ddd9942cde54b5e6b32f773f034bd017031a176683f0245f299e772.
- Two repeated c28 sightings on the same tentative track yield one branch with one event, shared latent binding, and zero order edges.

Test boundary: Node calls the actual createVideoTrackingAT controller used by the mounted preview and the actual runner/WASM. Worker transport and IndexedDB are replaced with a Node runner and in-memory ACK store. No live browser DOM, Worker transport or IndexedDB interaction was executed. Appearance scores are saved fixed observations; this test does not perform fresh DINO inference or a new exhaustive pose search.

## Preserved earlier fixed-frame results and limitations

The frozen candidate's five fixed frames contain 125 regions and 803 current-renderer proposal replays; all 803 gains equal saved gains. Only c28 residual12 has the new alternative. The 1200/4200/2355/3300 frames produce no new alternative. Legacy positive1200 and existing false predictions in4200/3300 remain unchanged. The 446 missing retained best-proposal recipes remain explicit absent evidence, not failed current renders. Full summary is REFERENCE_FIVE_FRAME_RESULTS.json. These results are not general recognition completeness or species calibration.

Failed camera substitution, integer-thumbnail substitution, and expanded stored-pose thumbnail experiments remain preserved in the earlier frozen source/private checkpoint. None was promoted. Current integration does not alter renderer ranking thresholds or use private native state.

## Failures found and retained

1. Initial controller test incorrectly expected raw tableSpeciesAlternatives on a compiled event; compilation stores masks and eventEvidence. The test was corrected to validate the sourceEvidence branch pair joins. FIRST_CONTROLLER_TEST_FAILURE.log is preserved privately.
2. Initial cancellation test exposed an existing synchronous onState cancellation hole: a stale session could start immediately after the callback. Added a one-line epoch guard before session creation. FIRST_CANCELLATION_FAILURE.json and cancellation-first.log remain preserved privately; all three final cases pass.
3. Earlier standalone frozen AT consumer evidence established compilation/branch preservation, but supplied enc.json at its root rather than .main and did not prove runnable kernel execution. Current actual-WASM tests use .main and establish kernel execution.

No expected test failures remain among the reported tests. A full repository-wide test suite and live browser end-to-end run were not performed here. Parent owns independent validation, integration, publication and activation.

## Privacy

The source archive contains only the five sources, scripts/tests, manifests, patch, this report and non-pixel aggregate summaries. No ROM, DST, RAM, raw video pixels, extracted game assets or ACK/source vectors are included. Private evidence is a separate archive and must not be committed or published.

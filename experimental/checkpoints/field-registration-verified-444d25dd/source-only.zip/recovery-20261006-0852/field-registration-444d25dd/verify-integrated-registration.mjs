import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {openMapRom} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/static-scene.mjs';
import {buildRomMapCatalog} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/rom-map-catalog.mjs';
import {MapRenderer} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/minimap-preview.mjs';
import {MapPositionMatcher} from '../../integrate-field-registration-444d25dd/web/map-position.mjs';
import {deriveVideoPlayerMapInput} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/video-player-map-input.mjs';
import {loadRomFloorInstances} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/rom-floor-candidates.mjs';
import {planRomScene} from '../../integrate-field-registration-444d25dd/web/map-browser-preview/rom-scene-plan.mjs';
const out=new URL('.',import.meta.url),rom=await fs.readFile(new URL('../verified/dq9_new2.nds',out)),wasm=await fs.readFile(new URL('../../integrate-field-registration-444d25dd/web/wasm/map_render.wasm',out)),{instance}=await WebAssembly.instantiate(wasm),renderer=new MapRenderer(instance),project=openMapRom(rom),catalog=buildRomMapCatalog(project),matcher=new MapPositionMatcher(instance),results=[];
const maps=[7401,7402].map(mapId=>{const record=catalog.maps.find(r=>r.mapId===mapId);return {mapId,record,floors:loadRomFloorInstances(project,planRomScene(project,record))};});
for(const sec of process.argv.slice(2)){
 const rgba=await fs.readFile(new URL(`field${sec}.rgba`,out)),sourceImage={width:1920,height:1080,rgba},frameEvidence={fullRGBA_SHA256:createHash('sha256').update(rgba).digest('hex'),sourcePTS:Number(sec),source:'independent-ffmpeg-decode-not-retained-browser-frame'},runs=[];
 for(const {mapId,record,floors}of maps)for(const descriptor of record.minimapCandidates){
  const path=descriptor.path,mapImage=renderer.compose(catalog.minimap,path),started=performance.now(),result=deriveVideoPlayerMapInput({sourceImage,layout:'obs-side-1920',mapImage,mapId,matcher,floors,frameEvidence}),elapsedMilliseconds=performance.now()-started;
  const {upper,...evidence}=result;runs.push({mapId,path,evidence,elapsedMilliseconds});
 }
 results.push({sec,frameEvidence,runs});console.log(JSON.stringify({sec,runs:runs.map(r=>({mapId:r.mapId,path:r.path,elapsedMilliseconds:r.elapsedMilliseconds,status:r.evidence.status,initialBest:r.evidence.registration.fallback?.initialRegistration.best,registration:{resolved:r.evidence.registration.resolved,best:r.evidence.registration.best,margin:r.evidence.registration.margin,search:r.evidence.registration.search},primaryWorld:r.evidence.primaryCandidate?.world,primaryFloors:r.evidence.primaryCandidate?.floor.heightsFx,worldPositionKnown:r.evidence.worldPositionKnown,playerIdentityProven:r.evidence.playerIdentityProven,minimumProvenATCalls:r.evidence.minimumProvenATCalls}))}));
}
await fs.writeFile(new URL('../../integrate-field-registration-444d25dd/validation/actual-frames.json',out),JSON.stringify({wasmSHA256:createHash('sha256').update(wasm).digest('hex'),romSHA256:createHash('sha256').update(rom).digest('hex'),sourceCommit:'de68aef82e31e707da2f039dce009c6865ad7c4d',scope:'Independent ffmpeg decoded formal-video frames, not original browser pixels; no name OCR rerun, full background rendering or all-input claim. Existing ROM floor candidates loaded.',results},null,2));

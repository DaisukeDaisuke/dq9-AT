// Isolated shadow: forward need not be the unique best. A verified candidate
// still needs its own unique independent reverse best at the exact inverse.
import{IMAGE_TRANSLATION_LIMITS as L,PROPOSAL_LIMITS}from'../../../replay-lane-ce87377/web/monster-position-proposals.mjs';
import{videoTrackingSourceKey}from'../../../replay-lane-ce87377/web/map-browser-preview/video-patch-correspondence.mjs';
const W=256,H=192,finite=Number.isFinite;
// Original even-grid search has(radius+1)^2 costs, then at most8 new fine costs.
export const SINGLE_WINNER_COST_CEILING=2*((L.radius+1)**2+8);
export function createCorrespondenceBudget(maximum=SINGLE_WINNER_COST_CEILING){if(!Number.isSafeInteger(maximum)||maximum<1)throw Error('Positive bounded cost budget required');return{maximum,used:0,searches:0,completedSearches:0,omittedSearches:0};}
function search(previous,current,roi,budget){
 const r={x:Math.round(roi.x),y:Math.round(roi.y),w:Math.round(roi.w),h:Math.round(roi.h)},costs=new Map(),fail=reason=>({ready:false,reason,roi:r,costs,testedSearchComplete:false});budget.searches++;
 if(![r.x,r.y,r.w,r.h].every(finite)||r.w<=0||r.h<=0)return fail('patch-bounds-unavailable');
 const stride=Math.max(1,Math.ceil(Math.sqrt(r.w*r.h/1024))),samples=[];let texture=0,textureCount=0;
 for(let y=Math.max(0,r.y);y<Math.min(H,r.y+r.h);y+=stride)for(let x=Math.max(0,r.x);x<Math.min(W,r.x+r.w);x+=stride){const i=y*W+x;if(previous.blocked[i])continue;samples.push(i);if(x+1<Math.min(W,r.x+r.w)&&!previous.blocked[i+1]){texture+=Math.abs(previous.gray[i]-previous.gray[i+1]);textureCount++;}if(y+1<Math.min(H,r.y+r.h)&&!previous.blocked[i+W]){texture+=Math.abs(previous.gray[i]-previous.gray[i+W]);textureCount++;}}
 texture=textureCount?texture/textureCount:0;if(samples.length<L.minimumSamples)return fail('insufficient-known-patch-samples');if(texture<L.minimumTexture)return fail('patch-texture-unresolved');
 function cost(dx,dy){const k=dx+','+dy;if(costs.has(k))return costs.get(k).residual;if(budget.used===budget.maximum)throw 'cost-budget-exhausted';budget.used++;let sum=0,count=0,offset=dy*W+dx;for(const i of samples){const x=i%W+dx,y=Math.floor(i/W)+dy;if(x<0||x>=W||y<0||y>=H||current.blocked[i+offset])continue;sum+=Math.min(L.residualClip,Math.abs(previous.gray[i]-current.gray[i+offset]));count++;}const residual=count>=L.minimumSamples?sum/count:Infinity;costs.set(k,{dx,dy,residual,knownSamples:count});return residual;}
 let best;
 try{best={dx:0,dy:0,residual:cost(0,0)};for(let dy=-L.radius;dy<=L.radius;dy+=2)for(let dx=-L.radius;dx<=L.radius;dx+=2){const residual=cost(dx,dy);if(residual<best.residual)best={dx,dy,residual};}const rough={...best};for(let dy=Math.max(-L.radius,rough.dy-1);dy<=Math.min(L.radius,rough.dy+1);dy++)for(let dx=Math.max(-L.radius,rough.dx-1);dx<=Math.min(L.radius,rough.dx+1);dx++){const residual=cost(dx,dy);if(residual<best.residual)best={dx,dy,residual};}}
 catch(error){if(error!=='cost-budget-exhausted')throw error;budget.omittedSearches++;return{...fail(error),texture,samples:samples.length};}
 budget.completedSearches++;const common={roi:r,costs,texture,samples:samples.length,testedSearchComplete:true,best};
 if(!finite(best.residual)||best.residual>L.maximumResidual||Math.abs(best.dx)>=L.radius||Math.abs(best.dy)>=L.radius)return{ready:false,reason:'patch-registration-outside-existing-gates',...common};
 if([...costs.values()].filter(v=>v.residual===best.residual).length!==1)return{ready:false,reason:'patch-registration-tied',...common};
 return{ready:true,...common};
}
export function enumerateVideoPatchCorrespondences(previous,current,roi,{budget=createCorrespondenceBudget()}={}){
 const dt=(current.stamp.mediaTime??current.stamp.videoTime)-(previous.stamp.mediaTime??previous.stamp.videoTime),no=reason=>({ready:false,reason,candidates:[],unknown:true,identityCertified:false});
 if(videoTrackingSourceKey(previous.stamp)!==videoTrackingSourceKey(current.stamp))return no('source-identity-changed');if(!(dt>0&&dt<=PROPOSAL_LIMITS.maxGapSeconds))return no('unobserved-time-gap');
 const before=budget.used,forward=search(previous,current,roi,budget),candidates=[],tested=[...forward.costs.values()].filter(c=>finite(c.residual)&&c.residual<=L.maximumResidual&&Math.abs(c.dx)<L.radius&&Math.abs(c.dy)<L.radius);
 // Verification order preserves the original best first, followed by score
 // order. Order allocates bounded work only; it never chooses an accepted ROI.
 tested.sort((a,b)=>a.residual-b.residual||a.dy-b.dy||a.dx-b.dx);
 for(const c of tested){const translated={...forward.roi,x:forward.roi.x+c.dx,y:forward.roi.y+c.dy},entry={...c,roi:translated,forwardTexture:forward.texture,forwardSamples:forward.samples,reverseStatus:'unverified-budget',verifiedReciprocal:false};
  if(budget.used<budget.maximum){const reverse=search(current,previous,translated,budget);entry.reverse={ready:reverse.ready,reason:reverse.reason??null,texture:reverse.texture,samples:reverse.samples,testedSearchComplete:reverse.testedSearchComplete,best:reverse.best??null};if(reverse.testedSearchComplete){if(reverse.ready&&reverse.best.dx===-c.dx&&reverse.best.dy===-c.dy){entry.reverseStatus='unique-independent-reverse-exact';entry.verifiedReciprocal=true;}else entry.reverseStatus=reverse.reason==='patch-registration-tied'?'ambiguous-independent-reverse-tie':'failed-independent-reverse';}}
  else budget.omittedSearches++;
  candidates.push(entry);
 }
 return{ready:candidates.length>0,candidates,forward:{reason:forward.reason??null,testedOffsets:forward.costs.size,testedSearchComplete:forward.testedSearchComplete,best:forward.best??null},costEvaluations:budget.used-before,unknown:true,unsearchedOffsetsPossible:true,unverifiedCandidates:candidates.filter(c=>c.reverseStatus==='unverified-budget'||c.reverseStatus==='ambiguous-independent-reverse-tie').length,criterionChange:'Forward numeric feasibility instead of unique forward best; unique independent reverse best and exact inverse remain required for verified paths',identityCertified:false,birthCertified:false,absenceCertified:false,minimumProvenATCalls:0};
}

// Yield only between deterministic work units. Time changes scheduling, not search.
export function hudAbort(reason='HUD task superseded'){return new DOMException(reason,'AbortError');}
export function createHudCooperativeBudget({budgetMs=8,yieldTask=()=>new Promise(resolve=>setTimeout(resolve,0)),now=()=>performance.now(),isCurrent=()=>true,onSlice=()=>{}}={}){
 if(!Number.isFinite(budgetMs)||budgetMs<=0||typeof yieldTask!=='function')throw Error('Invalid cooperative HUD scheduler');let start=now(),maxSliceMs=0,yields=0,checks=0,totalActiveMs=0;
 const valid=()=>{if(!isCurrent())throw hudAbort();};
 const mark=()=>{const duration=now()-start;maxSliceMs=Math.max(maxSliceMs,duration);totalActiveMs+=duration;onSlice({durationMs:duration,checks,yields});return duration;};
 return{async checkpoint(force=false){valid();checks++;if(!force&&now()-start<budgetMs)return;mark();yields++;await yieldTask();valid();start=now();},assertCurrent:valid,finish(){valid();mark();return{budgetMs,maxSliceMs,yields,checks,totalActiveMs,sliceScope:'Elapsed scheduler slice, including async waits between checkpoints; not a CPU profile'};}};
}

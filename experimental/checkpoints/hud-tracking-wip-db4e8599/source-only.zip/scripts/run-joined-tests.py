from pathlib import Path
import subprocess,json,time,hashlib
r=Path('merge-hud-measured-tracking-db4e8599');cases=[]
for n in ['capture-resources','edge-binding','capture-clock-boundary','classification-anchor','mounted-fast-lane','mounted-layout-startup']:
 cases.append((n,['node',str(r/'tests'/f'{n}.test.mjs')],0))
cases.append(('mounted-delayed-anchor',['node',str(r/'tests/mounted-delayed-anchor.test.mjs'),'web','HANDOFF'],0))
for n in ['test-mounted-activation','test-activation-mounted-latest','test-pause-mounted-latest','test-mounted-tracking-factors']:
 cases.append((n,['node',str(r/'tests'/f'{n}.mjs')],0))
cases.append(('preserved-replay',['node',str(r/'tests/run-preserved-replay-suite.mjs')],1))
for n in ['hud-classification-anchor','mounted-hud-tracking']:
 cases.append((n,['node',str(r/'tests'/f'{n}.test.mjs')],0))
for n in ['cooperative-equivalence','connection.test','mounted-hud.test','legacy-mounted-latest','legacy-mounted-activation']:
 cases.append(('hud-'+n,['node',str(r/'tests-hud'/f'{n}.mjs')],0))
cases.append(('five-frame-anchors',['node',str(r/'scripts/check-five-frame-anchors.mjs')],0))
cases.append(('HUD-counterfactual-controls',['node',str(r/'scripts/check-shadow-controls.mjs')],0))
cases.append(('primary-preview-entry',['node','--experimental-vm-modules',str(r/'tests/preview-entry-hud.test.mjs')],0))
for n in ['test-producer','test-consumer-guards','test-real-controller','test-legacy-and-repeat','test-cancellation']:
 cases.append(('camera-'+n,['node',str(r/'tests-camera'/f'{n}.mjs')],0))
rows=[]
for name,cmd,expected in cases:
 start=time.monotonic();p=subprocess.run(cmd,text=True,capture_output=True);log=r/'private-evidence'/('FINAL_'+name+'.log');log.write_text(p.stdout+'\nSTDERR\n'+p.stderr);row={'name':name,'command':cmd,'exit':p.returncode,'expectedExit':expected,'matchedExpectedOutcome':p.returncode==expected,'elapsedSeconds':time.monotonic()-start,'logSHA256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);print(json.dumps(row),flush=True)
 (r/'JOINED_TEST_RESULTS.json').write_text(json.dumps({'runs':rows,'allMatchedExpectedOutcome':all(x['matchedExpectedOutcome'] for x in rows),'expectedKnownFailure':'Original overlapping duplicate replay assertion remains expected0/actual1; no thresholds/input/assertions changed.'},indent=2)+'\n')
 if p.returncode!=expected:print(p.stdout[-4000:]+p.stderr[-4000:],flush=True);raise SystemExit(1)

# Conditional ROM-HUD exclusion shadow branch

Task UUID:71574e03-06a7-4df6-b7b1-0505aaf27760, generated with Python uuid.uuid4(). This is a new isolated directory. The preceding archive remains byte-identical: `ROM_COMMAND_OVERLAY_SOURCE.zip`, SHA256 `0fc416a24ac42f65ea5cd9dd802af2e2da5992787e81b54162f3dc950bb12c5b`. No production files, Git state or published assets were changed.

## Result

The source-derived HUD detector now drives a **conditional proposal branch**. At actual4200 it removes raw HUD components0 and2, totaling254 residual pixels, and reduces49 proposals to47. Actual mallet/body fragments25 and34 are unchanged, as are the saved1200 region58 and3300 regions120/131 body hypotheses. This is a useful provisional recognition change, not a verified world identity or proof of AT absence.

The original raw mask, region records and IDs remain in a separate branch. No observation bundle, tracker, encounter decision or AT compiler was modified. The new branch explicitly carries `conditional:true`, `pixelOwnershipCertified:false`, `absenceCertified:false`, no-event/unknown alternatives, and zero certified AT events. No production enablement is recommended without parent review.

## Unchanged detector and gate

The prior runtime ROM loader, source shapes, full-scene search and synthetic calibration are copied unchanged. `icon.nsarc → wing1.spr` supplies the source347-pixel opaque support. The threshold remains0.6937063578643885, generated from486 synthetic positives/66 negatives before the previous five-frame robust evaluation. The factory recalibrates from its own loaded ROM; no user-entered parameter JSON is required.

The conditional mask applies only when:

1. The full-scene matcher has exactly one distinct above-threshold match
2. Its placement agrees with the independently decoded ROM ordinary default layout
3. The ROM, frozen native pixel hash, source epoch, segment, time and current-frame checks all agree

Only source-alpha opaque support is conditionally removed. No32×32 rectangle, tuned dilation or new score threshold is used. Missing/ambiguous/unsupported-layout matches keep the branch unmasked. The detector does not reliably reject every tiny occlusion; that limitation is measured below.

## Raw and conditional provenance

`createConditionalHudProposer(romInputs)` privately owns its source and calibration. Returned metadata mutations cannot change its decisions. `infer` accepts the frozen256×192 RGBA image, full raw residual mask, complete original region domain, frame identity and current-frame callback.

The result contains:

- `raw.regions` and `raw.residualMask`: unchanged copies
- `conditionalWorld.residualMask`, `excludedResidualMask` and `conditionalOverlaySupportMask`: separate hypothesis buffers
- A per-parent ledger of excluded/retained pixels and remaining proposal IDs
- Raw/excluded-mask hashes and a conditional branch key including frame, ROM member, calibration and mask identity
- Explicit lack of body identity, pixel-ownership, absence or AT certification

The Otsu threshold is not recomputed. The component labels are reconstructed and validated against every original region before subtraction. Bounding-box overlap is never mistaken for component pixel membership.

## Parent-preserving remainder policy

The first implementation reconnected all surviving pixels and created a new proposal for each disconnected part. It caused3300's247 proposals to grow to251: the HUD's five remaining fringe pixels became five one-pixel proposals. That result and source are frozen in `CONNECTED_REMAINDER_RESULTS.json` and `baseline/conditional-hud-residual-connected.mjs`.

The final implementation keeps each surviving original parent ID. It recomputes the remaining bounds, count and sparse mask and records every disconnected part as diagnostic data, without creating extra queue slots. It does **not** assume one parent is one connected object or actor.

Every changed surviving parent has `classificationReuseAllowed:false` and `classificationEligible:false`. The existing ROI-only consumer does not implement this sparse conditional mask, so these parents remain uncomputed unknown. Unchanged parents retain their original records exactly. A production consumer must not reapply an old classification to a changed parent merely because its numeric ID survived.

## Five actual frames

| Frame | Raw→final parent proposals | Conditional pixels excluded | Fully filtered raw IDs | Changed parents retained unknown |
|---|---:|---:|---|---|
|4200|49→47|254|0,2|none|
|1200|268→262|286|2,15,14,16,11,17|13:1px;18:1px|
|c28|716→714|284|33,75|70:523px|
|2355|283→282|281|1|0:2px in2 disconnected parts|
|3300|247→247|347|none|24:5px in5 disconnected parts|

-4200's frozen false z038a prediction at region2 has no world proposal in the conditional branch. The original raw false prediction remains preserved. Region0 is also filtered, including the raw0 UI witness reported by the independent sampling investigation; no new classifier pass is claimed here.
-4200 fragments25/34 are unchanged, including their old false z038a classifications. This HUD change does not solve their body/appearance problem.
-1200's saved z061c region58 and3300's saved z002b regions120/131 are unchanged. These are retained conditional classifier hypotheses, not an exhaustive ground-truth body set.
-c28 region70 retains523 of585 pixels. Its62 UI-overlapping pixels are subtracted only within this hypothesis; its original585-pixel raw region is still available. The retained523-pixel sparse region is held unknown rather than discarded.
-Fringe misses remain visible. No radius/threshold was added to erase the last2/5 pixels in2355/3300.

No known body sample above loses pixels. There is no exhaustive labelled body corpus, so a universal body-recall figure is not claimed. All raw/no-event/unknown data remain available; these numbers describe the separate conditional queue, not irreversible evidence deletion.

## Queue/budget effects

The saved3×3 automatic size policy and budget32 were replayed unchanged. The old requested queues reproduce exactly. Only unchanged parents are ready for the current ROI-only classifier; changed parents are listed as unknown.

| Frame | Old→ready requests | Removed old queue IDs | Newly within budget |
|---|---:|---|---|
|4200|10→8|0,2|none|
|1200|22→19|18,2,15|none|
|c28|32→32|70,33,75|0,706,371|
|2355|29→28|0|none|
|3300|32→32|24|28|

Newly available slots are not new detections. No new DINO/native-body calls or downstream identity decisions were run. This readiness comparison cannot substitute for a sparse-mask-aware classifier integration.

## Controls and preserved failures

60 counterfactual cases across five actual frames pass351 explicit outcome/preservation checks. Their original residual domain is reused to isolate the conditional branch; these are not full end-to-end residual re-extractions after editing pixels.

- Five absent replacements,30 quarter/half occlusions and five clipped copies stay unmasked
- Five duplicate copies stay ambiguous and unmasked
- Five uniquely detected off-layout copies stay unmasked
- Blurred4200 has a second false background match at(17,95), score0.7027964285, and the branch stays unmasked
- The other four additionally blurred frames retain the same conditional HUD branch
- **All five one-pixel-occlusion controls still apply the branch and remove the altered residual pixel.** This is a real conditional false-exclusion risk, preserved rather than hidden. Recognition may tolerate that variation; complete ownership is not certified

A further3,219 assertions validate the five complete domains, exact unchanged-parent retention, mask/ledger accounting, sparse remainder runs, no proposal-count growth, stale/malformed input rejection and immutable private source/calibration behavior. These assertion counts include many per-region invariants; they are not thousands of independent videos.

## Real runtime cost

This must not run on the10Hz fast-capture path.

The initial native256×192 measurement gave204–231ms per frame, median219ms, with535ms one-time source loading/calibration. It is retained in `BENCHMARK_PRE_PROVENANCE_HASH.json`.

The final source-hashed benchmark, including the provenance hashes, measured15 runs over the five native frames:

-200.8–220.6ms per frame, median209.6ms, mean211.6ms
-One-time ROM-bound factory/calibration484.1ms, separate from553.5ms fixture/ROM adapter preparation
-Sampled factory retention after GC:240,064 bytes JS heap and361,142 bytes array buffers; RSS grew19,922,944 bytes including JIT/runtime effects
-Per-frame endpoint allocation deltas:3.55–21.13MB JS heap and0.20–0.64MB array buffers
-Whole-process maximum RSS814,620KiB includes formal ROM loading and large fixture JSON parsing. It is not the detector's isolated memory requirement

These are Node measurements on this executor, not browser/mobile guarantees. Memory values are endpoint samples, not isolated per-call peaks. The factory/calibration must be cached once per ROM; inference belongs on the existing full-analysis cadence with source cancellation and backpressure, preferably off the UI thread. No detector optimization or tolerance change was performed.

## Minimal integration touchpoints for parent review

1. `gpu-file-preview.mjs` ROM lifecycle: create/release one proposer from the already-loaded ROM filesystem/SDK and overlay17. Do not run calibration per frame. Its current `openMapRom` load at line48 and `mountMapVideoComparison` setup at line37 are the ownership boundary.
2. `map-video-comparison.mjs` full-analysis path: after the frozen comparison at line150, compute the shadow result under existing frame/epoch cancellation. Keep the original `comparison.components`, record, raw tracking and observation branch unchanged. Do not add this to the fast capture/provisional marker loop.
3. Candidate view/selection: show the conditional branch separately. Use parent IDs plus the conditional branch key. Keep changed sparse/disconnected parents visibly unknown; current `annotateResidualRegions` assumes contiguous fresh component IDs and must not be called on these parent-preserved IDs as if they were a raw component scan.
4. Only if recognition integration is explicitly chosen: `residual-recognition-job.mjs` / `residual-recognition-input.mjs` need branch identity in requests/cache keys and a defined policy for the conditional sparse mask. Current ROI-only requests cannot safely reuse changed-parent classifications. Carry raw versus conditional provenance through display/export; do not route a filtered absence into the AT compiler.

The minimal safe first integration is a full-analysis shadow/candidate view. No production enablement was made here.

## Reproduce

From the workspace root, with the same private formal ROM and frozen fixtures already available:

    node shadow-rom-hud-exclusion-71574e03/tests/conditional-hud.test.mjs
    node shadow-rom-hud-exclusion-71574e03/scripts/replay-shadow.mjs
    node shadow-rom-hud-exclusion-71574e03/scripts/check-shadow-controls.mjs
    node shadow-rom-hud-exclusion-71574e03/scripts/check-shadow-budget.mjs
    node --expose-gc shadow-rom-hud-exclusion-71574e03/scripts/benchmark-shadow.mjs

The source archive contains modules, tests, scripts, this report and aggregate results only. Captured pixels, masks, ROM bytes, extracted assets and private evidence are excluded. The first benchmark launch found no `/usr/bin/time`; it was replaced by Node's `process.resourceUsage()` and labelled endpoint memory samples. This did not change the detector.

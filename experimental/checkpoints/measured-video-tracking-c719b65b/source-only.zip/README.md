# Bounded measured-video replay lane checkpoint

Status: frozen source checkpoint for review and backup. **Not a claim of complete tracking or production readiness.** The original overlapping-duplicate assertion failure remains, and the actual orange monster still becomes unresolved while visible.

Task UUID: c719b65b-23c5-4709-ab00-50fa639c8c0d.

## Source and baseline

Six production files change:

- web/monster-position-proposals.mjs
- web/map-browser-preview/residual-tracking-input.mjs
- web/map-browser-preview/map-video-comparison.mjs
- web/map-browser-preview/video-patch-correspondence.mjs (new)
- web/map-browser-preview/video-tracking-replay.mjs (new)
- web/map-browser-preview/video-tracking-capture.mjs (new)

The starting source is the ce87377 snapshot plus the already-published one-file frame-identity correction. The three edited baseline files have exact byte hashes in SOURCE_MANIFEST.json. Against the inspected 6849e14 source, the tracker and adapter baselines are byte-identical; map-video-comparison differs only in cache-query versions. Parent reported later main revisions, including77fa; this checkpoint does not claim those unread revisions are byte-identical. Root must reconcile cache-query changes before any integration.

The ZIP includes the six full source files, three prior baseline files, patch, source tests, compact results, README and manifest. It excludes ROM, saves, RAM/DST data, game assets, decoded pixels and source video. No Git, deployment, external Work, user-computer or browser actions were performed. The earlier pose-ranking experiment is separate and remains held.

## Runtime connection

The mounted video callback offers actual retained VideoFrame pixels to a separate bounded lane before the slower ROM-background observation pump. A single pending hash and reusable canvas limit capture work. Unknown layout, unbound pixel timestamps, hash errors, cancellation and source changes cannot invent a measured frame. The ordinary classifier/background path remains intact.

Each frame stores only grayscale pixels, alpha-unavailable mask and its actual source/timestamp/hash metadata. The default limit is256 frames. A delayed ROM residual seed is accepted only when its exact original gameplay-pixel frame remains available and its boxes/timestamps are valid. The lane never attaches an old box directly to the current playback frame.

Local forward/backward image-patch correspondence accounts for object movement independently of the camera. It is followed by the existing conservative image tracker and association gates. Camera translation alone cannot continue a box. Missing/evicted/conflicting history, weak texture, insufficient known samples or unresolved correspondence stop that hypothesis and retain unknown/occlusion/error explanations. No new enemy detection, species choice, actor identity, birth, death, AT draw or native source tick is certified.

When a later ROM comparison's exact frame has measured history, it can receive a tentative continuity hint. Current raw residual regions remain unchanged. Existing normal tracker associations win conflicts. Source, epoch, segment, layout, pixel hash, ROM/map scope and target frame must match. Only an explicit retained-frame internal observation order is supplied to the tracker: real capture serials are preserved when available, absent serials stay null. Video microseconds are not represented as observed frame numbers.

## Screen-edge correction

The first patch matcher rejected an entire candidate if any part moved offscreen. Actual orange residual12 moved from x17 to11 to1, and was lost at170.612 while still visible at the left edge.

The corrected matcher compares only the real in-frame intersection. It does not pad pixels or extrapolate offscreen body support. The original150-known-sample minimum, texture gate2, clipped residual gate14, clipping value40, ±16-pixel search and0.5-second temporal discontinuity remain numerically unchanged. The full translated patch is a hypothesis; observedPatchROI reports only its clipped visible intersection, unobservedPatchPixels records the offscreen portion, and partialPatch stays explicit. Insufficient overlap remains unresolved. No fitted tolerance was added.

These numerical registration gates are inherited rather than calibrated for every local monster patch. Small/flat or changing animated patches can remain unsupported. All body/identity certificates remain false.

## Actual video result and retained failure

The headless run uses12 real decoded1ninn.mkv frames at source PTS170.312 through171.412,0.1 seconds apart. The seed is the exact saved browser gameplay RGBA and original c28 raw residual boxes. Following frames use FFmpeg decoding. File size and PTS were checked; FFmpeg's seed RGB differs from the saved browser RGB (RGBA MAE0.736,max8), so mixed-decoder evidence is explicitly recorded. No color correction was applied and no claim of browser-pixel parity is made.

Residual12 is the visible orange monster, initially22×33 pixels,726 sampled seed pixels:

- 170.312: original ROI x17,y5
- 170.412: tracked x11,y8
- 170.512: tracked x1,y13
- 170.612: after intersection correction, partial patch x-4,y17, observed intersection x0,width18; offscreen pixels are unknown
- 170.712: tracked x0,y17
- 170.812: unresolved while the orange object remains visible

The170.812 failure is exact and retained. Both directions have726 known samples and pass the inherited texture/residual gates. Forward gives(dx4,dy-2,residual11.7066); backward gives(dx-4,dy1,residual11.4449). The1-pixel reverse-Y disagreement fails exact bidirectional consistency. Both endpoints use FFmpeg, so there is no decoder transition at that step. This supports only a translation-model/correspondence limitation; it does not prove a specific native animation cause. No1-pixel tolerance was introduced.

For all32 raw seed regions, the corrected sequence retains6,3,3,3,1,0 boxes over the first six steps. Most are UI/background/error regions, not labeled monsters. Counts are not detection accuracy. The raw pre-clipping replay and its earlier loss remain saved separately.

The final headless replay took86.3ms over11 steps in one run, storing1,179,648 bytes of grayscale/mask data. Other runs varied; this is not a browser-speed claim. Canvas readback, browser video decoding and live contention with native workers were not benchmarked. The lane adds work; live overhead and usefulness remain review requirements.

## Bounds and lifecycle

- Default256 gray+mask frame slots: logical pixel bound25,460,736 bytes, including up to3 retained/in-flight predecessor references
- One asynchronous gameplay-pixel hash and one reusable source canvas; temporary full-frame readback is bounded by the current video's dimensions, not included in the gray-buffer figure
- Cooperative replay work budget8ms between patches; individual synchronous patch/legacy-camera operations are not hard-preempted
- Current frame history, source changes, cancellation and hash conflicts are explicitly handled
- If a slow ROM result arrives after its seed or intervening frames have been evicted, seed() returns residual-seed-frame-not-retained and continuity remains unknown. At the normal0.1-second capture work cadence,256 slots cover roughly25.6 seconds, but this is not a guaranteed time window. A13-second render gap can still fail if actual capture gaps exceed0.5 seconds or object correspondence is lost. No history is enlarged to force a success.
- The capture owner has one pending hash; replay has one active drain promise and at most one cooperative yield timer. New observations replace bounded slots rather than append unbounded pending jobs. Stop/source cancellation invalidates pending results, and drain scheduling ends when retained work is exhausted.
- A conflict discovered in an already-consumed frame invalidates dependent replay history
- Seventy-step stress test with4 slots retained active tracking,4 histories and at most491,520 bytes, including predecessor ownership

The mounted bootstrap test retained13 controlled pixel frames while the ROM pass was blocked, replayed11 steps from the original delayed seed, invoked the classifier once and closed all13 controlled VideoFrame handles. This verifies real controller wiring with a controlled provider, not native-browser rendering accuracy.

## Tests and exact status

- Existing mounted activation/latest-pending/pause/AT-controller regressions:45 checks pass
- New mounted blocked-background/bootstrap test:4 pass
- Four-edge clipping, insufficient-overlap, exact-tie, seed/source-binding tests:8 pass
- Capture, cancellation, asynchronous source changes, resource eviction and separate internal-order tests:8 pass
- Original replay suite:9 pass, **1 original assertion still fails**

The failing original fixture overlays two20-pixel patches12 pixels apart; the second overwrites part of the first, leaving one complete match. It expected0 tracks but returns1 tentative track. The fixture and expected result were not changed. The preserved-suite runner continues after that original failure and returns a nonzero status. A separately added nonoverlapping12×16 duplicate fixture demonstrates exact tied minima are rejected, but does not erase or replace the original failure.

Thus the checkpoint records74 passed checks and1 retained assertion failure; it must not be described as a fully passing test suite. No physical-actor or species accuracy validation is claimed.

## Reproduce

From the task's existing workspace:

```sh
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/run-preserved-replay-suite.mjs
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/edge-binding.test.mjs
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/capture-resources.test.mjs
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/mounted-fast-lane.test.mjs
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/measure-actual-video.mjs
node connect-moving-tracks-c719b65b/replay-lane-ce87377/tests/inspect-orange-loss.mjs
```

The first command intentionally retains the nonzero original failure. Actual-video scripts require the separately retained source inputs/decoded test frames; the ZIP does not redistribute them. Test-only synthetic frames and controlled capture providers are not production observations.

Root owns backup, any later integration decision, reverse cache-query invalidation and browser verification. This checkpoint does not replace the production proposal order or declare full video-to-ROM-to-tracking-to-AT automation complete.

The historical pre-clipping matcher source and a compact before/after actual-video summary are included for restart-safe failure reproduction. They are not alternative production modules.

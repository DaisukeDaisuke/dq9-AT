# Cooperative HUD recognition connection

Task UUID:6f344b30-ac7f-4107-b76c-b72c38d350ff, generated with Python uuid.uuid4(). New isolated source tree, based on commit126d5dfd207ce2dbf144ce196c48dd84f5ef5828. The shared assignment protocol remains unchanged. No browser, external Work, user-PC, Git or publication operation was used.

## Implemented connection

The frozen conditional HUD detector is connected to the existing low-frequency full-analysis workflow in this isolated copy:

- ROM loading starts one private template/calibration preparation for the current ROM identity
- A completed frozen background/video comparison starts one HUD task
- The ordinary automatic classification queue awaits that same task
- Fully HUD-explained original parents leave only the conditional classification queue
- Sparse surviving parents remain in the conditional queue as explicitly uncomputed; their old ROI classifications are never reused
- Original raw regions, masks, IDs, tracking input, unknown and non-event evidence remain available
- No manual screen box, parameter control, mask control or threshold input is added

This does not insert HUD inference into a10Hz capture path. The integration hook is after full `compareMapBackground`, and its classification consumer is the existing full-analysis queue. The separate tracking integration in `integrate-measured-replay-a9f6b3fc` was not edited. Its combined cadence must be checked by the parent after merging.

## Changed files and merge contract

Two existing files are changed:

1. `web/map-browser-preview/gpu-file-preview.mjs`: own the ROM-lifetime HUD connection, start preparation once after ROM hashing, cancel/release on ROM replacement, and preserve ordinary ROM loading if optional HUD source preparation is unsupported.
2. `web/map-browser-preview/map-video-comparison.mjs`: start/reuse HUD work for full comparisons, await it before automatic classification selection, retain summary provenance, and independently cancel/discard obsolete HUD work.

New/extended detector files:

- `web/map-browser-preview/conditional-hud-connection.mjs`
- `web/hud-cooperative.mjs`
- `web/conditional-hud-residual.mjs`
- `web/rom-command-overlay-advisory.mjs`
- `web/rom-command-overlay.mjs`

`BASELINE_BINDING.json` records the exact126d source hashes for the two existing files. `INTEGRATION.patch` is their minimal unified patch. Parent-owned publication/cache version updates and the merge with the tracking worker remain unperformed. No tracking, AT, DINO, native body renderer or classification threshold module was changed.

## Cooperative execution, same decisions

The8ms scheduling target affects only when work yields:

- Template search keeps the same ascending y/x order, profile order and source-stratum arithmetic
- It yields at row boundaries without dropping candidates or changing scores
- Synthetic calibration keeps the same examples and deterministic random sequence, yielding between examples and search rows
- Residual membership/remainder work also yields at bounded scan/traversal boundaries
- Cancellation is checked before/after yields and at final frame/hash validation

The asynchronous result, excluding scheduling telemetry, is deeply equal to the frozen synchronous result on all five actual frames. The complete calibration object, conditional masks, original/remaining region records, provenance hashes and branch keys are unchanged.

There is no worker pool, new model, threshold adjustment, heuristic early exit or broad new scheduling system. The pure synchronous exports remain for reference/testing; the mounted connection calls only the cooperative proposer.

## Current conditional queue results

The original budget selection is preserved. This minimal integration does not refill newly free slots.

| Frame | Raw requested | Conditional queue | Sent to inference | Sparse parent retained queued/unknown |
|---|---:|---:|---:|---|
|4200|10|8|8|none|
|1200|22|20|19|18|
|c28|32|30|29|70|
|2355|29|29|28|0|
|3300|32|32|31|24|

4200's fully explained original HUD parents0/2 leave the conditional queue. Its actual body/mallet fragments25/34 remain untouched. The other saved body hypotheses and the original raw domains are unchanged. Changed sparse parents are not silently discarded: `conditionalQueueRegionIds` preserves them and `heldConditionalRegionIds` records why no existing ROI-only inference runs.

`automaticResidualSelection.conditionalHud` carries the conditional branch identity, original source/frame binding, fully explained IDs, sparse IDs, per-parent counts, original-mask/excluded-mask hashes and the known one-pixel risk. The observation bundle continues receiving all original regions, so filtered or held entries remain unclassified evidence rather than asserted absences.

Existing individual raw-diagnostic classification buttons remain raw diagnostics. The new filtering applies to the ordinary automatic full-analysis queue; no new controls were introduced.

## Cancellation and lifecycle results

The actual mounted page was tested with controlled HUD/classifier promises and synthetic1920×1080 capture pixels:

- HUD completion leaves existing raw tracking state unchanged and does not call classifier/tracker reset hooks
- The automatic path waits for HUD before selecting its conditional queue
- A sparse parent remains queued but never reaches the ROI-only classifier
- Cancelling the next HUD task leaves an already running, correctly owned classifier and tracking state intact
- That HUD cancellation does not fall back to starting a stale raw classification
- A source reset rejects old HUD completion without UI overwrite or classifier restart

The connection also tests ROM preparation reuse, actual cooperative frame cancellation, stale-frame rejection, preparation cancellation and unsupported-source fallback. A late ROM preparation cannot replace a newer ROM's state.

The original mounted latest-frame and activation suites still pass without a supplied HUD connection:9 latest-frame checks and13 activation/lifecycle checks. This is compatibility evidence for the existing hooks, not the separate10Hz tracking integration's joint test.

## Measured responsiveness and cost

Paired Node measurements cover the five actual native256×192 fixtures, three repetitions each. ROM and fixture parsing are outside per-frame timing.

| Measurement | Frozen synchronous | Cooperative |
|---|---:|---:|
|Median total frame time|213.7ms|225.9ms|
|Frame time range|205.6–236.2ms|211.8–255.9ms|
|Maximum1ms timer-sentinel interval|235.6ms|12.8ms|
|Maximum measured processing slice|not split|11.4ms|
|Yields per frame|not split|22–26|

The total work was not removed. Cooperative execution creates frequent opportunities for other event-loop work instead of blocking it for roughly210ms.

Preparation is cached once per ROM. In this paired run, synchronous preparation took463.2ms with a461.5ms maximum timer interval; cooperative preparation took576.7ms with62 timer callbacks and a32.4ms maximum timer interval. Its largest measured scheduling slice was31.3ms. Thus8ms is a target, not a hard real-time upper bound. JIT, GC, runtime/source work and OS scheduling can overrun it.

These are Node event-loop observations, not browser paint-rate guarantees. The implementation belongs on full-analysis cadence and must not be called from10Hz tracking capture. The parent must check the combined browser/tracking workload after merge.

## Preserved risks and uncertainty

All60 prior counterfactual cases still pass their351 explicitly stated checks under cooperative execution. No detector/capture confidence change was made.

The important failure remains: a one-pixel occlusion can survive the template test and that altered residual pixel can be conditionally excluded. Blurred4200's second background rival still prevents application. Larger tested occlusions, absent/clipped/duplicate/off-layout cases remain unmasked. No result certifies complete pixel ownership, body identity, birth, AT consumption or AT absence.

Changed sparse masks remain unsupported by the old rectangular crop consumer; they are held unknown rather than assigned a cached class. Actual shader/browser rendering and live long-video behavior were not tested here. The five fixed matcher outputs and the mounted controller handshake were tested separately.

## Verification artifacts

- `COOPERATIVE_EQUIVALENCE.json`: all five complete detector outputs and calibration match the frozen implementation
- `CONNECTED_QUEUE_RESULTS.json`: one ROM preparation across five frames, original and conditional queues
- `CONNECTION_TEST_RESULTS.json`:20 connection assertions
- `MOUNTED_HUD_RESULTS.json`:3 mounted end-to-end controller scenarios
- `SHADOW_CONTROL_RESULTS.json`:60 cases,351 checks, including the acknowledged one-pixel failure
- `evidence/MOUNTED_PATCHED.json` and `evidence/MOUNTED_ACTIVATION.json`:22 existing mounted checks
- `COOPERATIVE_BENCHMARK.json`: paired measurements with source hashes
- `INTEGRATION.patch` and `BASELINE_BINDING.json`: exact merge inputs

## Reproduce

From the workspace root, using the already available private ROM/frozen fixtures:

    node connect-cooperative-hud-6f344b30/tests/cooperative-equivalence.mjs
    node connect-cooperative-hud-6f344b30/tests/connection.test.mjs
    node connect-cooperative-hud-6f344b30/tests/mounted-hud.test.mjs
    node connect-cooperative-hud-6f344b30/tests/legacy-mounted-latest.mjs
    node connect-cooperative-hud-6f344b30/tests/legacy-mounted-activation.mjs
    node connect-cooperative-hud-6f344b30/scripts/replay-connected-queue.mjs
    node connect-cooperative-hud-6f344b30/scripts/check-shadow-controls.mjs
    node connect-cooperative-hud-6f344b30/scripts/benchmark-cooperative.mjs

The deliverable is a source delta plus tests/reports. It contains no ROM/video bytes, raw pixels, extracted assets or masks. Both earlier ZIPs remain unchanged. Publication and joint tracking integration belong to the parent.

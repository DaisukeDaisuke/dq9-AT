import{unpackBackgroundMask}from'./background-branch-support.mjs';
import{videoTrackingFrameKey}from'./video-patch-correspondence.mjs';
const N=49152,W=256,H=192,copy=x=>structuredClone(x),same=(a,b)=>a?.length===b?.length&&a.every((x,i)=>x===b[i]);
/** Prior support only: exact connected pixels of the original ROM-background
 * residual, never a newly observed body mask or a current segmentation. */
export function collectVideoComponentSupport({stamp,backgroundEvidence,comparison,regionIds},{maximumSamples=1024}={}){
 if(!Number.isSafeInteger(maximumSamples)||maximumSamples<1)throw Error('Positive support sample work budget required');
 const no=reason=>({ready:false,reason,templates:[],currentSegmentationKnown:false,bodyCertified:false,identityCertified:false});
 const support=backgroundEvidence?.backgroundBranchSupport,frame=support?.frame,pts=stamp?.mediaTime??stamp?.videoTime;
 if(!support?.ready||!frame||!['sourceId','sourceEpoch','timelineSegment','fullRGBA_SHA256'].every(k=>frame[k]!==undefined&&frame[k]===stamp?.[k])||frame.mediaTime!==pts||!/^[a-f0-9]{64}$/.test(stamp?.gameplayRGBA_SHA256??''))return no('original-source-frame-binding-unavailable');
 const branches=support.branches?.filter(b=>b.rowIndex===support.selectedPreviewRowIndex&&b.recordKey===backgroundEvidence.recordKey&&b.romSHA256===backgroundEvidence.romSHA256&&b.fullRGBA_SHA256===stamp.fullRGBA_SHA256);
 if(branches?.length!==1)return no('original-selected-background-branch-unavailable');const branch=branches[0],mask=unpackBackgroundMask(branch.residualMask),known=unpackBackgroundMask(branch.knownMask);
 if(comparison?.residualMask?.length!==N||comparison.validMask?.length!==N||!same(mask,comparison.residualMask)||!same(known,comparison.validMask))return no('original-comparison-mask-binding-differs');
 if(!Array.isArray(comparison.components)||!Array.isArray(regionIds))return no('original-component-list-unavailable');
 const byId=new Map(comparison.components.map(r=>[r.id,r]));if(byId.size!==comparison.components.length)return no('duplicate-original-component-id');
 const wanted=new Set(regionIds),seen=new Uint8Array(N),queue=new Int32Array(N),templates=[],deferred=[];let id=0;
 for(let start=0;start<N;start++){if(!mask[start]||seen[start])continue;let head=0,tail=1,x0=W,y0=H,x1=-1,y1=-1;queue[0]=start;seen[start]=1;
  while(head<tail){const i=queue[head++],x=i%W,y=Math.floor(i/W);x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);for(const j of[x?i-1:-1,x+1<W?i+1:-1,y?i-W:-1,y+1<H?i+W:-1])if(j>=0&&mask[j]&&!seen[j]){seen[j]=1;queue[tail++]=j;}}
  if(wanted.has(id)){const raw=byId.get(id),roi={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};if(!raw||raw.pixels!==tail||!['x','y','w','h'].every(k=>raw.roi?.[k]===roi[k]))return no('original-connected-component-metadata-differs');
   const indices=Array.from(queue.subarray(0,tail)).sort((a,b)=>a-b),stride=Math.ceil(tail/maximumSamples),points=Uint16Array.from(indices.filter((_,i)=>i%stride===0).map(i=>(Math.floor(i/W)-y0)*W+(i%W-x0)));
   templates.push({kind:'original-connected-residual-support-v1',regionId:id,sourceFrameKey:videoTrackingFrameKey(stamp),sourcePTS:pts,romSHA256:backgroundEvidence.romSHA256,recordKey:branch.recordKey,branchId:branch.branchId,roi,componentPixels:tail,sampledPoints:points.length,samplingStride:stride,maximumSamples,points,currentSegmentationKnown:false,bodyCertified:false,identityCertified:false});
  }id++;
 }
 for(const regionId of wanted)if(!templates.some(t=>t.regionId===regionId))deferred.push({regionId,reason:'original-component-not-present'});
 return{ready:true,sourceFrameKey:videoTrackingFrameKey(stamp),templates,deferred,maximumSamples,erosionPolicy:'Only points observed in both frames of each successful correspondence remain active; no replenishment',currentSegmentationKnown:false,bodyCertified:false,identityCertified:false};
}

from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('/workspace/scratch/4d4d74ad4379');r=root/'recover-gate-reseed-ce0bdaa3';assert not r.exists();r.mkdir()
saved=root/'recovery-20261006-0852/saved-source';base=root/'recovery-20261006-0852/current-dq9-AT'
expected={'map-video-residual.mjs':'5e8e4d1c00a3c6cd457d71a1def16241d4a7ffb17576f18bd86c88c6878a3a55','video-tracking-capture.mjs':'6ff71713e2abe8dd8ba3c49077f00ff7783b7a945aee6d87aeea3ef4eda8a53c','video-tracking-replay.mjs':'2636f2b77d06a578b7aae3f066b60e67e5f097b1b3482abefff78fb04fa81ec4','map-video-comparison.mjs':'608324526b931596e1912f24013e0fe9a3f656836771f4ee0d4a77dc99a41101'}
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((saved/'same-canvas-readback-gate-da2d94ae.zip').read_bytes())=='c6dc63c3179aa53fddc0700654cc0ccd138bf86da11c217b2a76e1e3bf96ef92'
shutil.copytree(base/'web',r/'web')
for name in ['baseline','evidence','scripts','tests','gate-tests','original-tests','pinned-order/tests','pinned-order/web/map-browser-preview']:(r/name).mkdir(parents=True,exist_ok=True)
for name in expected:shutil.copy2(base/'web/map-browser-preview'/name,r/'baseline'/name)
with zipfile.ZipFile(saved/'same-canvas-readback-gate-da2d94ae.zip') as z:
 manifest=json.loads(z.read('SOURCE_MANIFEST.json'))
 for name,m in manifest['files'].items():
  b=z.read(name);assert sha(b)==m['sha256'] and len(b)==m['bytes'],name
 for name in ['map-video-residual.mjs','video-tracking-capture.mjs']:
  b=z.read('web/map-browser-preview/'+name);assert sha(b)==expected[name];(r/'web/map-browser-preview'/name).write_bytes(b)
 for n in z.namelist():
  if n.startswith('tests/') and n.endswith('.mjs'):(r/'gate-tests'/Path(n).name).write_bytes(z.read(n))
  if n.startswith('original-tests/') and n.endswith('.mjs'):(r/n).write_bytes(z.read(n))
with zipfile.ZipFile(saved/'hud-tracking-wip-db4e8599.zip') as z:
 for name,h in [('map-video-comparison.mjs','cba06b701822d66cdc92a0a705d13afd0e8cb1bd2161ae42212f9554d77837f4'),('video-tracking-replay.mjs',expected['video-tracking-replay.mjs'])]:
  b=z.read('reseed-order-fix/web/map-browser-preview/'+name);assert sha(b)==h,(name,sha(b));(r/'pinned-order/web/map-browser-preview'/name).write_bytes(b);(r/'web/map-browser-preview'/name).write_bytes(b)
 for n in ['RESEED_ORDER_FIX.patch','RESEED_ORDER_FIX_BINDINGS.json','RESEED_ORDER_FIX_RESULTS.json','RESEED_RACE_CONTROL.json']:(r/'pinned-order'/n).write_bytes(z.read(n))
 for n in ['tests/reseed-order-fix.test.mjs','tests/reseed-race-control.test.mjs']:(r/'pinned-order'/n).write_bytes(z.read(n))
p=r/'web/map-browser-preview/map-video-comparison.mjs';s=p.read_text()
s=s.replace('./video-tracking-replay.mjs?v=measured-replay-candidate-20261006-0653','./video-tracking-replay.mjs?v=gate-reseed-integration-20261006-0829')
s=s.replace('./video-tracking-capture.mjs?v=measured-replay-candidate-20261006-0653','./video-tracking-capture.mjs?v=same-canvas-readback-20261006-0817')
s=s.replace('measuredVideoTracking:fastReplay.snapshot(),measuredClassificationView:','measuredVideoTracking:fastReplay.snapshot(),measuredVideoCapture:fastCapture.snapshot(),measuredClassificationView:')
s=s.replace('measuredTrackingSnapshot:()=>fastReplay.snapshot(),measuredClassificationSnapshot:','measuredTrackingSnapshot:()=>fastReplay.snapshot(),measuredCaptureSnapshot:()=>fastCapture.snapshot(),measuredClassificationSnapshot:')
needle="const source=new FileVideoInput(video,(_now,stamp)=>{if(pump.enabled){fastCapture.offer(stamp,{layout:frozen?.evidence.layout});"
replacement="const source=new FileVideoInput(video,(_now,stamp)=>{if(pump.enabled){const size=frozen?.evidence.sourceSize;if(size&&(size.width!==video.videoWidth||size.height!==video.videoHeight)){resetSource('video-dimensions-changed',stamp);pump.start();}fastCapture.offer(stamp,{layout:frozen?.evidence.layout});"
assert needle in s;s=s.replace(needle,replacement)
needle=' const source=new FileVideoInput(video,(_now,stamp)=>';assert needle in s
s=s.replace(needle," // Decoded input dimensions only, never element/CSS presentation dimensions.\n // Invalidate pending slow comparisons/classifications as well as fast pixels.\n"+needle,1)
p.write_text(s)
actual={name:sha((r/'web/map-browser-preview'/name).read_bytes()) for name in expected}
report={'recoveryUUID':'ce0bdaa3-d68e-4fae-a462-eb550c2ed029','oldArchiveAvailable':False,'oldArchiveSHA256':'9911052b6622538e818237bb5b8e19ea65a8b0dc8c0d83aeedca298d25df73fa','reconstructedFromSavedInputsAndRetainedIntegrationOperations':True,'recoveredFourFilesMatchPreLossSHA256':actual==expected,'expected':expected,'actual':actual,'gateZIP_SHA256':sha((saved/'same-canvas-readback-gate-da2d94ae.zip').read_bytes()),'orderZIP_SHA256':sha((saved/'hud-tracking-wip-db4e8599.zip').read_bytes()),'HUDIncluded':False,'buildRun':False,'browserRun':False,'published':False}
(r/'evidence/EXACT_SOURCE_RECOVERY.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert actual==expected
shutil.copy2('/tmp/recover-final-integration-ce0bdaa3.py',r/'scripts/recover-final-integration.py')

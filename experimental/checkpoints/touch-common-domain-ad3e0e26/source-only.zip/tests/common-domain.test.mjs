import assert from'node:assert/strict';import fs from'node:fs';
import{buildCommonObservedDomain,compareCompositionOnCommonDomain}from'../web/common-observed-domain.mjs';
let assertions=0;const eq=(a,b)=>{assert.deepEqual(a,b);assertions++;},near=(a,b)=>{assert.ok(Math.abs(a-b)<1e-12);assertions++;},bad=(f,re)=>{assert.throws(f,re);assertions++;};
const background={schema:'dq9-local-no-overlay-background-rival-v1',width:2,height:1,valid:Uint8Array.from([1,1]),errors:Float64Array.from([.4,.4]),observedPixels:2};
const domain=buildCommonObservedDomain(background);eq(domain.pixelCount,2);eq(domain.baselineErrorSum,.8);eq(domain.baselineMeanError,.4);eq(domain.relativeNoOverlayScore,0);
const short=compareCompositionOnCommonDomain(domain,background,{sourceErrorSum:0,coveredBackgroundErrorSum:.4,sourceSupportPixels:1}),full=compareCompositionOnCommonDomain(domain,background,{sourceErrorSum:0,coveredBackgroundErrorSum:.8,sourceSupportPixels:2});
near(short.score,.2);near(full.score,.4);near(short.unexplainedOutsideSourceErrorSum,.4);near(full.unexplainedOutsideSourceErrorSum,0);eq(short.commonDomainPixels,full.commonDomainPixels);near(short.candidateDomainMeanError,.2);near(full.candidateDomainMeanError,0);eq(full.score>short.score,true);
const badExtension=compareCompositionOnCommonDomain(domain,background,{sourceErrorSum:.9,coveredBackgroundErrorSum:.8,sourceSupportPixels:2});eq(badExtension.score<short.score,true);eq(badExtension.score<0,true);
// The rule rewards explained observed pixels, not length by itself.
const uncovered={...background,width:3,valid:Uint8Array.from([1,1,0]),errors:Float64Array.from([.4,.4,0])};eq(buildCommonObservedDomain(uncovered).pixelCount,2);
bad(()=>compareCompositionOnCommonDomain(structuredClone(domain),background,{sourceErrorSum:0,coveredBackgroundErrorSum:.4,sourceSupportPixels:1}),/Unbound/);
bad(()=>compareCompositionOnCommonDomain(domain,{...background},{sourceErrorSum:0,coveredBackgroundErrorSum:.4,sourceSupportPixels:1}),/Unbound/);
domain.pixelCount++;bad(()=>compareCompositionOnCommonDomain(domain,background,{sourceErrorSum:0,coveredBackgroundErrorSum:.4,sourceSupportPixels:1}),/changed/);domain.pixelCount--;
bad(()=>compareCompositionOnCommonDomain(domain,background,{sourceErrorSum:0,coveredBackgroundErrorSum:1,sourceSupportPixels:1}),/Invalid/);
bad(()=>buildCommonObservedDomain({...background,observedPixels:1}),/inconsistent/);
bad(()=>buildCommonObservedDomain({...background,valid:new Uint8Array(2),observedPixels:0}),/Empty/);
fs.writeFileSync('derive-touch-common-domain-ad3e0e26/evidence/COMMON_DOMAIN_TESTS.json',JSON.stringify({assertions,unexplainedContinuationRetained:true,sharedDenominator:true,badExtensionNotRewarded:true,scope:'Arithmetic and common-domain binding mechanics only'},null,2));console.log({assertions});

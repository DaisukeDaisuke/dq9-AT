# Joint touch video candidate stage: dependency-independent checkpoint

UUID d55dc6f9-05a4-49fc-886d-85f6753aa2ad. Internal task only. Protocol libfile_564b88200db481919e83f5494a793df9 was read before environment replacement. No external committee or Library/Git/browser operation was performed.

## Current result

The bounded full-scene candidate mechanics are implemented. The pure core scans every fully-contained integer ring/dot placement, joins retained origins to a fixed full-viewport endpoint lattice, evaluates ring/shaft/head/dot source-color support, refines joint candidates, and exposes exact-raster scoring. A separate source/frame adapter has been written but has not yet run: its required guarded ROM modules disappeared during environment replacement and have not been restored at this checkpoint.

This is not a completed ROM/video inference stage. No real frame was numerically evaluated. No overlay presence, player position, pixel ownership, species identity, exclusion mask, or AT decision is emitted. Threshold is null. Absent-overlay, uncomputed/truncated search, clipped cases, unsupported short-vector heading and unknown capture/current display state are retained explicitly.

## Frozen search plan

SEARCH_PLAN.json SHA256 81a864b45cce3619d8daecd5d12d0d4513d7fc636a11344801225305e47d9a9f was persisted before any numeric real-frame evaluation. Its budgets are fixed in source. Float affine sprite sampling is a proposal approximation only. The ROM-bound exact four-sprite raster must rerank it before a video candidate can be reported. All exact-ranked rivals and incomplete cases are retained; only the displayed shortlist is capped at 32.

## Tests so far

node derive-video-touch-d55dc6f9/tests/search-core-mechanics.test.mjs

36 assertions passed on tiny generated fixtures. They verify full-scene iteration counts, candidate integer bounds, deterministic ranking, unchanged input bytes, explicit incomplete/absent alternatives, cancellation, input rejection and four-role exact-score completeness. These fixtures deliberately do not pretend to be ROM assets or game video. Both new modules pass node --check. The adapter's static imports remain unresolved until source restoration.

## Environment replacement

The old formal ROM, renderer snapshot, prior producer and fixed video files were available at task start, were read, and then disappeared during a confirmed container replacement. The initially attempted plan write failed with missing paths. The new isolated directory and the current files were created afterward. No old missing file has been replaced with a dummy or approximate implementation.

Required restored dependencies:
- produce-touch-overlay-08abb25e/web/rom-touch-origin-overlay.mjs
- produce-touch-overlay-08abb25e/web/rom-touch-overlay-composition.mjs
- produce-touch-overlay-08abb25e/web/rom-touch-overlay-raster.mjs
- inspect-at-connection-20261004-2203/parent-camera-alternative-integration-0523/web and required import closure
- recovery-20261004-2203/verified/dq9_new2.nds
- explain-player-ring-ab633c61 source/frozen calibration and results
- exclude-rom-command-overlay-58b47cd3 fixture/membership helper
- five immutable inspect-map-video-publication-20261005 comparison JSON inputs

Next: restore source-only dependencies into this isolated copy, extend the producer to accept only privately bound automatically generated video candidates, keep validation behavior unchanged, then run bounded source/raster/binding tests and one frozen five-frame replay. Preserve the old negative ring matcher, inputs and failures. No threshold fitting after real-frame evaluation.

"""Reconstructed validation oracle. Executes immutable ROM code with synthetic
source sprite objects; no live game memory, savestate or video coordinates."""
import sys,struct,json,math,hashlib
from pathlib import Path
R=Path('restore-touch-geometry-4d501e2a');sys.path.insert(0,str(R/'private-tools'))
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE,UC_HOOK_CODE
from unicorn.arm_const import *
MANIFEST=json.loads((R/'evidence/ORACLE_INPUT_MANIFEST.json').read_text());SEGMENTS=[]
for item in MANIFEST['segments']:
 b=(R/'private-evidence'/item['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==item['sha256'];SEGMENTS.append((item['address'],b))
ASSETS=[]
for item in MANIFEST['sprites']:
 b=(R/'private-evidence'/item['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==item['sha256'];n,fmt,w,h,parts=struct.unpack_from('<HHHHI',b);x,y,wx,hy=struct.unpack_from('<HHHH',b,12);assert(n,fmt,parts)==(1,3,1);ASSETS.append((w,h,x,y,wx,hy))
i32=lambda x:(x+2**31)%2**32-2**31
s16=lambda x:(x+2**15)%2**16-2**15
I=[4096 if i%5==0 else 0 for i in range(16)]
def mul(a,b):return[i32(sum(a[k*4+i%4]*b[(i//4)*4+k]for k in range(4))>>12)for i in range(16)]
def pos(a,v):return[i32(sum(a[k*4+r]*v[k]for k in range(4))>>12)for r in range(4)]
def trunc(a,b):return(-1 if(a<0)!=(b<0)else 1)*(abs(a)//abs(b))
def machine():
 u=Uc(UC_ARCH_ARM,UC_MODE_ARM)
 for a,n in [(0x02000000,0x400000),(0x01ff8000,0x8000),(0x027e0000,0x20000),(0x04000000,0x1000)]:u.mem_map(a,n)
 for a,b in SEGMENTS:u.mem_write(a,b)
 def r32(a):return struct.unpack('<I',u.mem_read(a,4))[0]
 def w32(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def r64(a):return struct.unpack('<q',u.mem_read(a,8))[0]
 def read(uc,access,a,size,value,data):
  if 0x4000280<=a<0x40002b0:
   mode=r32(0x4000280)&3;A=i32(r32(0x4000290))if mode==0 else r64(0x4000290);B=r64(0x4000298)if mode==2 else i32(r32(0x4000298));assert B!=0;q=trunc(A,B);u.mem_write(0x40002a0,struct.pack('<QQ',q%(2**64),(A-q*B)%(2**64)))
  elif 0x40002b0<=a<0x40002c0:
   mode=r32(0x40002b0)&1;N=struct.unpack('<Q',u.mem_read(0x40002b8,8))[0]if mode else r32(0x40002b8);w32(0x40002b4,math.isqrt(N))
 u.hook_add(UC_HOOK_MEM_READ,read,begin=0x4000280,end=0x40002bf)
 def execute(address,regs,stack):
  u.reg_write(UC_ARM_REG_CPSR,0x10)
  for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],regs):u.reg_write(reg,v)
  sp=0x23f0000
  for i,v in enumerate(stack):w32(sp+i*4,v)
  u.reg_write(UC_ARM_REG_SP,sp);u.reg_write(UC_ARM_REG_LR,0x23eff00);u.emu_start(address,0x23eff00,count=200000);assert u.reg_read(UC_ARM_REG_PC)==0x23eff00
 return u,r32,w32,execute

def projection():
 u,r32,w32,execute=machine();imm=lambda a:((r32(a)&255)>>(((r32(a)>>8)&15)*2)|(r32(a)&255)<<(32-((r32(a)>>8)&15)*2))&0xffffffff;o={'top':imm(0x2196d30),'bottom':imm(0x2196d34),'left':0,'right':imm(0x2196d3c),'near':-imm(0x2196d10),'far':imm(0x2196d1c),'w':imm(0x2196d1c)};out=0x22a0000
 execute(0x20c44b8,[o[k]for k in ['top','bottom','left','right']],[o[k]for k in ['near','far','w']]+[out]);proj=list(struct.unpack('<16i',u.mem_read(out,64)));eye=out+0x100;u.mem_write(eye,bytes(12));execute(0x20c3ba0,[eye,r32(0x2196f40),r32(0x2196f3c),out],[]);view=list(struct.unpack('<12i',u.mem_read(out,48)));return{'projectionOperands':o,'projectionFx':proj,'view4x3Fx':view}

def run(origin,end):
 u,r32,w32,execute=machine();base=0x2280000
 for idx,(w,h,x,y,wx,hy)in enumerate(ASSETS):
  obj=base+idx*0x88;u.mem_write(obj,bytes(0x88));u.mem_write(obj+4,struct.pack('<H',3));u.mem_write(obj+0x80,struct.pack('<HhB',32767,31,3))
  for at in[0x34,0x38,0x3c]:w32(obj+at,4096)
  img=0x2290000+idx*0x100;piece=img+16;track=img+32;entry=img+64
  w32(obj+8,img);w32(obj+12,track);w32(obj+0x14,2);w32(obj+0x74,1)
  u.mem_write(img,struct.pack('<BBBBI',w,h,1,0,piece));u.mem_write(piece,struct.pack('<IHH',idx*0x1000,wx|(hy<<4),x|((h-y-(8<<hy))<<8)));u.mem_write(track,struct.pack('<IIII',1,entry,1,entry));u.mem_write(entry,struct.pack('<III',1,0,0))
 u.mem_write(base+0x220,bytes([*origin,*end,1,1,1]));m=I[:];stk=[];pending={};fifo=[];polygons=[];vertices=[];uv=[0,0];color=None;tex=None;attr=None;vfirst=None;role=None;events=[];mathTrace={}
 def finish(cmd,values):
  nonlocal m
  a=I[:]
  if cmd==0x19:
   a=[0]*16
   for col in range(4):a[col*4:col*4+3]=values[col*3:col*3+3]
   a[15]=4096
  elif cmd==0x1b:
   for j in range(3):a[j*5]=values[j]
  elif cmd==0x1c:a[12:15]=values
  else:raise Exception(('unsupported matrix command',cmd))
  m=mul(m,a)
 def write(uc,access,a,size,value,data):
  nonlocal m,uv,color,tex,attr,vfirst,vertices
  if a<0x4000400:return
  events.append([a,size,value])
  if 0x4000400<=a<0x4000440:
   if not fifo:fifo.extend([value,[]]);assert value==0x19
   else:
    fifo[1].append(i32(value))
    if len(fifo[1])==12:finish(fifo[0],fifo[1]);fifo.clear()
  elif a==0x4000444:stk.append(m[:])
  elif a==0x4000448:assert value==1 and stk;m=stk.pop()
  elif a in[0x400046c,0x4000470]:
   q=pending.setdefault(a,[]);q.append(i32(value))
   if len(q)==3:finish(0x1b if a==0x400046c else 0x1c,q);pending[a]=[]
  elif a==0x40004a8:tex=value
  elif a==0x40004a4:attr=value
  elif a==0x4000480:color=value&32767
  elif a==0x4000488:uv=[s16(value&65535),s16(value>>16)]
  elif a==0x4000500:assert value==1;vertices=[]
  elif a==0x400048c:
   if vfirst is None:vfirst=[s16(value&65535),s16(value>>16)]
   else:
    v=vfirst+[s16(value&65535),4096];vertices.append({'localFx':v,'positionFx':pos(m,v),'uvFx4':uv[:],'rgb555':color});vfirst=None
  elif a==0x4000504:assert len(vertices)==4;polygons.append({'role':role,'vertices':vertices,'textureParameter':tex,'polygonAttribute':attr,'matrixFx':m[:]})
 def code(uc,a,size,data):
  nonlocal role
  if a in[0x20481e8,0x2048104]:role=['ring','shaft','head','dot'][(u.reg_read(UC_ARM_REG_R0)-base)//0x88]
  if a==0x20989a8:mathTrace['distanceFx']=r32(u.reg_read(UC_ARM_REG_SP))
  if a==0x20c4e58:mathTrace['normalizedFx']=[i32(u.reg_read(UC_ARM_REG_R0)),i32(u.reg_read(UC_ARM_REG_R1)),0]
  if a==0x2098a9c:mathTrace['angleFx']=i32(u.reg_read(UC_ARM_REG_R0))
 u.hook_add(UC_HOOK_MEM_WRITE,write,begin=0x4000400,end=0x4000fff);u.hook_add(UC_HOOK_CODE,code);execute(0x2098888,[base,origin[0],origin[1],end[0]],[end[1]]);assert len(polygons)==4 and not stk and not fifo and m==I
 return{'origin':origin,'endpoint':end,'math':mathTrace,'polygons':polygons,'writeCount':len(events),'writesSHA256':hashlib.sha256(json.dumps(events,separators=(',',':')).encode()).hexdigest()}
if __name__=='__main__':
 (R/'private-evidence/PROJECTION_ORACLE.json').write_text(json.dumps(projection()));rows=[]
 for i,p in enumerate(json.loads((R/'private-evidence/TEST_INPUTS.json').read_text())):
  rows.append(run(p['origin'],p['endpoint']))
  if i%200==0:print(i,flush=True)
 (R/'private-evidence/ROM_ORACLE.json').write_text(json.dumps(rows));print('NEW reconstructed witness executions:',len(rows))

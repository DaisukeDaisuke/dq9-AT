// Optional, explicitly separate query domain. The legacy source crop is untouched.
// Uses the same fixed gameplay pixel grid as ROM body/background comparisons;
// does not assert matching pose/camera, actor membership or bank completeness.
import {cropRGBA} from './monster-roi-descriptor.mjs';
const need=(x,m)=>{if(!x)throw Error(m);},keys=['sourceId','sourceEpoch','timelineSegment','mediaTime','fullRGBA_SHA256','gameplayRGBA_SHA256','sampling'];
const same=(a,b)=>keys.every(k=>a?.[k]!==undefined&&a[k]===b?.[k]);
const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
export async function nativeGridAppearanceQuery({nativeVideo,videoEvidence,region,getCurrentFrame,signal}){
 need(nativeVideo?.width===256&&nativeVideo?.height===192&&(nativeVideo.rgba instanceof Uint8Array||nativeVideo.rgba instanceof Uint8ClampedArray)&&nativeVideo.rgba.length===196608,'Owned 256x192 native gameplay RGBA required');
 need(videoEvidence?.sampling==='pixel-center-bilinear-256x192'&&/^[a-f0-9]{64}$/.test(videoEvidence.fullRGBA_SHA256??'')&&/^[a-f0-9]{64}$/.test(videoEvidence.gameplayRGBA_SHA256??'')&&typeof videoEvidence.sourceId==='string'&&videoEvidence.sourceId.length>0&&['sourceEpoch','timelineSegment'].every(k=>Number.isSafeInteger(videoEvidence[k])&&videoEvidence[k]>=0)&&Number.isFinite(videoEvidence.mediaTime)&&videoEvidence.mediaTime>=0,'Frozen native sampling profile and frame identity required');
 need(typeof getCurrentFrame==='function','Current source guard required');const frame=structuredClone(videoEvidence),guard=()=>{if(signal?.aborted||!same(frame,getCurrentFrame()))throw new DOMException('Native appearance source changed','AbortError');};guard();
 const q=region?.roi;need(q&&['x','y','w','h'].every(k=>Number.isInteger(q[k]))&&q.x>=0&&q.y>=0&&q.w>0&&q.h>0&&q.x+q.w<=256&&q.y+q.h<=192,'Native region geometry required');
 const pixels=nativeVideo.rgba.slice();need(pixels.every((x,i)=>i%4!==3||x===255),'Video query alpha must remain opaque; no residual/body masking');const nativeRGBA_SHA256=await digest(pixels);guard();need(nativeRGBA_SHA256===frame.gameplayRGBA_SHA256,'Native query pixels differ from their frozen source identity');
 const image=cropRGBA({width:256,height:192,rgba:pixels},q.x,q.y,q.w,q.h),cropRGBA_SHA256=await digest(image.rgba);guard();
 return{kind:'geometry-derived-native-grid-appearance-query-v1',image,frame,originalRegionId:region.id,nativeROI:{...q},nativeRGBA_SHA256,cropRGBA_SHA256,queryDomain:'owned-gameplay-native256x192-before-ROI-crop',sampling:'unchanged captured pixel-center-bilinear native grid, then integer native crop; existing DINO bicubic224 normalization follows',alphaPolicy:'original opaque video RGB; no residual-mask or model-mask alpha',legacySourceQueryReplaced:false,modelOrSpeciesChosen:false,identityCertified:false,noEventPossible:true,scope:'Alternative sampling domain only. Native display-grid comparability does not establish camera/pose/shading equality with the normalized ROM appearance bank or identify the observed object.'};
}

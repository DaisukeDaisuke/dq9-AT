# Common observed-domain comparison for touch-arrow lengths

UUID ad3e0e26-2536-40b5-b312-d17daad23f5c was generated with Python before this task/manifest was written. Internal worker, protocol libfile_564b88200db481919e83f5494a793df9. One bounded implementation/control/evaluation pass. No Git, Library, browser, user-PC, production/UI, root-stage or build.sh work.

## Actual impact

On the fixed historical frame4200, the full visible-arrow hypothesis returns to rank1: origin[119,99]→endpoint[69,52]. The visible-arrow hypotheses in1200 and2355 remain first. Region18 retains its original9 residual pixels; the top4200 source hypothesis intersects8 of them conditionally. No pixels, classifications, species or AT state were changed.

There is an important regression in presence discrimination. The no-visible-arrow controls c28 and3300 now have command-area impostors with positive total improvement over the smooth-background rival. Their retained per-role local gains are negative, so the two measures disagree. The new ranker is useful for comparing arrow lengths, but it is not a reliable standalone presence or ownership discriminator. No gate or threshold was added after seeing this result.

Keep the checkpoint isolated. All candidate ambiguity and no-overlay/unknown alternatives remain exposed. Do not turn the recorded8/9 intersection into an ownership mask or claim that the historical false-enemy label is fixed.

The predecessor remains untouched: derive-touch-contrast-ed94b819/JOINT_TOUCH_BACKGROUND_RIVAL_SOURCE.zip,68,502 bytes,SHA256a5328687cdf6a87388211f351a3b61ba9471803e6ca7dd333aa821132d992823. Earlier checkpoints and failures remain in their original directories.

## Minimal implementation

New web/common-observed-domain.mjs builds one comparison domain from every native pixel whose existing ROM-radius background perimeter is fully observed. The domain is derived once from the entire frame and source dimensions; it is independent of candidate support, known positions and ROIs. In these five opaque frames it contains41,412 pixels; its mask hash isb57be8e313eb2607d3e4225ff66237c8ecfaa973a021fc513a550378cf4d20bb.

Each candidate predicts source RGB on its final opaque source support, and the existing local-background prediction everywhere else in that same domain. Consequently, the background error from unexplained continuation outside a short arrow remains in its model error. No-overlay predicts the background everywhere. The relative score is:

    (no-overlay total error - candidate total error) / common observed pixel count

Equivalently, it is summed(background error-source error) on source support, divided by the same full-domain count. The candidate cannot improve its denominator by choosing a shorter footprint. An incorrect extension can make the score worse; length is not rewarded by itself. The original local four-role score is retained separately as localRoleGain, rather than discarded or silently turned into a gate.

Only exact reranking changes. The predecessor's automatic origin/endpoint proposal generation, computation budgets, source guards, default geometry, native sample convention, cancellation/mutation checks and final-role completeness remain unchanged. All five complete and incomplete candidate sets, as well as every search statistic, were checked against the predecessor and are identical. The new full-domain source score only changes their ordering and diagnostics.

All four final source roles must still have visible support. A source pixel outside the observed background domain makes the hypothesis incomplete. Short-distance actor heading, unsearched/truncated vectors, clipped source/background support, capture phase/filter/color, current visibility/nondefault state, destination depth/fog and no-overlay remain explicit alternatives. Threshold remains null and every candidate remains unadmitted.

## Frozen controls before real replay

SEARCH_PLAN.json SHA256c86f9dd87334f64917bd265229cb4b1a20f8bef1121c5c2937473e11e4e18e8e and runtime source hashes were frozen before successor controls. Three new synthetic source vectors were generated from PRNG seed0x7139ac25. Nine positive scenes use those vectors over source-mean cyan, RGB gradient and checker backgrounds. Six no-overlay scenes use uniform cyan, uniform white, gradient, checker, deterministic RGB noise and a smooth colored wave. Actual captures are never read by this control script.

Every positive also compares its complete reference vector with its source-composed midpoint-length rival on the identical observed domain. These are synthetic verification coordinates, not production inputs.

-Full reference beats midpoint in9/9 paired cases
-Minimum full-reference gain:+0.0002488920
-Maximum automatically selected negative-scene gain:-0.0001340413
-Exact source vector retained in0/9 positive searches by the unchanged proposal beam
-Top origins are correct in those nine generated scenes, but endpoint error ranges1–5.1px

The declared reference control scores separate, but exact recovery remains incomplete and these procedural controls do not cover structured real UI. No case was removed, no negative failure was recategorized, and no source/budget/threshold changed after controls. The original flat/procedural generated-scene tests remain recorded separately, including their endpoint miss. No admission threshold is derived or activated.

## One frozen five-frame replay

New common-domain scores and predecessor local-role scores have different meanings. Neither is a probability. The following rows are observations of the first-ranked complete source hypothesis, not accepted detections.

| Frame | Top vector | Common-domain gain | Retained local-role gain | Result |
|---|---|---:|---:|---|
|4200|[119,99]→[69,52]|+0.0006310039|+0.0097680950|Full visible-arrow hypothesis restored to first; predecessor's too-short winner moves down|
|1200|[127,98]→[183,116]|+0.0006117011|+0.0520150235|Visible arrow remains first|
|c28|[225,25]→[236,15]|+0.0003966813|-0.0266748883|False arrow hypothesis in command area; total and local measures conflict|
|2355|[131,93]→[138,141]|+0.0007629942|+0.0861336775|Visible arrow remains first|
|3300|[225,25]→[236,15]|+0.0000181105|-0.0663373600|False command-area arrow hypothesis; total and local measures conflict|

The source support sizes of those top hypotheses are400,370,178,319 and178 pixels, respectively. Every comparison uses the same41,412 observed pixels for its frame. Visual agreement does not establish the actual touch byte coordinates.

The4200 top hypothesis's conditional support overlaps8 of region18's9 pixels and349 of the long-arrow-associated region3's530 pixels, alongside smaller neighboring residuals. This is source-template intersection, not pixel ownership. All1,563 original component IDs, ROIs and pixel counts were independently reconstructed and verified. Original capture files and native video bytes remain unchanged; excludedPixels is0.

Private visual evidence: private-evidence/FIVE_FRAME_CANDIDATES.png. Full private registrations preserve all rivals, incomplete cases, common-domain errors and local-role evidence. No raw pixels or screenshots are included in the source-only archive.

## Verification

-21 new common-domain arithmetic/binding assertions: common denominator, unexplained continuation retained, bad extension not rewarded, empty/changed/foreign domain rejection
-29 inherited background-rival arithmetic assertions
-34 inherited ROM/source/frame/video-contract assertions
-1,960 complete validation output objects remain identical to the independently ROM-validated reconstructed producer
-All128 attempted exact candidate identities per frame remain the same complete/incomplete sets as the predecessor
-Runtime/plan hashes remain identical to the pre-control and pre-real-replay freezes
-Exactly one successor fixed five-frame replay

These84 assertions and the validation equality check establish bounded mechanisms, not all-input game/video automation or detector success. Geometry evidence is reused rather than expanded into another exhaustive investigation.

## Inputs and reproduction

Formal ROM: recovery-20261006-0852/verified/dq9_new2.nds,SHA2563c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7. The reconstructed producer remains source-bound. Fixed original comparisons are read from the parent's hash-verified recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005. The renderer import closure is read-only and hashed in evidence/DEPENDENCY_MANIFEST.json.

From workspace root:

    node derive-touch-common-domain-ad3e0e26/tests/common-domain.test.mjs
    node derive-touch-common-domain-ad3e0e26/tests/background-rival.test.mjs
    node derive-touch-common-domain-ad3e0e26/scripts/calibrate-controls.mjs
    node derive-touch-common-domain-ad3e0e26/tests/rom-video-candidates.test.mjs
    node derive-touch-common-domain-ad3e0e26/scripts/verify-validation-preservation.mjs
    node derive-touch-common-domain-ad3e0e26/scripts/replay-fixed.mjs
    node derive-touch-common-domain-ad3e0e26/scripts/diagnose-overlap.mjs
    python derive-touch-common-domain-ad3e0e26/scripts/render-evidence.py

This source-only checkpoint is not a standalone production application. It contains no ROM bytes, decoded sprites, video pixels, screenshots or native-memory truth.

## Limit exposed by this pass

Common-domain error fixes the incentive to select a too-short subset of an arrow, but allows improvement in some roles to outweigh a poorly explained ring. Real command graphics expose this limitation even though simple procedural negatives do not. A subsequent implementation needs explicit competing source UI/structure evidence or a justified treatment of that disagreement; do not fit a numerical gate between these five observed scores. Existing raw monster/body evidence must remain intact while such alternatives are unresolved.

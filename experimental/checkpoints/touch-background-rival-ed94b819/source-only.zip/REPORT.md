# Source-derived background rival for joint touch candidates

UUID ed94b819-5ee6-44c3-afd5-fac0d601449e, generated with Python before this successor's task/manifest was written. Internal worker only; protocol libfile_564b88200db481919e83f5494a793df9. This is one bounded implementation/calibration/evaluation pass. No Git, Library, browser, user-PC, production/UI, root-stage or build.sh operation was performed.

## Result and recommendation

The source-derived background rival fixes the previous blue-sky ranking failures in the frozen evaluation:1200 and2355 now rank candidates following the visible arrows first. In both no-visible-arrow controls, c28 and3300, every evaluated complete UI candidate scores below the explicit background rival.

4200 remains ambiguous: the original long arrow is retained at rank2, but a too-short arrow now ranks first. Automatically choosing the winner would still be wrong. Keep this candidate-only and isolated. No presence/absence classification, ownership, mask, species or AT decision is authorized by these results.

The published predecessor archive is untouched: derive-video-touch-d55dc6f9/JOINT_TOUCH_VIDEO_CANDIDATES_SOURCE.zip,68,694 bytes,SHA2565b1796a8fb02e9c8d9ec7f59bad79b5113d9703f87a19752b7727e9371097fa4. Its source, prior failures and results remain preserved in their original directory.

## One implementation change

New web/local-background-rival.mjs predicts each native pixel's RGB from the mean on a symmetric one-pixel-thick square perimeter around it. For a full symmetric perimeter, this is also the least-squares affine-plane prediction at the center. Radius is1+ceil(maximum default ROM sprite width/height /2), which evaluates to9 for this bound source. It is neither an actual-frame setting nor a fitted value.

At each source support pixel, the algorithm compares two errors:
- source-composition RGB MSE;
- no-overlay smooth-background prediction MSE.

Gain is background error minus source error, normalized by3*255^2. Ring/dot origin proposals and the ring/shaft/head/dot joint proposals now rank by(mean role gain+minimum role gain)/2. The exact guarded raster is scored by the same rule on final opaque owner support. The no-overlay alternative has relative reference score0. This is conditional improvement on the tested support, not an absence probability or a calibrated global scene likelihood.

For a perfectly uniform, fully observed RGB image, the rival's error is0; nonnegative source error therefore cannot produce a positive gain. Affine RGB gradients are also reproduced exactly in the integer arithmetic unit fixture. Complex real backgrounds are not guaranteed to follow this rival.

The whole-scene origin scan now has35,457 positions with complete source support and background perimeter;13,695 positions remain incomplete. All prior computation budgets are unchanged:256 origin proposals,4px endpoint lattice,786,432 coarse combinations,64 refinement seeds and128 exact-raster proposals. Source-native sample convention, geometry, source guards and unknown-state behavior are unchanged. Missing perimeters are uncomputed; no extrapolation or absence inference is used. Complete rivals, incomplete cases, unsearched vectors, short-distance heading, capture and current display-state alternatives remain explicit.

## Independent controls before real replay

SEARCH_PLAN.json SHA256fa2b40a731e9448ed3482b8642dc2d7c45560f9f9fb43e0ce11a05c2e02df0d7 and all runtime source hashes were frozen before controls. No actual capture was read by the calibration script.

Three PRNG-derived source vectors, from fixed seed0x61728395, were rendered over three independent procedural backgrounds: ROM-source-mean cyan, an RGB gradient and a checker pattern. Six complete no-overlay scenes were searched independently: uniform cyan, uniform white, gradient, checker, deterministic RGB noise and a smooth colored wave. No case was dropped, and no algorithm/budget/threshold changed after seeing results.

-9 positive reference compositions: minimum gain+0.0163364945
-9 automatically ranked positive scenes: minimum top gain+0.0109655173
-6 negative whole-scene searches: maximum top gain-0.0472965286
-Exact original vector retained in1/9 positive cases. Other top hypotheses have correct origins but endpoint discrepancies of about1px, including diagonal displacement. These are retained recovery errors, not exact successes.

The declared control scores separate, but these limited source-native controls do not calibrate real capture/filter/color variation or guarantee recall. Admission threshold remains null; all candidates remain unadmitted. The inherited flat/procedural tests also preserve their prior exact-vector distinction: the flat vector ranks first exactly, while the procedural endpoint remains displaced.

## One fixed real-frame replay

All five original comparison files were read from the parent's hash-verified restore, with no modification. Runtime source and plan hashes remain identical to the pre-calibration and pre-real freezes. The new gain scores have different meaning from the predecessor's color scores and must not be compared numerically across methods.

| Frame | Top source vector | New gain | Complete/incomplete | Observation |
|---|---|---:|---:|---|
|4200|[119,99]→[109,89]|+0.0190533418|16/112|Correct ring vicinity, but arrow too short. Long arrow[119,99]→[69,52] retained at rank2,+0.0097680950.|
|1200|[127,98]→[183,116]|+0.0520150235|106/22|Follows visible arrow; predecessor ranked sky.|
|c28|[231,26]→[236,12]|-0.0253794247|16/112|Background rival outranks all evaluated complete UI hypotheses.|
|2355|[131,93]→[138,141]|+0.0861336775|111/17|Follows visible arrow; predecessor ranked sky.|
|3300|[225,25]→[236,15]|-0.0663373600|14/114|Background rival outranks all evaluated complete UI hypotheses.|

Visual agreement does not reveal the exact actual touch vector. Negative gains on evaluated hypotheses do not establish absence over the uncomputed domain. The4200 top short hypothesis still intersects8 of region18's9 original residual pixels, but does not explain the full arrow. No pixel is removed and that classification remains unchanged.

All1,563 original component IDs, ROIs and pixel counts were independently reconstructed and verified. Original native video bytes, capture files and all residual memberships remain unchanged. Private visual evidence shows the inputs, top source hypotheses and all complete candidate origins in private-evidence/FIVE_FRAME_CANDIDATES.png.

## Tests and dependencies

29 new arithmetic/scoring assertions pass, including exact constant/affine background prediction, missing perimeter behavior, input preservation, role completeness and relative-score semantics.34 inherited source/frame/video-contract assertions pass, including forged/mutated/stale candidate rejection and input changes during scanning. These63 assertions are mechanism tests, not detection successes. All1,960 complete synthetic validation outputs remain identical to the reconstructed ROM-validated producer after adding the existing provenance branch.

The verified reconstructed geometry and guarded reader are reused. Formal ROM SHA256 is3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7. No ROM, sprite, video pixel, screenshot or native-memory content is included in the source-only archive. External runtime code dependencies are hashed in evidence/DEPENDENCY_MANIFEST.json. This is not a standalone production application.

Reproduction from workspace root:

    node derive-touch-contrast-ed94b819/tests/background-rival.test.mjs
    node derive-touch-contrast-ed94b819/scripts/calibrate-controls.mjs
    node derive-touch-contrast-ed94b819/tests/rom-video-candidates.test.mjs
    node derive-touch-contrast-ed94b819/scripts/verify-validation-preservation.mjs
    node derive-touch-contrast-ed94b819/scripts/replay-fixed.mjs
    node derive-touch-contrast-ed94b819/scripts/diagnose-overlap.mjs
    python derive-touch-contrast-ed94b819/scripts/render-evidence.py

## Remaining bounded implementation need

The4200 ranking exposes a model-comparison limit: candidates are scored on their own role-normalized support, so a short arrow can earn a better local average while leaving a visible long continuation unexplained. A useful next implementation should compare rival lengths and the no-overlay explanation on a common observed domain, preserving unexplained continuation and all alternatives. Source-native sampling and capture-state uncertainty still prevent exact-vector or pixel-ownership claims. Do not cure the4200 ambiguity by choosing its known endpoint or retuning this fixed evaluation.

/* Source-bounded XZ refinement. No screen translation, time samples or preset changes. */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function percentile(a,q){const b=Array.from(a).sort((x,y)=>x-y);return b[Math.floor((b.length-1)*q)]??0;}
function gray(image){const a=new Float64Array(49152);for(let i=0;i<a.length;i++)a[i]=(image.rgba[i*4]+image.rgba[i*4+1]+image.rgba[i*4+2])/3;return a;}
function blur(a,sigma){const radius=Math.ceil(sigma*4),k=Array.from({length:2*radius+1},(_,j)=>Math.exp(-.5*((j-radius)/sigma)**2)),sum=k.reduce((a,b)=>a+b);for(let j=0;j<k.length;j++)k[j]/=sum;let tmp=new Float64Array(a.length),out=new Float64Array(a.length);const reflect=(v,n)=>{while(v<0||v>=n)v=v<0?-v-1:2*n-v-1;return v;};for(let y=0;y<192;y++)for(let x=0;x<256;x++){let s=0;for(let j=-radius;j<=radius;j++)s+=a[y*256+reflect(x+j,256)]*k[j+radius];tmp[y*256+x]=s;}for(let y=0;y<192;y++)for(let x=0;x<256;x++){let s=0;for(let j=-radius;j<=radius;j++)s+=tmp[reflect(y+j,192)*256+x]*k[j+radius];out[y*256+x]=s;}return out;}
function gradient(a){const x=new Float64Array(a.length),y=new Float64Array(a.length),n=new Float64Array(a.length);for(let py=1;py<191;py++)for(let px=1;px<255;px++){const i=py*256+px;x[i]=a[i-255]+2*a[i+1]+a[i+257]-a[i-257]-2*a[i-1]-a[i+255];y[i]=a[i+255]+2*a[i+256]+a[i+257]-a[i-257]-2*a[i-256]-a[i-255];n[i]=Math.hypot(x[i],y[i]);}return{x,y,n};}
const sample=(a,x,y)=>{const ix=Math.floor(x),iy=Math.floor(y),u=x-ix,v=y-iy,i=iy*256+ix;return(1-v)*((1-u)*a[i]+u*a[i+1])+v*((1-u)*a[i+256]+u*a[i+257]);};
/** Sample the original bounded line before local refinement. Edge registration
 * is not unimodal: golden-section elimination over the full interval can discard
 * a better basin. This is a bounded proposal, never a global-minimum proof.
 * At most 48 objective calls, below the previous line search ceiling of 52.
 */
export function lineMinimum(fn,p,d,bounds){
 let lo=-Infinity,hi=Infinity;
 for(let j=0;j<2;j++){
  if(d[j]===0)continue;
  let a=(bounds[j][0]-p[j])/d[j],b=(bounds[j][1]-p[j])/d[j];
  if(a>b)[a,b]=[b,a];lo=Math.max(lo,a);hi=Math.min(hi,b);
 }
 let calls=0;
 const at=t=>({t,point:p.map((x,j)=>clamp(x+t*d[j],...bounds[j]))});
 const evaluate=t=>{const r=at(t),value=fn(r.point);r.value=Number.isFinite(value)?value:Infinity;calls++;return r;};
 const initial=evaluate(0);let best=initial;
 if(!Number.isFinite(lo)||!Number.isFinite(hi)||hi<=lo)return{point:best.point,value:best.value};
 const samples=[];
 // Eight equal subdivisions are algorithmic sampling, not input coordinates.
 for(let i=0;i<=8;i++){
  const t=lo+(hi-lo)*i/8,r=t===0?initial:evaluate(t);
  samples.push(r);if(r.value<best.value)best=r;
 }
 // Keep the initial point in the candidate set and in the local bracket.
 if(!samples.some(r=>r.t===0)){samples.push(initial);samples.sort((a,b)=>a.t-b.t);}
 const index=samples.findIndex(r=>r.t===best.t);
 let a=samples[Math.max(0,index-1)].t,b=samples[Math.min(samples.length-1,index+1)].t;
 const ratio=(Math.sqrt(5)-1)/2;
 let c=b-ratio*(b-a),e=a+ratio*(b-a),fc=evaluate(c),fe=evaluate(e);
 if(fc.value<best.value)best=fc;if(fe.value<best.value)best=fe;
 while(calls<48&&b-a>1e-4){
  if(fc.value<fe.value){b=e;e=c;fe=fc;c=b-ratio*(b-a);fc=evaluate(c);if(fc.value<best.value)best=fc;}
  else{a=c;c=e;fc=fe;e=a+ratio*(b-a);fe=evaluate(e);if(fe.value<best.value)best=fe;}
 }
 return{point:best.point,value:best.value};
}
/** image/depth refer to the same original source camera; the result is only a
 * point hypothesis until caller rerenders native geometry and checks the video.
 * depth24 uses the original post-raster DS Z plane; unknown owners stay excluded.
 */
export async function refineGeometryPosition({position,referenceWorld=null,camera,image,depth24,knownMask,video,isCurrent=()=>true,onProgress=async()=>{}}){
 if(!position?.world||!position.coordinate?.bounds||![image,video].every(v=>v?.width===256&&v.height===192&&v.rgba?.length===196608)||depth24?.length!==49152||knownMask?.length!==49152)throw Error('Coherent bounded position, native depth/image and video required');
 const keys=['x','z'],worldKeys=['xFx','zFx'],original={...position.world},reference={...(referenceWorld??position.world)},bounds=keys.map((k,j)=>{const b=position.coordinate.bounds[k];if(!b?.inSigned32Range||!Number.isInteger(b.rawMin)||!Number.isInteger(b.rawMax)||b.rawMin>b.rawMax||!Number.isInteger(original[worldKeys[j]])||original[worldKeys[j]]<b.rawMin||original[worldKeys[j]]>b.rawMax)throw Error('Source marker interval unavailable');if(!Number.isInteger(reference[worldKeys[j]]))throw Error('Explicit reference-camera world required');return[(b.rawMin-reference[worldKeys[j]])/4096,(b.rawMax-reference[worldKeys[j]])/4096];});
 if(!Array.isArray(camera?.viewFx)||camera.viewFx.length!==16||!Array.isArray(camera.projectionFx)||camera.projectionFx.length!==16)throw Error('Explicit source camera matrices required');
 const P=camera.projectionFx.map(x=>x/4096),V=camera.viewFx.map(x=>x/4096),vx=new Float64Array(49152),vy=new Float64Array(49152),vz=new Float64Array(49152),valid=new Uint8Array(49152);for(let i=0;i<49152;i++){if(!knownMask[i]||!Number.isInteger(depth24[i])||depth24[i]<0||depth24[i]>0xffffff)continue;const z=-P[14]/(2*depth24[i]/0xffffff-1+P[10]);if(!Number.isFinite(z)||z>=0)continue;vz[i]=z;vx[i]=-z*((i%256+.5)/128-1)/P[0];vy[i]=-z*(1-(Math.floor(i/256)+.5)/96)/P[5];valid[i]=1;}
 const sourceGray=gray(image),videoGray=gray(video),steps=[];let delta=worldKeys.map((k,j)=>(original[k]-reference[k])/4096),evaluations=0;
 for(const sigma of[3,1.5,.8]){if(!isCurrent())throw new DOMException('Geometry refinement cancelled','AbortError');const a=gradient(blur(sourceGray,sigma)),b=gradient(blur(videoGray,sigma)),threshold=percentile(a.n.filter((_,i)=>valid[i]),.55),ids=[];for(let i=0;i<49152;i++){const x=i%256,y=Math.floor(i/256);if(valid[i]&&x>8&&x<248&&y>8&&y<180&&a.n[i]>threshold)ids.push(i);}if(ids.length<256)return{ready:false,reason:'Insufficient known source geometry edges',originalWorld:original,sourceBounds:position.coordinate.bounds,steps,currentCameraCertified:false};const scale=percentile(ids.map(i=>a.n[i]),.85);
 const loss=d=>{evaluations++;let numerator=0,denominator=0,count=0;const cx=V[0]*d[0]+V[8]*d[1],cy=V[1]*d[0]+V[9]*d[1],cz=V[2]*d[0]+V[10]*d[1];for(const i of ids){const z=vz[i]-cz,x=128*(P[0]*(vx[i]-cx)/-z+1)-.5,y=96*(1-P[5]*(vy[i]-cy)/-z)-.5;if(x<2||x>253||y<2||y>189)continue;const gx=sample(b.x,x,y),gy=sample(b.y,x,y),n=Math.hypot(gx,gy),w=Math.min(a.n[i]/scale,1);numerator+=w*(a.x[i]*gx+a.y[i]*gy)/((a.n[i]+5)*(n+5));denominator+=w;count++;}return denominator?1-numerator/denominator+.2*(1-count/ids.length):Infinity;};
 const before=loss(delta);let value=before,dirs=[[1,0],[0,1]];
 for(let iteration=0;iteration<12;iteration++){const start=delta.slice(),prior=value;let biggest=0,index=0;for(let j=0;j<2;j++){const old=value,r=lineMinimum(loss,delta,dirs[j],bounds);delta=r.point;value=r.value;if(old-value>biggest){biggest=old-value;index=j;}}const d=delta.map((x,j)=>x-start[j]);if(Math.hypot(...d)<1e-4||2*(prior-value)<=1e-6*(Math.abs(prior)+Math.abs(value))+1e-12)break;const r=lineMinimum(loss,delta,d,bounds);if(r.value<value){dirs[index]=dirs[1];dirs[1]=d;delta=r.point;value=r.value;}if(!isCurrent())throw new DOMException('Geometry refinement cancelled','AbortError');await onProgress({phase:'geometry',sigma,iteration,value});await new Promise(r=>setTimeout(r,0));}
 steps.push({sigma,before,loss:value,delta:delta.slice(),pixels:ids.length});
 // A prior view can leave the current marker interval entirely off-screen.
 // The optimizer then retains an infinite loss; that is no measured position.
 // Let callers retry their existing same-frame source render instead of
 // publishing the unchanged marker center as a successful refinement.
 if(!Number.isFinite(value))return{ready:false,reason:'No finite source geometry refinement outcome',originalWorld:original,referenceWorld:reference,sourceBounds:structuredClone(position.coordinate.bounds),steps,evaluations,currentCameraCertified:false,mapIdentityCertified:false,minimumProvenATCalls:0};
 await onProgress({phase:'geometry',sigma,complete:true,value});
 }
 const world=Object.fromEntries(worldKeys.map((k,j)=>[k,Math.round(reference[k]+delta[j]*4096)])),onBoundary=keys.some((k,j)=>world[worldKeys[j]]<=position.coordinate.bounds[k].rawMin||world[worldKeys[j]]>=position.coordinate.bounds[k].rawMax);
 return{ready:true,originalWorld:original,world,referenceWorld:reference,deltaWorld:worldKeys.map(k=>(world[k]-original[k])/4096),referenceDeltaWorld:delta,sourceBounds:structuredClone(position.coordinate.bounds),steps,evaluations,onBoundary,nativeRerenderRequired:true,currentCameraCertified:false,mapIdentityCertified:false,minimumProvenATCalls:0,scope:'Local source-depth geometric registration only inside original same-frame marker XZ bounds. No free pixel translation, clock search, camera preset fit, interval contraction or current-state certification.'};
}

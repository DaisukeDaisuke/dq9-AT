# Automatic joint touch-arrow candidates

Isolated source-only checkpoint. UUID d55dc6f9-05a4-49fc-886d-85f6753aa2ad. Protocol libfile_564b88200db481919e83f5494a793df9 was read before environment replacement. No external committee, Git/Library write, browser, user PC, local MCP, production import or build.sh operation was performed.

## Result

Automatic full-scene ring/shaft/head/dot candidate generation is implemented. On fixed frame4200, the top candidate follows the visible arrow, with source input hypothesis origin[119,99] and endpoint[69,52]. Its source-opaque support intersects8 of the original region18's9 residual pixels. This is a conditional template intersection, not observed pixel ownership or proof of the actual input vector.

The candidate discriminator still fails. The visible arrows in1200 and2355 are absent from the retained complete candidates; blue-sky patterns rank highest instead. The no-visible-arrow controls c28 and3300 also return background proposals. Do not activate a classifier, mask, species veto or AT consumer from this checkpoint. Threshold remains null, admitted remains false, excluded pixels remains0, and the original region18 classification is unchanged.

## Implemented modules

- web/joint-touch-search-core.mjs: browser-compatible, fixed-budget whole-scene source-color support search, joint vector proposals/refinement, per-role exact-raster scoring and explicit uncomputed alternatives.
- web/rom-touch-video-candidates.mjs: guarded ROM source loader, source-native sample convention derived from an exact ROM-only raster probe, exact video/frame/pixel binding, private candidate provenance tokens, cancellation/staleness/input-mutation checks, exact source-raster reranking and read-only evidence export.
- web/rom-touch-overlay-composition.mjs and web/rom-touch-overlay-raster.mjs: isolated copies of the reconstructed source producer. Only an automatic-video provenance branch and explicit candidate raster profile were added. The old validation path, ROM mathematics, transforms, textures and unknown flags are preserved.
- web/rom-touch-origin-overlay.mjs: byte-identical copy of the reconstructed guarded source reader.

The video entry accepts source, native frame RGBA and frame identity. It has no caller-provided player position, ROI, answer vector, map, species label or capture-fit parameters. Its source-derived probe is synthetic and unrelated to actual video coordinates. Automatically minted candidates are bound to their exact source and frame; a forged object, clone, mutation or candidate from another source is rejected. Video hypotheses are never relabelled as synthetic validation inputs.

## Fixed search

SEARCH_PLAN.json SHA25681a864b45cce3619d8daecd5d12d0d4513d7fc636a11344801225305e47d9a9f was saved before numeric actual-frame evaluation.

Each real frame scans42,657 fully-contained integer source ring/dot placements over the complete scene. It retains256 spatially diverse origins, evaluates786,432 origin/endpoint combinations on a fixed4px full-viewport endpoint lattice, retains four joint proposals per origin, and refines64 joint seeds. Origin refinement is +/-2px; endpoint refinement is +/-3px. The exact guarded native raster then evaluates128 selected proposals. Search budgets are computation limits, not acceptance gates. Unsearched byte-domain vectors, truncated candidates, clipped quads and unsupported cases remain explicit unknown alternatives.

The approximate proposal stage uses source-derived affine sprite support. The exact stage scores all final-opaque ring/shaft/head/dot support after the existing native depth composition. Each role contributes RGB MSE; the joint score is1-(mean(role errors)+max(role errors))/2. This score is an uncalibrated ranking measure, not a probability. All complete exact-ranked rivals and every incomplete exact case remain in the output; only the display shortlist is capped at32. Missing role support cannot receive a partial-success score.

Current visibility, nondefault sprite animation, short-distance actor heading, destination depth/fog, capture sampling/filter/color and absent-overlay remain unresolved. The isolated native1x pre-fog empty-destination profile does not claim final captured pixel ownership.

## Fixed actual-frame results

These are diagnostic rankings, not detections. No real-frame result changed source code, search budgets or thresholds. PRE_REAL_REPLAY_FREEZE.json binds all runtime source hashes, and the final freeze check confirms they remain identical.

| Frame | Top origin → endpoint | Score | Complete / incomplete exact cases | Visual result |
|---|---|---:|---:|---|
|4200|[119,99] → [69,52]|0.9052624418|45 /83|Follows visible arrow; actual input vector not independently known|
|1200|[112,28] → [83,40]|0.9551537335|128 /0|Sky false proposal; visible arrow missed|
|c28|[232,183] → [239,170]|0.9171580299|29 /99|Background false proposal; no visible arrow|
|2355|[94,16] → [156,7]|0.9654768539|41 /87|Sky false proposal; visible arrow missed|
|3300|[225,25] → [238,31]|0.8010623277|17 /111|Command-area/background false proposal; no visible arrow|

Per-frame runtime in this environment was about1.4–1.8s. All1,563 original connected-component memberships were independently reconstructed and matched their original IDs, ROIs and pixel counts. Every original capture file and native-video pixel hash remains unchanged. The4200 source support also intersects other residuals, which demonstrates why an approximate UI explanation cannot erase whole components or nearby body evidence. No raw region, mask, classification or AT branch was modified.

private-evidence/FIVE_FRAME_CANDIDATES.png shows originals, top source hypothesis and all complete candidate origins. Private files also contain full registrations and pixel planes. They are excluded from the source-only ZIP.

## Bounded tests and preserved failures

36 pure-core generated-fixture assertions cover complete-scene iteration, deterministic ranking, integer candidates, untouched inputs, cancellation, malformed inputs and required four-role support.34 additional ROM/source/video-contract assertions cover forged candidates, wrong raster provenance, source/frame/pixel binding, missing/stale/changed input, changes during scanning, clone/mutation rejection and read-only raster export. These70 assertions are mechanism tests, not70 successful video detections.

Two source-native generated full scenes were declared before real replay. After the source-native sample-convention correction, the flat-background case returns the exact origin/endpoint at rank0 with score1. The procedural-background case still does not retain its exact vector; its top hypothesis has the correct origin but a shorter endpoint. That failure is data in ROM_VIDEO_TESTS.json rather than a success assertion rewritten to pass.

First run: both synthetic exact vectors were missed. The cause included a naive sprite-paste sampling convention that was one row above the actual isolated native raster. The loader now derives the integer sample offset from its ROM-only default dot probe and verifies the entire dot support and RGBA mapping. It does not hardcode the row offset or infer it from a video. Initial source files, first failed synthetic summary and the inspection log are retained. The remaining procedural miss was not tuned away.

The reconstructed geometry dependency separately passed1,960 ROM executions /45,080 geometry comparisons,74 guard tests, and256 byte-identical independently sourced raster comparisons. Those are the geometry worker's bounded source evidence, not new real-video validation or an all-input guarantee from this task. A separate regression check confirms all1,960 complete validation output objects remain identical after the provenance-only extension.

## Environment recovery and provenance

A confirmed container replacement removed the original task directories after they were read. The original40,097-byte producer ZIP was not recovered byte-for-byte. This task uses restore-touch-geometry-4d501e2a's newly reconstructed, independently revalidated producer. Its original composition SHA256 is8da345803b2984a29cb4a6bfd8d9967a29e839d3a66031b608577960ce61bb62; raster SHA256 is5eae68d2c9a116486e264449f3258acf94f32c0516ad22042453637cd05913a9. The source reader SHA256 is56070250705e0445c7b83e39881a9c40b8a81f4f50bf8323545f64045e79e6fb. SOURCE_ADAPTER_DIFF.json records the isolated new hashes. No old matcher, old calibration, old threshold or original capture was edited.

Formal ROM: recovery-20261006-0852/verified/dq9_new2.nds, SHA2563c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7. Renderer import closure is read-only under recovery-20261006-0852/current-dq9-AT. The parent restored27 capture inputs with their full manifest hashes; this task reads the five original comparison files directly under recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005.

## Reproduction and next bounded work

From workspace root:

    node derive-video-touch-d55dc6f9/tests/search-core-mechanics.test.mjs
    node derive-video-touch-d55dc6f9/tests/rom-video-candidates.test.mjs
    node derive-video-touch-d55dc6f9/scripts/replay-fixed.mjs
    node derive-video-touch-d55dc6f9/scripts/diagnose-overlap.mjs
    python derive-video-touch-d55dc6f9/scripts/render-evidence.py

The checkpoint is not a standalone application; external renderer/ROM/fixed-capture dependencies are recorded. It contains no ROM bytes, decoded source sprites, video pixels or private source-polygon recipes.

Next useful implementation is a source-derived spatial contrast / foreground-versus-background explanation that rejects uniform cyan/sky support without fitting the failed actual frames, while preserving origin/endpoint alternatives lost by the current beam. Capture-phase/filter hypotheses and an independent admission calibration remain necessary. The present bounded task stops at executable candidate generation plus its exact limitations; it does not claim general UI detection, the region18 fix, automatic player identification or all-input automation.

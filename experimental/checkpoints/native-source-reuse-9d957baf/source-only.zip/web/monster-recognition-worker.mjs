import {NitroFS} from './vendor/nitro-fs.mjs';
import {parseMonsterAssetCatalog} from './monster-assets.mjs';
import {MonsterGeometry} from './monster-geometry.mjs?v=field-stream-20261005-1108';
import {createDinoFeatureBackend} from './monster-dinov2.mjs?v=recognition-cache-20261005-1007';
import {createFeatureBankStore} from './monster-feature-cache.mjs';
import {recognizeROI,supplementEnemyROIs,prepareDinoPoseBank,createRenderedReferenceCache} from './monster-recognition-engine.mjs?v=stored-pivot-source-20261006-0800';
let state=null,epoch=0,active=null,nativeBodyModulePromise=null;
const loadNativeBodyModule=()=>nativeBodyModulePromise??=import('./monster-native-auto-support.mjs?v=native-source-reuse-20261006-1028').catch(error=>{nativeBodyModulePromise=null;throw error;});
const post=message=>self.postMessage(message);
self.onmessage=async({data:m})=>{
 if(!m||!['load','recognize','supplement','prepare','native-body-support','cancel'].includes(m.type))return;
 if(m.type==='cancel'){
  // Targeted optional expiry must never abort a newer appearance request.
  // ID-free cancellation remains supported for the other existing clients.
  const targeted=typeof m.id==='string';
  if(!targeted||(active?.requestId===m.id&&active?.romEpoch===m.romEpoch)){active?.abort();active=null;}
  if(targeted)post({type:'cancelled',id:m.id,romEpoch:m.romEpoch});return;
 }
 const id=m.id,romEpoch=m.romEpoch;let requestEpoch=epoch,controller=null,stage=m.type;
 try{
  if(typeof id!=='string'||!id||!Number.isSafeInteger(romEpoch)||romEpoch<0)throw Error('要求の識別情報が不正です');
  if(m.type==='load'){
   active?.abort();active=null;const previous=state;state=null;const mine=++epoch;requestEpoch=mine;previous?.renderedReferenceCache.clear();previous?.nativeBodySupport?.dispose();await previous?.dino?.dispose();
   if(!(m.rom instanceof ArrayBuffer)||m.rom.byteLength<512||m.rom.byteLength>512*1024*1024)throw Error('NDSは512MiB以下のファイルを選んでください');
   if(new TextDecoder().decode(new Uint8Array(m.rom,12,4))!=='YDQJ')throw Error('日本語版DQ9 (YDQJ) のNDSを選んでください');
   const [romDigest,csvResponse,wasmResponse]=await Promise.all([crypto.subtle.digest('SHA-256',m.rom),fetch(new URL('./data/monsters.csv',import.meta.url)),fetch(new URL('./wasm/monster_geometry.wasm',import.meta.url))]);if(!csvResponse.ok||!wasmResponse.ok)throw Error('識別用のコード・カタログを読み込めません');
   const catalog=parseMonsterAssetCatalog(await csvResponse.text()),{instance}=await WebAssembly.instantiate(await wasmResponse.arrayBuffer(),{});if(mine!==epoch)return;
   state={rom:new Uint8Array(m.rom),nitro:NitroFS.fromRom(m.rom),catalog,geometry:new MonsterGeometry(instance),romEpoch,romSHA256:Array.from(new Uint8Array(romDigest),v=>v.toString(16).padStart(2,'0')).join(''),featureStore:createFeatureBankStore(),renderedReferenceCache:createRenderedReferenceCache()};post({type:'loaded',id,romEpoch,catalog:[...catalog].map(([modelId,speciesCandidates])=>({modelId,speciesCandidates}))});return;
  }
  if(!state||state.romEpoch!==romEpoch)throw Error('現在のNDSを読み込み直してください');active?.abort();controller=new AbortController();controller.requestId=id;controller.romEpoch=romEpoch;const mine=epoch;active=controller;
  const runState=state,onProgress=p=>{if(active===controller&&mine===epoch){if(typeof p.phase==='string'&&p.phase)stage=p.phase==='init'?`${m.inferenceBackend??'wasm'}-init`:p.phase;post({type:'progress',id,romEpoch,...p});}};
  if(m.type==='native-body-support'){
   const budget=m.budget;
   if(!Number.isFinite(budget?.wallTimeMs)||budget.wallTimeMs<=0||budget.wallTimeMs>1500||!Number.isSafeInteger(budget.maxProposals)||budget.maxProposals<=0||budget.maxProposals>128)throw Error('Explicit native frame-job budget exceeds 1500 ms / 128 proposals');
   if(m.request?.backgroundEvidence?.romSHA256!==runState.romSHA256)throw Error('Native body request ROM differs from loaded ROM');
   const started=performance.now();
   // Cache only the import promise. A canceled cold import cannot construct
   // heavy source state when it later resolves alongside a newer DINO request.
   if(!runState.nativeBodySupport){
    const {createAutomaticNativeBodySupportService}=await loadNativeBodyModule();
    if(active!==controller||mine!==epoch||controller.signal.aborted)throw new DOMException('中止','AbortError');
    if(performance.now()-started>=budget.wallTimeMs)throw Error('Native optional import exhausted the cooperative job budget; body work remains unknown');
    runState.nativeBodySupport=createAutomaticNativeBodySupportService({rom:runState.rom,catalog:runState.catalog,geometry:runState.geometry,romSHA256:runState.romSHA256,nitro:runState.nitro});
   }
   const service=runState.nativeBodySupport;
   const remaining=budget.wallTimeMs-(performance.now()-started);
   if(remaining<=0)throw Error('Native source preparation exhausted the cooperative job budget; body work remains unknown');
   const result=await service.evaluate(m.request,{signal:controller.signal,getCurrentFrame:()=>active===controller&&mine===epoch&&!controller.signal.aborted?{...m.request.videoEvidence,romSHA256:runState.romSHA256}:null,budget:{wallTimeMs:remaining,maxProposals:budget.maxProposals},onProgress});
   if(active!==controller||mine!==epoch||controller.signal.aborted)return;active=null;post({type:'result',id,romEpoch,result});return;
  }
  const getDino=async({backend:provider='wasm'}={})=>{if(runState.dino?.spec.backend===provider)return runState.dino;const previous=runState.dino,previousStage=stage;runState.dino=null;runState.renderedReferenceCache.clear();stage='backend-dispose';await previous?.dispose();stage=`${provider}-init`;const backend=await createDinoFeatureBackend({backend:provider,signal:controller.signal,onProgress});if(active!==controller||mine!==epoch){await backend.dispose();throw new DOMException('中止','AbortError');}runState.dino=backend;stage=previousStage;return backend;};
  const outcome=await (m.type==='prepare'?prepareDinoPoseBank:m.type==='supplement'?supplementEnemyROIs:recognizeROI)(m,{...runState,cacheQuery:true,cachePartialPoses:true,signal:controller.signal,onProgress,getDino});
  const result=m.type==='prepare'?{prepared:true,timings:outcome.timings,cacheWarnings:outcome.cacheWarnings}:outcome;
  if(active!==controller||mine!==epoch)return;active=null;post({type:'result',id,romEpoch,result});
 }catch(error){if(error?.name==='AbortError'||requestEpoch!==epoch||(controller&&active!==controller))return;const detail={name:typeof error?.name==='string'?error.name:'Error',message:String(error?.message??error),stack:typeof error?.stack==='string'?error.stack:'',stage:typeof error?.stage==='string'&&error.stage?error.stage:stage};post({type:'error',id,romEpoch,message:detail.message,error:detail});}
};

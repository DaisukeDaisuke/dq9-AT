// This imports immutable existing fixtures only after parent-confirmed restoration.
// No labels, residuals, masks or known coordinates enter candidate registration.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { openMapRom } from '../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/static-scene.mjs';
import { readArm9Overlay } from '../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/rom-overlay.mjs';
import { cases, fixture } from './restored-fixtures.mjs';
import { loadJointTouchVideoSource, registerJointTouchVideoCandidates,
  snapshotJointCandidateRaster } from '../web/rom-touch-video-candidates.mjs';
const root = 'derive-touch-contrast-ed94b819/';
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const rom = fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds');
assert.equal(hash(rom),'3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7');
const source = await loadJointTouchVideoSource({...openMapRom(rom),romSHA256:hash(rom),fieldOverlay:readArm9Overlay(rom,17)});
const results = [];
for (const test of cases) {
  const f = fixture(test), before = {pixels:hash(f.image.rgba),captureFile:hash(fs.readFileSync(f.path)),components:JSON.stringify(f.cmp.components)};
  const start = performance.now();
  const registration = await registerJointTouchVideoCandidates(source,f.image,{frame:f.frame});
  const elapsedSeconds = (performance.now()-start)/1000;
  assert.equal(hash(f.image.rgba),before.pixels);assert.equal(hash(fs.readFileSync(f.path)),before.captureFile);
  assert.equal(JSON.stringify(f.cmp.components),before.components);
  assert.equal(registration.threshold,null);assert.equal(registration.excludedPixels,0);
  const detail = {id:f.id,comparisonPath:f.path,comparisonSHA256:f.comparisonSHA256,elapsedSeconds,registration,
    originalRegionCount:f.cmp.components.length,rawPixelsUnchanged:true,originalCaptureFileUnchanged:true,originalComponentsUnchanged:true};
  fs.writeFileSync(root+'private-evidence/REGISTRATION_'+f.id+'.json',JSON.stringify(detail,null,2));
  fs.writeFileSync(root+'private-evidence/VIDEO_'+f.id+'.rgba',f.image.rgba);
  if (registration.candidates.length) {
    const raster = await snapshotJointCandidateRaster(source,registration,0,f.image,f.frame);
    fs.writeFileSync(root+'private-evidence/TOP_RASTER_'+f.id+'.rgba',raster.rgba);

  }
  const summary = {...detail,registration:undefined,frame:f.frame,statistics:registration.statistics,
    top:registration.candidates.slice(0,5).map(c=>({origin:c.candidate.origin,endpoint:c.candidate.endpoint,score:c.exact.score,roleErrors:c.exact.roleErrors,backgroundErrors:c.exact.backgroundErrors,roleGains:c.exact.roleGains})),
    unknownAlternatives:registration.unknownAlternatives,threshold:null,admitted:false,excludedPixels:0};
  results.push(summary);console.log(JSON.stringify(summary));
}
fs.writeFileSync(root+'evidence/FIVE_FRAME_RESULTS.json',JSON.stringify(results,null,2));

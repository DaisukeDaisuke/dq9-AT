// Candidate-only no-overlay rival. Radius is supplied by the guarded ROM adapter,
// never fitted to a real frame. No exterior perimeter means uncomputed evidence.
const need=(x,message)=>{if(!x)throw Error(message);};
export function buildLocalBackgroundRival(image,radius){
 need(Number.isInteger(radius)&&radius>=1&&radius<=255,'Source-derived native-pixel radius required');
 need(Number.isInteger(image?.width)&&Number.isInteger(image?.height)&&image.width>0&&image.height>0&&
  (image.rgba instanceof Uint8Array||image.rgba instanceof Uint8ClampedArray)&&image.rgba.length===image.width*image.height*4,'Byte RGBA image required');
 const W=image.width,H=image.height,stride=W+1,integral=Array.from({length:4},()=>new Float64Array((W+1)*(H+1)));
 for(let y=0;y<H;y++){const sums=[0,0,0,0];for(let x=0;x<W;x++){const i=(y*W+x)*4,j=(y+1)*stride+x+1;
  for(let c=0;c<4;c++){sums[c]+=c===3?(image.rgba[i+3]===255?1:0):image.rgba[i+c];integral[c][j]=integral[c][j-stride]+sums[c];}}}
 const box=(plane,x0,y0,x1,y1)=>plane[(y1+1)*stride+x1+1]-plane[y0*stride+x1+1]-plane[(y1+1)*stride+x0]+plane[y0*stride+x0];
 const errors=new Float64Array(W*H),valid=new Uint8Array(W*H),predictedRGB=new Float64Array(W*H*3),count=8*radius;
 let observedPixels=0;
 for(let y=radius;y<H-radius;y++)for(let x=radius;x<W-radius;x++){
  const i=y*W+x,outer=box(integral[3],x-radius,y-radius,x+radius,y+radius),inner=box(integral[3],x-radius+1,y-radius+1,x+radius-1,y+radius-1);
  if(image.rgba[i*4+3]!==255||outer-inner!==count)continue;
  let error=0;
  for(let c=0;c<3;c++){const value=(box(integral[c],x-radius,y-radius,x+radius,y+radius)-box(integral[c],x-radius+1,y-radius+1,x+radius-1,y+radius-1))/count;
   predictedRGB[i*3+c]=value;error+=(image.rgba[i*4+c]-value)**2;}
  errors[i]=error/(3*255*255);valid[i]=1;observedPixels++;
 }
 return{schema:'dq9-local-no-overlay-background-rival-v1',width:W,height:H,radius,errors,valid,predictedRGB,observedPixels,
  uncomputedPixels:W*H-observedPixels,relativeReferenceScore:0,
  scope:'Center prediction of a local smooth background from a symmetric exterior square perimeter; equivalently affine-plane center prediction. No global scene, ownership or probability claim.'};
}
export function jointContrastScore(sourceErrors,backgroundErrors){
 need(sourceErrors.length===backgroundErrors.length&&sourceErrors.length>=2&&
  [...sourceErrors,...backgroundErrors].every(v=>Number.isFinite(v)&&v>=0&&v<=1),'Normalized source/background role errors required');
 const gains=sourceErrors.map((error,i)=>backgroundErrors[i]-error);
 return(gains.reduce((a,b)=>a+b,0)/gains.length+Math.min(...gains))/2;
}
export function backgroundErrorAt(model,x,y){
 x=Math.floor(x);y=Math.floor(y);if(x<0||y<0||x>=model.width||y>=model.height)return null;
 const i=y*model.width+x;return model.valid[i]?model.errors[i]:null;
}

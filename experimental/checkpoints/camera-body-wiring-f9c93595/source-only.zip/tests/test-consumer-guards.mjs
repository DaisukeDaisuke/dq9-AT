import fs from'node:fs';import assert from'node:assert/strict';import{createVideoTrackingAT}from'../web/map-browser-preview/video-tracking-at.mjs';
const root='wire-camera-body-alternative-f9c93595/',bundle=JSON.parse(fs.readFileSync(root+'evidence/WIRED_C28_BUNDLE.json')),tables=JSON.parse(fs.readFileSync(root+'web/data/enc.json')).main,mutations=[
 ['compact-score',s=>s.cameraBodyAlternative.branches[0].candidates[0].pixelErrorReduction++],
 ['compact-reference',s=>s.cameraBodyAlternative.branches[0].candidates[0].sourceEvidenceReference.modelId='other'],
 ['owned-score',s=>s.classificationEvidence[0].rankings[0].sourceNativeSupport.branches[0].best.fit.pixelErrorReduction++],
 ['owned-extent-frame',s=>s.classificationEvidence[0].rankings[0].sourceNativeSupport.branches[0].best.nativeBodyExtent.frame.mediaTime++],
 ['missing-owned-camera',s=>s.classificationEvidence[0].rankings[0].sourceNativeSupport.branches.pop()],
 ['missing-claimed-model',s=>s.cameraBodyAlternative.branches[0].candidates.pop()],
 ['claimed-frame',s=>s.cameraBodyAlternative.frame.fullRGBA_SHA256='0'.repeat(64)],
 ['claimed-species-subset',s=>s.cameraBodyAlternative.speciesCandidates=[]],
 ['missing-true-alias',s=>s.modelAliases.find(a=>a.modelId==='z019b').speciesCandidates=[]],
 ['missing-unknown',s=>s.cameraBodyAlternative.noEventPossible=false],
 ['certification-claim',s=>s.cameraBodyAlternative.identityCertified=true],
 ['certified-observation-claim',s=>s.cameraBodyAlternative.certifiedObservation=true],
 ['conditional-only-removed',s=>delete s.cameraBodyAlternative.conditionalHypothesisOnly]
],checks=[];
const run=async(b,name)=>{let preparations=0,starts=0,manual=0;const states=[],controller=createVideoTrackingAT({getOptions(){manual++;throw Error('No manual options');},getTables:()=>tables,engineRevision:'camera-wire-guard',onState:s=>states.push(s),prepare:async()=>{preparations++;throw Error('Invalid optional evidence scheduled');},startSession(){starts++;throw Error('Invalid start');}});await controller.observe(b);assert.equal(preparations,0,name);assert.equal(starts,0,name);assert.equal(manual,0,name);assert.equal(states.at(-1).status,'waiting');checks.push(name);};
for(const[name,mutate]of mutations){const b=structuredClone(bundle);mutate(b.sightings.find(s=>s.originalProposalId==='12'));await run(b,name);}
{const b=structuredClone(bundle);b.source.background.automaticSearch.backgroundCandidates[2].accepted=false;await run(b,'complete-retained-map-camera-domain-changed');}
{const b=structuredClone(bundle);b.source.modelPlan.models.find(m=>m.modelId==='z019b').origins=[];await run(b,'missing-own-enc-origin');}
{const b=structuredClone(bundle);b.source.video={...b.source.video,mediaTime:b.source.video.mediaTime+1};await run(b,'different-current-source-frame');}
{const b=structuredClone(bundle);b.debugOnly=true;await run(b,'existing-debug-input-policy-preserved');}
{const b=structuredClone(bundle);b.source.ramSHA256='0'.repeat(64);await run(b,'existing-memory-input-policy-preserved');}
const out={passed:true,checks,rejectedBeforePreparation:true,workerStarts:0,manualOptionsReads:0,scope:'Mutated compact claims and missing/stale owned evidence cannot schedule AT; existing production input guards remain active.'};fs.writeFileSync(root+'evidence/CONSUMER_GUARDS_RESULT.json',JSON.stringify(out,null,2));console.log(out);

# Complete independent-reverse diagnostic

Held isolated diagnostic; extra computation is measured, not a production budget change. The equal594-cost negative checkpoint remains immutable.

Every forward-feasible candidate within the original coarse/fine search's tested domain receives its own complete original reverse search. There is no answer-based early stop. A candidate only continues if the independent reverse best is unique and exactly returns to the source, followed by the unchanged single-patch association gate. Numeric gates, samples, clipping, displacement bounds and source gap are unchanged. Forward need not be the unique best. Fixed reciprocal SAD alone never confirms a match.

The finite work ceiling is priorPositionCount *297*(1+297): the maximum original forward cost domain plus a complete reverse search for every possibly feasible tested offset. This is an offline diagnostic ceiling, not a claimed realtime budget. It does not enumerate all961 integer forward offsets; original search-domain omissions remain unknown. Identical positions only coalesce within one original track and retain parent references. No native-memory truth, model selection, chosen actor identity or AT consumer is involved.

## Result

Residual12, visible orange monster: eight verified0.1s patch-continuation steps versus four in the original lane. Exactly one path survives each pair through171.112, instead of baseline170.712. At170.812 all six forward-feasible positions receive reverse searches; only(4,-1) returns uniquely with(-4,+1). The original best(4,-2) still fails and is preserved.

Inspection of the actual video pixels confirms the four extra boxes remain around the visible orange monster. At171.112 its full ROI hypothesis is(9,-3,22,33), while observedROI is(9,0,22,30),660 in-frame pixels and66 offscreen/unobserved. At171.212 part of the monster is still visible, but all five feasible candidates fail independent reverse verification. The best forward(0,-9) has462 known samples and SAD11.1732; its independent reverse best is(-5,-14). That loss is preserved, not interpreted as disappearance.

Fixed negatives retain exactly the original verified lifetimes: r17/r31 zero, r51 seven steps, fragmented r99 six and r120/r126/r131/r141 zero, holdout r371 four. No persistent multiple accepted positions occur in these selected single-original trials. This is not a guarantee for other objects, multiple actors or all inputs. Species, identity and draw certification remain false.

## Cost and limits

Orange requires20,787 displacement-cost evaluations, with up to5,049 on a pair. Initial headless baseline40.79ms versus complete189.41ms; final43.24ms versus162.02ms. r51 requires100,053 evaluations with no retention improvement: initial64.3ms versus876.1ms, final58.21ms versus808.55ms. Both timing sets and all negative rows are retained. Warmup/noise prevent general performance claims; the overhead is substantial.

Eight checks pass: complete independent reverse coverage/no omissions, exact orange lifetime, unique170.812 alternative, partial-edge support, preserved171.212 failure, unchanged fixed negatives/cost, reverse numeric failure handling and unchanged equal-budget checkpoint. The complete helper also distinguishes a terminal reverse texture/sample gate failure from unverified budget work. This metadata case was absent from all actual equal-budget runs, whose checkpoint is unchanged.

## Reproduction

From the authorized workspace root run `tests/measure-complete.mjs orange` under this directory, then repeat with legacy, fragmented and holdout. Run `tests/complete-reverse.test.mjs`. These require the previously saved actual crops/logs, original browser comparison JSONs and frozen replay source. The first seed is exact browser RGBA; later frames are FFmpeg actual PTS frames. Mixed-decoder evidence is not browser pixel parity. Source serial/hash metadata is not copied onto later frames.

This source-only checkpoint includes full diagnostic source, scripts/tests, summaries, patch, README, manifests and baseline source dependency hashes. Private images, video-derived masks/pixels, ROM, videos, game assets and emulator states are excluded. The private contact sheet remains local. No classifier/controller/production/AT changes are included. The next optimization, if separately justified, must preserve these accepted paths exactly rather than loosen reverse checks.

// Isolated automatic video candidate adapter. No production website import exists.
// Source composition/raster dependencies must be restored unchanged before testing.
import { loadTouchOverlayComposition, produceTouchOverlayPolygons,
  snapshotTouchCompositionForRaster } from './rom-touch-overlay-composition.mjs';
import { rasterTouchOverlayValidation } from './rom-touch-overlay-raster.mjs';
import {buildLocalBackgroundRival} from './local-background-rival.mjs';
import { sha256 } from './rom-touch-origin-overlay.mjs';
import { searchJointTouchVectors, scoreExactJointRaster, SEARCH_BUDGET,
  JOINT_SEARCH_PLAN_SHA256 } from './joint-touch-search-core.mjs';
const sources = new WeakMap(), candidates = new WeakMap(), registrations = new WeakMap();
const need = (x, message) => { if (!x) throw Error(message); };
const sourceKey = s => JSON.stringify(s);
function own(source) {
  const data = sources.get(source);
  need(data && data.key === sourceKey(source), 'Unknown or mutated joint video source');
  return data;
}
function frameKey(frame) {
  need(frame && ['romSHA256','sourceId','sourceEpoch','timelineSegment','mediaTime','nativeRGBA_SHA256'].every(k => frame[k] !== undefined && frame[k] !== null) &&
    /^[a-f0-9]{64}$/.test(frame.romSHA256) && /^[a-f0-9]{64}$/.test(frame.nativeRGBA_SHA256) &&
    typeof frame.sourceId === 'string' && frame.sourceId.length && Number.isSafeInteger(frame.sourceEpoch) && frame.sourceEpoch >= 0 &&
    Number.isSafeInteger(frame.timelineSegment) && frame.timelineSegment >= 0 && Number.isFinite(frame.mediaTime) && frame.mediaTime >= 0,
    'Exact ROM/video/frame/pixel binding required');
  return JSON.stringify(Object.fromEntries(['romSHA256','sourceId','sourceEpoch','timelineSegment','mediaTime','nativeRGBA_SHA256'].map(k => [k,frame[k]])));
}
function imageValid(image, source) {
  need(image?.width === source.viewport.width && image?.height === source.viewport.height &&
    (image.rgba instanceof Uint8Array || image.rgba instanceof Uint8ClampedArray) && image.rgba.length === image.width * image.height * 4,
    'Native source-viewport byte RGBA required');
}
/** Construct static source ring/dot support only for proposals. Shaft/head overdraw
 * is not assumed here; final reranking requires all four exact depth-composited roles. */
function makeOriginPoints(sprites, transform) {
  const pixelMap = new Map();
  for (const index of [0,3]) {
    const s = sprites[index], offset = index ? transform.dotOffset : transform.ringOffset;
    for (let y = 0; y < s.height; y++) for (let x = 0; x < s.width; x++) {
      const i = (y * s.width + x) * 4;
      if (s.rgba[i + 3] !== 255) continue;
      const px = x + offset.x, py = y + offset.y;
      pixelMap.set(px + ',' + py, { role: index === 0 ? 0 : 1, x: px + .5, y: py + .5,
        rgb: Array.from(s.rgba.subarray(i,i+3)) });
    }
  }
  return [0,1].map(role => [...pixelMap.values()].filter(p => p.role === role));
}
function deriveNativeSampleOffset(composition, probe, sprites, origin) {
  const raster = rasterTouchOverlayValidation(composition,probe,{profile:'isolated-source-validation-native1x-Z-pre-fog'});
  need(raster.isolatedRasterReady, 'Source probe raster unavailable');
  const dot = sprites[3], points = [], observed = [];
  for(let y=0;y<dot.height;y++)for(let x=0;x<dot.width;x++)if(dot.rgba[(y*dot.width+x)*4+3]===255)points.push([x,y]);
  for(let i=0;i<raster.owner.length;i++)if(raster.owner[i]===3&&raster.rgba[i*4+3]===255)observed.push([i%raster.width,Math.floor(i/raster.width)]);
  need(points.length===observed.length&&points.length>0,'Source dot support incomplete in sample-convention probe');
  const offset = [0,1].map(axis=>Math.min(...observed.map(p=>p[axis]))-origin[axis]-composition.transform.dotOffset[axis?'y':'x']-Math.min(...points.map(p=>p[axis])));
  for(const [x,y] of points){const px=origin[0]+composition.transform.dotOffset.x+x+offset[0],py=origin[1]+composition.transform.dotOffset.y+y+offset[1],i=(py*raster.width+px)*4,j=(y*dot.width+x)*4;
    need(raster.owner[i/4]===3&&[0,1,2,3].every(c=>raster.rgba[i+c]===dot.rgba[j+c]),'Source-native dot sampling convention not exact');}
  return offset;
}
export async function loadJointTouchVideoSource(options) {
  const composition = await loadTouchOverlayComposition(options);
  // This source-only probe is never influenced by a real video or chosen location.
  const origin = [Math.floor(composition.viewport.width / 2),Math.floor(composition.viewport.height / 2)];
  const endpoint = [origin[0],Math.min(255,origin[1] + 44)];
  const probe = produceTouchOverlayPolygons(composition,{schema:'dq9-touch-vector-validation-candidate-v1',
    provenance:'synthetic-source-validation',origin,endpoint});
  const snapshot = snapshotTouchCompositionForRaster(composition,probe);
  const model = { sprites: snapshot.sprites, constants: structuredClone(composition.constants),
    originPoints: makeOriginPoints(snapshot.sprites,composition.transform),
    sampleOffset: deriveNativeSampleOffset(composition,probe,snapshot.sprites,origin),
    backgroundRadius:1+Math.ceil(Math.max(...snapshot.sprites.flatMap(s=>[s.width,s.height]))/2) };
  const result = {schema:'dq9-rom-joint-touch-video-source-v1',romSHA256:composition.romSHA256,
    resources:structuredClone(composition.sourceSprites),sourceCode:structuredClone(composition.sourceCode),
    viewport:structuredClone(composition.viewport),sourceNativeSampleOffset:model.sampleOffset.slice(),backgroundRadiusSourceDerived:model.backgroundRadius,planSHA256:JOINT_SEARCH_PLAN_SHA256,
    scope:'Ordinary/default four-sprite source geometry; current visibility, destination, fog and capture state remain unknown'};
  sources.set(result,{key:sourceKey(result),composition,model});
  return result;
}
function bindCandidate(source, data, frame, proposal) {
  const candidate = {schema:'dq9-touch-vector-video-candidate-v1',provenance:'automatic-full-scene-video-search',
    origin:proposal.origin.slice(),endpoint:proposal.endpoint.slice(),frame:structuredClone(frame),planSHA256:JOINT_SEARCH_PLAN_SHA256};
  candidates.set(candidate,{source,composition:data.composition,key:JSON.stringify(candidate)});
  return candidate;
}
/** Verification-only export used by the extended composition producer. There is no
 * public constructor for arbitrary video coordinates. A clone or changed token fails. */
export function snapshotJointVideoCandidate(compositionSource, candidate) {
  const data = candidates.get(candidate);
  need(data && data.composition === compositionSource && data.key === JSON.stringify(candidate),
    'Unknown, mutated or unbound automatic video candidate');
  own(data.source);
  return structuredClone(candidate);
}
export async function registerJointTouchVideoCandidates(source, image, options = {}) {
  need(Object.keys(options).every(k => ['frame','getCurrentFrame','signal'].includes(k)), 'Unexpected video candidate input; no position or ROI parameters allowed');
  const {frame,getCurrentFrame=()=>frame,signal=null} = options, data = own(source), key = frameKey(frame);
  imageValid(image,source); need(frame.romSHA256 === source.romSHA256, 'Source/video ROM differs');
  need(await sha256(image.rgba) === frame.nativeRGBA_SHA256, 'Frame pixels differ');
  const checkCurrent = () => { own(source); need(!signal?.aborted && frameKey(getCurrentFrame()) === key, 'Cancelled or stale video frame'); };
  checkCurrent();
  const backgroundModel = buildLocalBackgroundRival(image,data.model.backgroundRadius);
  const proposal = await searchJointTouchVectors(image,data.model,{checkCurrent,backgroundModel,
    yieldTask:()=>new Promise(resolve=>setTimeout(resolve,0))});
  const scored = [], incomplete = [];
  for (let i = 0; i < proposal.proposals.length; i++) {
    checkCurrent();
    const p = proposal.proposals[i], token = bindCandidate(source,data,frame,p);
    const geometry = produceTouchOverlayPolygons(data.composition,token);
    const clippedQuad = geometry.polygons.some(p => p.vertices.some(v => v.positionFx[0] < 0 || v.positionFx[1] < 0 ||
      v.positionFx[0] > image.width * 4096 || v.positionFx[1] > image.height * 4096));
    const raster = clippedQuad ? null : rasterTouchOverlayValidation(data.composition,geometry,{profile:'isolated-video-candidate-native1x-Z-pre-fog'});
    const exact = clippedQuad ? {complete:false,reason:'Clipped source quad remains uncomputed in this bounded capture profile'} : scoreExactJointRaster(image,raster,{backgroundModel});
    const row = {candidate:token,approximateScore:p.score,exact,
      geometryReady:geometry.geometryReady,unknown:true,admitted:false,pixelOwnershipVerified:false,safeForHardPruning:false};
    if (exact.complete) scored.push(row); else incomplete.push(row);
    if (i % 8 === 7) await new Promise(resolve=>setTimeout(resolve,0));
  }
  scored.sort((a,b)=>b.exact.score-a.exact.score || a.candidate.origin[1]-b.candidate.origin[1] ||
    a.candidate.origin[0]-b.candidate.origin[0] || a.candidate.endpoint[1]-b.candidate.endpoint[1] || a.candidate.endpoint[0]-b.candidate.endpoint[0]);
  checkCurrent(); need(await sha256(image.rgba) === frame.nativeRGBA_SHA256, 'Frame pixels changed during search'); checkCurrent();
  const result = {schema:'dq9-joint-touch-video-registration-v1',frame:structuredClone(frame),source:structuredClone(source),
    candidates:scored,incompleteCandidates:incomplete,displayedCandidateCount:Math.min(scored.length,SEARCH_BUDGET.displayed),
    statistics:{...proposal.statistics,completeExactCandidates:scored.length,incompleteExactCandidates:incomplete.length},
    unknownAlternatives:proposal.unknownAlternatives,planSHA256:JOINT_SEARCH_PLAN_SHA256,threshold:null,
    searchExhaustive:false,unknown:true,admitted:false,observedCompositionReady:false,pixelOwnershipVerified:false,
    safeForHardPruning:false,excludedPixels:0,bodyDecision:'unchanged',
    scope:'Automatic bounded full-scene four-sprite versus local-background candidates only. No overlay-presence, ownership, player, monster, mask or AT decision. All exact-ranked rivals retained.'};
  registrations.set(result,{source,key:JSON.stringify(result),frameKey:key,pixels:frame.nativeRGBA_SHA256});
  return result;
}
/** Read-only evidence export. It cannot accept a candidate from another frame or
 * source and never erases a pixel or supplies a player/species label. */
export async function snapshotJointCandidateRaster(source,registration,index,image,frame) {
  const data = own(source), bound = registrations.get(registration);
  need(bound && bound.source === source && bound.key === JSON.stringify(registration) && bound.frameKey === frameKey(frame),
    'Unknown, changed or unbound video registration');
  imageValid(image,source); need(await sha256(image.rgba) === bound.pixels, 'Changed video pixels');
  need(Number.isInteger(index) && index >= 0 && index < registration.candidates.length, 'Candidate index out of range');
  const candidate = registration.candidates[index].candidate;
  const geometry = produceTouchOverlayPolygons(data.composition,candidate);
  return rasterTouchOverlayValidation(data.composition,geometry,{profile:'isolated-video-candidate-native1x-Z-pre-fog'});
}

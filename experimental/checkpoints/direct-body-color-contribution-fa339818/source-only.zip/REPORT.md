# Direct body-color contribution producer

Task UUID:fa339818-55f6-467c-b5fc-31eb0052762a. Isolated two-module implementation. No production edit, recognition gate change, fitted threshold, DST/RAM input, species decision or AT event.

## Implemented result

The compositor now tracks direct body RGB contribution separately from final color writer, depth writer, and changed pixels. An accepted later map blend retains an earlier actor contribution exactly when the destination RGB coefficient remains nonzero. Opaque source replacement removes prior contribution. Transparent, depth-rejected and duplicate-ID-skipped fragments leave it unchanged. Unsupported shadow/depth-only paths remain unsupported instead of being interpreted as color writes.

Two new source masks are retained on accepted mixed compositor results:

- nativeState.preFogBodyColorContribution: nonzero direct body RGB coefficient lineage after admitted color writes, before fog.
- nativeState.bodyColorContribution: the same lineage after the admitted RGB fog operation. Full RGB fog replacement removes the prior term; partial/disabled/alpha-only fog preserves it as appropriate.

The extent reader adds a distinct directBodyColorContribution summary. Existing bodyColorOwnership and its incomplete final-writer flags remain unchanged. No current comparator or AT consumer uses the new summary. This does not silently convert final-writer ownership into full contribution ownership.

## Precise contract

The mask tracks nonzero source-coefficient dependency before integer rounding, not a counterfactual visible-pixel difference. Equal colors or quantization may cancel numerical changes even when the coefficient is nonzero. It does not infer visible body membership, identity, shadows, indirect occlusion/depth influence or whole-scene correctness.

For an admitted accepted color write with body-source flag B:

- Alpha31 replacement: M = B.
- Alpha1..30: a = alpha5 + 1. If blending is enabled and prior alpha is nonzero, destination coefficient is32−a; otherwise it is zero. M = B OR (destination coefficient >0 AND previous M).
- Alpha zero, failed depth, duplicate translucent ID and all other skipped color writes: M is unchanged.

The opaque actor branch sets M=1 only at its existing accepted RGB write. Map writes use B=0. Actor translucent-list writes use B=1, including their alpha31 texels. Native operations, their order, RGB/depth arithmetic and existing ownership assignments are untouched.

Fog uses the existing source formula ((128−w)C+wF)>>7. Only enabled RGB fog with w=128 removes the direct RGB coefficient. Alpha-only fog leaves RGB dependency intact. Unsupported negative source weights (w>128) cannot produce a complete contribution capability. Depth-dependent fog effects are not represented as direct body RGB contribution.

## Source binding

The new capability is owned by the exact compositor result in a private WeakMap. The extent reader requires the same guarded map-before-natural-body destination, valid source frame and alignment, renderer subset, and unchanged identities/bytes for both contribution masks, final-writer mask and source coverage. Clones, JSON claims, stale bindings, changed masks, unknown order, missing bindings and unsupported operation modes remain unknown. A contribution mask is never reconstructed from composite alpha.

The compositor import URL, including its query string, must be identical in monster-native-body.mjs and monster-native-extent-evidence.mjs so both use the same result capability registry. This checkpoint uses their existing shared compositor query. A mismatch fails conservatively to unknown.

## Actual ROM/video witness

Twenty exact retained best recipes from the four grouped4200 regions and all five retained source models were replayed before/after. All prior RGBA, pre-fog RGB, depth, IDs, facing/fog flags, changed masks, final/depth ownership, other renderer metadata, scores and prior extent fields match exactly.

The four z038a draws now provide separate complete direct-RGB-lineage summaries with417,535,1,282 and1,157 pixels. In these particular draws they equal the final-writer masks, with zero remaining earlier-contribution pixels hidden behind a later non-body writer. The source path still contains accepted early opaque writes, so the earlier zero-early-write shortcut remained ineligible. The new masks establish the actual color-dependency result instead of assuming it from materials or final ownership alone.

Synthetic layered cases explicitly exercise earlier body color retained through later map blends where the final writer is not the body. Actual masks matching on these four draws is not generalized to other poses, materials or scenes.

No classifier or AT gate changed. Full-resolution grouped appearance disagreement and all earlier false/unknown outcomes remain; the producer does not certify z038a or force a model to pass.

## Exact source files

- web/monster-native-scene-composition.mjs: track the two masks at existing accepted color-write/fog branches and expose a source-bound capability reader.
- web/monster-native-extent-evidence.mjs: expose the new direct contribution summary separately, preserving all old final-writer and opaque-path fields.

The narrow zero-early-opaque checkpoint and all previous negative experiments remain unchanged in their original directories. This implementation starts from the current deployed-stage baseline, not from that unpromoted shortcut.

## Validation

See VALIDATION_SUMMARY.json and TWO_FILE_MANIFEST.json for final counts and hashes.

- Layered cases cover retained prior actor color, opaque replacement, disabled blending, zero alpha, failed depth, duplicate IDs across map/body, alpha31 texels in translucent lists, full/partial/alpha-only/disabled fog, unsupported fog weights, shadow/depth-only rejection, source binding and mask mutation.
-256 independent coefficient-oracle cases compare direct lineage against a separate real-valued coefficient recurrence while proving all previous pixels/native state unchanged.
-15 unchanged legacy extent tests and1,000 legacy mixed composition sequences pass. The optional external C++ oracle was not invoked in this run.
-All20 exact actual-source replays pass. Four new contribution capabilities are produced, while all existing final-writer flags and prior output fields remain identical.

## Reproduce

From the existing private workspace:

    node track-body-color-contribution-fa339818/tests/direct-contribution.test.mjs
    node track-body-color-contribution-fa339818/tests/legacy-scene-composition.test.mjs
    node track-body-color-contribution-fa339818/tests/legacy-native-extent.test.mjs
    node track-body-color-contribution-fa339818/scripts/replay-exact-owned-proposals.mjs

The actual replay uses the prior grouped-native witness, saved exact video comparison, formal ROM and existing source geometry runtime named in the script. It does not introduce a pose/root/camera from emulator state or hand-select a new winning draw.

## Privacy and status

Source archive only: two changed modules, scripts/tests, patch, manifest, this report and aggregate summaries. ROM command extraction, exact source recipes and large private evidence are kept separately and must never be committed or published. Parent owns review/integration. No production activation or general recognition completion is claimed.

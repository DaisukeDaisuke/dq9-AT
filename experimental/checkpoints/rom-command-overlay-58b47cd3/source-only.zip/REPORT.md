# ROM-derived command-overlay checkpoint

Task UUID: 58b47cd3-cbce-42b0-9c17-6c5880628d94, generated with Python uuid.uuid4(). Isolated work only. Baseline: parent-camera-alternative-integration-0523/web, parent-supplied commit 126d5dfd207ce2dbf144ce196c48dd84f5ef5828. No baseline, Git, browser, external Work, gateway, user-PC or emulator-state operation was performed. The local v1.1 assignment protocol was read; no external committee identity was adopted.

## Useful result and limit

The actual command HUD is `data/bin/icon.nsarc` → `wing1.spr`, a source-authored 32×32 four-bit sprite containing the wing, X symbol and コマンド text. Its 347 opaque pixels are decoded at runtime from ROM. Source code independently supplies the ordinary default placement, (212,8), but that position is **not used to restrict the whole-scene search or assume visibility**.

A robust four-stratum source-template matcher finds one candidate at (212,8) on all five supplied frozen frames. Its correlation threshold was generated from 486 synthetic positives and 66 synthetic negatives before these real-frame scores were evaluated. The threshold is 0.6937063578643885; real scores are 0.9350614882–0.9473745082. The runtime module can recompute the calibration directly from ROM; no manually entered parameter JSON is needed.

The important conservative limit remains: this is an advisory UI explanation, **not verified complete pixel ownership in a lossy capture**. One-pixel occlusions still look like the command sprite. An additional blur on actual4200 yields a second, false background match, which is retained as ambiguity rather than silently choosing the known location. Therefore the robust path creates no exclusion mask. Production is not modified and no fixed-frame monster box has been removed.

## Current production path, checked from source

The old `monster-position-proposals.mjs:144` masks the fixed rectangle (212,0,44,39), and its callers in the old recognition page/observer request that exclusion. That is a separate path.

The current `map-browser-preview/map-video-comparison.mjs:150` calls `compareMapBackground` directly. `map-video-residual.mjs` imports `estimateCameraTranslation` from the old proposer but never calls `proposeEnemyROIs` or applies its HUD gate. It runs its unchanged Otsu split and four-neighbour components over valid background/video pixels. This establishes a current source-path gap; it is not a claim of a new live-browser reproduction.

## ROM evidence, instead of an evaluation answer rectangle

- Overlay17's table pointer at 0219c418 addresses the slot/name table. Slot0 names `wing1.spr`. The loading loop at 0219c258–0219c2b4 loads it through the ROM archive.
- ARM9 02048960 decodes the SPR image count, format, per-image dimensions, piece offsets and texture exponents, packed pixel payload and palette. For format3, each texture consumes `(8<<wx)*(8<<hy)/2` bytes. The implementation does not invent width, height, sprite pixels or palette values.
- ARM9 02047fbc initializes unity scale, alpha31 and RGB modulation0x7fff.
- Overlay17 0219bb38–0219bb88 draws slot0, image0 through the screen-relative GX quad path. Its transparency argument1 reaches TEXIMAGE_PARAM bit29 in 02048538; source palette index0 is transparent.
- Overlay17 0218ce2c and 0218ce38 provide ordinary initialization x/y values, guarded by source modes not equal to6 or9. Current mode, visibility and later rendering/capture state are not inferred from that initialization.
- Six code spans are hash-bound. Unsupported changed source code fails closed. The SPR image/palette payload is decoded; the unused animation footer is retained as uninterpreted metadata. No RAM, DST, SAV or native-emulator truth was read.

`SOURCE_RELATION.json` records the code ranges, hashes and source provenance, without resource pixels.

Initial NCER/NCGR/NCLR inventory was useful for finding the actual asset but is not the command draw mode. The final source relation is a GX sprite, not a DS 2D OBJ cell.

## Implementation

`web/rom-command-overlay.mjs`:

- Strict source format3 decoder and ROM/code-bound command-resource loader
- Exhaustive integer-translation search over the entire supplied frame
- Separate best-match diagnostics and exact-raster exclusion authority
- Exact match requires all347 opaque source RGB888 pixels, with one unique placement; no fitted tolerance
- Residual partition copies and retains the original mask and region IDs, never recomputes the Otsu threshold, and never removes an entire bounding box
- Frame hashes, ROM identity, source epoch, segment, time and current-frame checks reject stale/tampered data
- Four-neighbour membership reconstruction validates the complete original raw-component domain; ROI overlap is not treated as component membership

`web/rom-command-overlay-advisory.mjs`:

- Source-only templates for identity and one/two fixed binomial-blur passes
- Fully source-opaque support only, split into four scan-order strata; score is the minimum Pearson intensity correlation across strata
- Exhaustive placement search, with distinct competing matches preserved
- Bounded deterministic synthetic calibration from the loaded ROM sprite; no real video is a calibration input
- A downstream advisory branch that references original region IDs and exact source-support/component intersections, preserving every raw region and body decision
- No robust-path exclusion mask or species, tracking, birth or AT certification

## Actual measurements

All five actual frames retain every original region and residual pixel. Consequently actual applied exclusions and body false exclusions are both zero. This is not a completed correction or proof of universal safety.

| Frame | Whole-scene score | Exact source-support intersections of raw components |
|---|---:|---|
|4200|0.9437490080|region0:225/225; region2:29/29|
|1200|0.9419261791|18:200/201; 2:74/74; 15:4/4; 14:3/3; 13:1/2; 16:2/2; 11:1/1; 17:1/1|
|c28|0.9350614882|70:62/585; 33:187/187; 75:35/35|
|2355|0.9412206637|0:279/281; 1:2/2|
|3300|0.9473745082|24:347/352|

4200's false command-region2 gets an advisory source-UI competitor covering all29 residual pixels. The grouped0/2 UI witness overlaps254 source-opaque residual pixels. The actual mallet/body fragments25 and34 have zero overlap and are preserved. The c28 component70 example is especially important: only62 of585 pixels overlap source support, so discarding its whole box would be unjustified.

The exact baseline excludes nothing on all five real frames. Only12–16 of347 source pixels agree even in5-bit RGB; complete RGB equality fails. The bit-replicated palette version's raw mean absolute RGB errors are31.66–33.96. A formula-only bilinear upscale/downscale hypothesis, using the actual960×720 recording ROI, lowers error on227 fully source-opaque pixels to22.78–23.92, but still does not establish parity. Nearest upscale plus bilinear downscale does not change the native source raster here. These errors do not isolate codec loss as the sole cause: capture filter/phase, projection, final compositing/master brightness and exact RGB expansion are not bound end-to-end.

## Calibration and held-out controls

The source-independent plan was frozen in `ROBUST_CALIBRATION_PROTOCOL.json` before robust real-frame scoring. Positive transforms are fixed source-generated blur0/1/2, gain0.75/1/1.25, bias−16/0/16 and bounded perturbation0/4/8, against six generated background families. Negatives use complete background searches, source-color permutations and source-quarter/half occlusions. These generic bounds are an explicit synthetic domain, not an assertion that all recordings fall within it.

Synthetic minimum-positive score:0.7812001721. Maximum-negative score:0.6062125437. Their separation midpoint supplies the frozen threshold. Refactoring calibration into the runtime module reproduces the original calibration JSON byte-for-byte, SHA2566c1f336e1dcc3777ac71f819a280f00989d0afdc8d630d0564d76b1f876f57c7. No retuning followed actual validation.

Actual-frame validation includes55 counterfactual checks, generated from the original frame plus the same ROM background, with no hand-selected HUD coordinates:

- Five HUD-canvas replacements by ROM background reject
- Thirty source-quarter/half occlusions reject
- Five left-edge clipped copies reject
- Five distant duplicate HUDs return multiple-match ambiguity
- Four of five additionally blurred frames retain one candidate; blurred4200 yields a second background candidate at (17,95), score0.7027964285, and becomes ambiguous
- All five one-pixel occlusions retain a presence candidate. This demonstrates why robust template presence does not certify every source-support pixel belongs to the overlay

These are labelled counterfactuals, not naturally HUD-absent/occluded footage. No independent naturally absent recording was supplied or claimed. All originally visible world bodies remain in the complete-frame search domain; no extra above-threshold distinct match was found on the unmodified five frames. This is not an exhaustive world-body negative corpus.

## Tests and reproducibility

99 assertions pass:56 source/parser/exact-mask checks and43 robust-calibration/advisory checks. Cases include shifted exact sprites, empty background, one-pixel changes, clipping, blur, duplicate ambiguity, source-code changes, copied/tampered metadata, stale frame cancellation, image mutation, malformed dimensions and original-component membership.

From the workspace root:

    node exclude-rom-command-overlay-58b47cd3/tests/rom-command-overlay.test.mjs
    node exclude-rom-command-overlay-58b47cd3/scripts/calibrate-advisory.mjs
    node exclude-rom-command-overlay-58b47cd3/tests/advisory.test.mjs
    node exclude-rom-command-overlay-58b47cd3/scripts/replay-fixed.mjs
    node exclude-rom-command-overlay-58b47cd3/scripts/check-capture-transforms.mjs
    node exclude-rom-command-overlay-58b47cd3/scripts/validate-advisory.mjs

Private ROM and existing frozen captures are required by the fixture adapter. Production integration must supply its already-loaded ROM and frozen video image; it must not ask the user to type a threshold, map, model or per-frame mask.

Exploratory first failures were ordinary harness issues: an overlay adapter exposed `read` rather than `.bytes`, an NCER contact-sheet script initially stopped on unsupported affine cells, and the first calibration script had a `case0` syntax typo. These did not alter a source format or tune recognition. Early overlap diagnostics counted every residual pixel inside a region's ROI; final measurements validate actual four-neighbour membership and supersede those ROI-only counts. The original intermediate reports remain private.

## Remaining work and recommendation

Preserve this as a source-derived **advisory UI branch**. It establishes the correct source asset and a robust full-scene presence hypothesis and identifies the exact4200 false UI regions without relying on their known coordinates. It does not yet implement a safe complete real-capture exclusion or suppress the false world-monster prediction in production.

A downstream consumer could retain this UI explanation as competition to a world-body hypothesis while keeping all raw pixels and uncertainty. That integration and its effect on the existing body comparator were not performed. Promoting it to pixel exclusion requires a supported account of capture/occlusion ownership and broader naturally absent/body negatives; the observed blurred-background and one-pixel controls must not be hidden by tuning this threshold.

The source archive contains only code, tests, this report, provenance hashes and aggregate results. ROM/video bytes, rendered or captured pixels, extracted assets and disassembly payloads remain outside it. No publication was attempted.

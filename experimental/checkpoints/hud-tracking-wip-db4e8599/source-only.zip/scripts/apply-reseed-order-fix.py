from pathlib import Path
r=Path('merge-hud-measured-tracking-db4e8599')
helper='''
// Wait only for the target retained frame's measured record, not all future
// replay work. This creates no correspondence or handoff evidence by itself.
export async function waitForMeasuredReplayFrame({replay,stamp,isCurrent=()=>true,yieldTask=pause}){
 const key=videoTrackingFrameKey(stamp),source=videoTrackingSourceKey(stamp),pts=stamp.mediaTime??stamp.videoTime;
 for(;;){
  if(!isCurrent())return{recordAvailable:false,reason:'comparison-invalidated',frameKey:key};
  const state=replay.snapshot();if(state.sourceKey!==source)return{recordAvailable:false,reason:'replay-source-differs',frameKey:key};
  const frame=replay.frames.find(f=>f.key===key),record=replay.history.get(key);
  if(!frame||frame.conflicted)return{recordAvailable:false,reason:'target-frame-not-retained-or-conflicted',frameKey:key};
  if(record&&record.batchId===replay.batch?.id&&!record.previousFrame.conflicted)return{recordAvailable:true,reason:'matching-measured-record-available',frameKey:key};
  if(!replay.busy||state.currentPTS===null||state.currentPTS>=pts)return{recordAvailable:false,reason:'no-pending-measured-record-for-target',frameKey:key};
  await yieldTask();
 }
}
'''
for folder in [r/'web',r/'reseed-order-fix/web']:
 p=folder/'map-browser-preview/video-tracking-replay.mjs';s=p.read_text();assert 'waitForMeasuredReplayFrame' not in s;p.write_text(s+helper)
 p=folder/'map-browser-preview/map-video-comparison.mjs';s=p.read_text();s=s.replace('import{VideoTrackingReplay}', 'import{VideoTrackingReplay,waitForMeasuredReplayFrame}')
 s=s.replace('let latestTracking=null;', 'let latestTracking=null;let comparisonCompletion=Promise.resolve();',1)
 needle='  }else await renderBackground();\n }';assert needle in s;s=s.replace(needle,'  }else await renderBackground();\n  if(targetFrameId===frozen?.id)await comparisonCompletion;\n }',1)
 needle=' function compare(preserveContinuous=false){try{';assert needle in s;s=s.replace(needle,' function compare(preserveContinuous=false){const completion=(async()=>{try{',1)
 needle='  const measuredContinuity=fastReplay.continuityFor';assert needle in s;s=s.replace(needle,"  const targetFrame=frozen,targetBackground=background,targetComparison=comparison,comparisonCurrent=()=>targetFrame===frozen&&targetBackground===background&&targetComparison===comparison;\n  await waitForMeasuredReplayFrame({replay:fastReplay,stamp:targetFrame.evidence,isCurrent:comparisonCurrent});if(!comparisonCurrent())return false;\n"+needle,1)
 needle=" }catch(e){$('download-comparison').disabled=!frozen;status('比較できません：'+e.message);}};";assert needle in s;s=s.replace(needle," }catch(e){$('download-comparison').disabled=!frozen;status('比較できません：'+e.message);}})();comparisonCompletion=completion;return completion;};",1)
 needle='  if(!comparison||!frozen||!background)return;const expectedFrame=frozen;automaticActivationEpoch++;';assert needle in s;s=s.replace(needle,'  if(!comparison||!frozen||!background)return;const expectedFrame=frozen,expectedBackground=background,expectedComparison=comparison;await comparisonCompletion;if(expectedFrame!==frozen||expectedBackground!==background||expectedComparison!==comparison)return;automaticActivationEpoch++;',1)
 p.write_text(s)

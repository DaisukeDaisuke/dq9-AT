import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {openMapRom} from '../baseline/web/map-browser-preview/static-scene.mjs';
import {buildRomMapCatalog} from '../baseline/web/map-browser-preview/rom-map-catalog.mjs';
import {loadAutomaticScene} from '../baseline/web/map-browser-preview/automatic-scene.mjs';
import {createRendererSourceArchives} from '../baseline/web/map-browser-preview/renderer-source-archives.mjs';
import * as before from '../baseline/web/map-browser-preview/mode1-photometric-inverse.mjs';
import * as after from '../candidate/web/map-browser-preview/mode1-photometric-inverse.mjs';
import {prepareNativeIntegerCompute as prepareJob} from '../baseline/web/map-browser-preview/native-integer-compute-input.mjs';
const root='reduce-background-latency-aa33472f/',inputRoot='recovery-20261006-0852/capture-inputs/restored-fixed-captures/inspect-map-video-publication-20261005/';
const hash=v=>crypto.createHash('sha256').update(v).digest('hex'),json=v=>JSON.stringify(v,(k,v)=>typeof v==='bigint'?{bigint:v.toString()}:v instanceof Map?{map:[...v]}:ArrayBuffer.isView(v)?{type:v.constructor.name,values:[...v]}:v);
const rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds'),archives=createRendererSourceArchives(),project=archives.forProject(openMapRom(rom),rom),records=buildRomMapCatalog(project).maps;
const bodyBytes=fs.readFileSync(inputRoot+'BROWSER_LONG2355_BODY_df40cb.json'),cmpBytes=fs.readFileSync(inputRoot+'BROWSER_LONG2355_COMPARISON_df40cb.json'),body=JSON.parse(bodyBytes),cmp=JSON.parse(cmpBytes),branches=body.source.background.backgroundBranchSupport.branches,record=records.find(r=>r.key===branches[0].recordKey),automatic=loadAutomaticScene(project,record),video={...cmp.analysisVideo,rgba:Uint8Array.from(cmp.analysisVideo.rgba)};
const report={kind:'measured-mode1-source-decoding-reuse',scope:'Three unchanged saved long2355 ROM/video camera branches. No DST/RAM, new pose, threshold, branch pruning, or browser-throughput claim.',source:{romSHA256:hash(rom),bodySHA256:hash(bodyBytes),comparisonSHA256:hash(cmpBytes),recordKey:record.key},equivalence:[],cancellation:[],timings:[]};
const stripTime=job=>({...job,evidence:{...job.evidence,preparationMs:0}});
for(let index=0;index<branches.length;index++){
 const args={project,rom,record,automatic,camera:branches[index].camera},a=before.prepareMode1PhotometricBasis(args),b=after.prepareMode1PhotometricBasis(args);
 // Check all typed-array values, scores, rejection ledgers, ordinary states and source metadata, not just rendered RGBA.
 assert.deepStrictEqual(b,a);
 const row={index,point:branches[index].point,modelEqual:true,modelSHA256:hash(json(a)),polygons:a.inventory.polygons.length,gpuJobs:[],cpuBasis:[]};
 for(const weights of [false,true]){
  const jobA=prepareJob(weights?a.weightInventory:a.inventory,weights?a.weightTranslucent:a.translucent,a.controls,{...a.read.hypotheses[0].fogParameters,enabled:false}),jobB=prepareJob(weights?b.weightInventory:b.inventory,weights?b.weightTranslucent:b.translucent,b.controls,{...b.read.hypotheses[0].fogParameters,enabled:false});assert.deepStrictEqual(stripTime(jobB),stripTime(jobA));row.gpuJobs.push({weights,allWordsAndLedgerEqual:true,sha256:hash(json(stripTime(jobA)))});
  const basisA=await before.renderMode1PhotometricBasis(a,{weights}),basisB=await after.renderMode1PhotometricBasis(b,{weights});assert.deepStrictEqual(basisB,basisA);row.cpuBasis.push({weights,allOutputsEqual:true,rgbaSHA256:hash(basisA.rgba),ownershipSHA256:hash(new Uint8Array(basisA.owner.buffer)),knownMaskSHA256:hash(basisA.knownMask)});
  if(weights){row.resultBefore=before.inferMode1OrdinaryColor({model:a,basis:row._basisA,weights:basisA,video});row.resultAfter=after.inferMode1OrdinaryColor({model:b,basis:row._basisB,weights:basisB,video});assert.deepStrictEqual(row.resultAfter,row.resultBefore);delete row._basisA;delete row._basisB;}else{row._basisA=basisA;row._basisB=basisB;}
 }
 report.equivalence.push(row);console.log('branch',index,'exact model, packed GPU jobs, CPU outputs and inference result equal');
}
const args={project,rom,record,automatic,camera:branches[0].camera};
for(const stopAfter of [0,1,3,30,200]){
 const results=[];
 for(const impl of [before,after]){let yields=0,tick=0;try{await impl.prepareMode1PhotometricBasisAsync(args,{isCurrent:()=>yields<stopAfter,yieldTask:async()=>{yields++;},sliceMilliseconds:1,now:()=>tick++});assert.fail('Expected cancellation');}catch(e){results.push({stopAfter,yields,name:e.name,message:e.message});assert.equal(e.name,'AbortError');}}
 assert.deepStrictEqual(results[1],results[0]);report.cancellation.push(results[0]);
}
// Warm both implementations, then alternate order so no side always runs first.
for(let i=0;i<2;i++){before.prepareMode1PhotometricBasis(args);after.prepareMode1PhotometricBasis(args);}
for(let i=0;i<12;i++){
 const row={round:i,order:i%2?['candidate','baseline']:['baseline','candidate']};
 for(const name of row.order){const t=performance.now();const model=(name==='candidate'?after:before).prepareMode1PhotometricBasis(args);row[name+'Ms']=performance.now()-t;assert.equal(model.inventory.polygons.length,636);}
 report.timings.push(row);console.log('timing',row);
}
const median=a=>a.toSorted((x,y)=>x-y)[Math.floor(a.length/2)];report.summary={pairs:report.timings.length,baselineMedianMs:median(report.timings.map(r=>r.baselineMs)),candidateMedianMs:median(report.timings.map(r=>r.candidateMs))};report.summary.reductionPercent=100*(1-report.summary.candidateMedianMs/report.summary.baselineMedianMs);report.summary.allEquivalencePassed=true;report.summary.cancellationBoundariesPassed=report.cancellation.length;
fs.writeFileSync(root+'evidence/VERIFICATION.json',JSON.stringify(report,null,2));console.log('SUMMARY',report.summary);

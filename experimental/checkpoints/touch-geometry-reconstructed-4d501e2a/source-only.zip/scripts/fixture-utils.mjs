import fs from'node:fs';import crypto from'node:crypto';
import{openMapRom}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/static-scene.mjs';
import{readArm9Overlay}from'../../recovery-20261006-0852/current-dq9-AT/web/map-browser-preview/rom-overlay.mjs';
export const root='restore-touch-geometry-4d501e2a/',hash=b=>crypto.createHash('sha256').update(b).digest('hex');
export function source(){const rom=fs.readFileSync('recovery-20261006-0852/verified/dq9_new2.nds'),romSHA256=hash(rom);if(romSHA256!=='3c9d809eb8e446b0da6a9b383c7a6c5146001636038384aa49cb1a2e367546d7')throw Error('Formal ROM hash differs');return{opts:{romSHA256,...openMapRom(rom),fieldOverlay:readArm9Overlay(rom,17)}};}

# Appearance sampling investigation: optional domain, no preprocessing bug established

Task UUID:12deb83d-4393-4b54-a3e6-5ae1cca433c5. One new isolated helper; all383 existing web files remain byte-identical. No production integration, threshold fitting, appearance-veto removal or identity certification.

## Finding

The4200 grouped body ranking flip is reproducible from the same decoded RGB pixels by changing the sampling/crop operator order. It is not explained solely by browser-versus-FFmpeg RGB conversion.

- Source-resolution enclosing crop → unchanged DINO bicubic224: z005b0.5503666, z002b0.5208409.
- Same source RGB → existing pixel-center-bilinear256×192 gameplay grid → native crop → same DINO preprocessing: z002b0.6230246, z005b0.5994086.
- Original retained browser-native grid → native crop: z002b0.6021535, z005b0.6003495.

This comparison changes the resampling order, including its associated interpolation/crop phase. It does not prove one particular filtering stage is a bug, or that the native-grid ranking identifies the creature. Source and native crop aspect/crop quantization are intentionally different representations.

## Exact path inspection

`residualClassificationRequest` maps the native residual ROI into an enclosing integer source-resolution crop using floor/ceil. It preserves opaque video alpha. `recognizeROI` passes that crop to the DINO encoder without an intermediate native-display reduction.

The ROM bank uses64px CPU templates, quick bind/stand/run/appear midpoint poses and four45-degree camera views. `dinoInput` uses alpha>=128 only to find template-tight bounds, composites straight template RGB over gray128 once, applies the same aspect-preserving bicubic224 letterbox and ImageNet normalization used for queries. Queries retain their opaque world/background pixels. The CPU renderer produces straight, not premultiplied, RGB. Tests verify identical opaque query/template pixels normalize identically, and a semi-transparent template receives exactly one gray composite.

No wrong coordinate mapping, double alpha multiplication or separate query/template normalization defect was established. Gray-background ROM templates versus opaque video context and the bank's approximate camera/pose/lighting remain limitations. They were not changed or presented as solved.

## Implemented helper

`web/monster-native-grid-query.mjs` exports `nativeGridAppearanceQuery`.

It returns a separately labelled query from the already-owned256×192 gameplay sampling grid, using an exact integer native ROI. It verifies the captured sampling profile, native RGBA hash, source identity, opaque alpha, bounded crop, cancellation and stale-source guards before/after asynchronous hashing. It never masks residual/background pixels, chooses a model, changes a bank vector or replaces the old source crop.

This grid matches the existing ROM background/body comparison grid. That comparability does not make the normalized64px appearance bank's pose/camera/shading equal to video. The helper is standalone and inactive; no existing recognition request or cache path was wired to it.

## Fixed evaluation

All five fixed frames were recomputed with all requested model candidates and unchanged supported bank policy:

-125 original classified regions plus all37 existing4200 component-tree groups.
-30 unique ROM model banks,456 available template vectors (504 template occurrences across the five fixture banks).
-422 fresh query embeddings. Every query image and its normalized tensor was revalidated against the final helper/preprocessor hashes.
-Unsupported/missing animation clips are retained with their original parser failures; no unsupported curve was approximated or silently substituted.

For1200/4200/2355/3300, the decoded I420 hashes exactly equal the saved capture hashes. Their FFmpeg RGB conversions differ from browser-canvas RGB, so those domains remain explicit. Source-resolution and native-grid controls use identical decoded RGB within each fixture. c28 retains exact native RGBA but no saved I420 fingerprint; a seek-time guess was not substituted for its unavailable exact fresh full-resolution control. c28 still receives a fresh native-grid query across all four models.

Across the130 ROIs with exact source-frame controls, source-crop versus native-grid sampling changes54 top-model results. Browser-native versus decoded-native RGB changes5 top-model results. This demonstrates substantial sampling sensitivity, not calibration or correctness.

## Positive and negative outcomes

With the old thumbnail body-fit rule and all thresholds held fixed:

-1200 region58 remains z061c in all three domains.
-c28 region12 still ranks z019b first. Its original thumbnail gate remains unknown.
-4200 native-grid queries remove the existing z038a agreements on mallet-head25 and handle34 and add z002b agreement on the body-sized merged proposal.
-They also introduce false z038a agreements on the larger command UI region0 and the player's selection-ring fragment18. The smaller command UI region2 remains false. These regressions occur in both browser-native and controlled-native RGB.
-Several grouped UI/background agreements remain: native-grid has seven thumbnail agreements across the47 raw/grouped4200 ROIs, versus four in the controlled source-resolution domain. These counts include false hypotheses and are not a detection-quality metric.
-3300 native-grid queries remove the two existing z002b agreements on120/131; this is not evidence that every associated body fragment was recovered.
-2355 has no new final thumbnail agreement after unchanged map compatibility.

The current production camera comparator was separately evaluated using only the same captured native pixels and the exact fixed native proposal corpus. All125 outcomes are unchanged, including c28 residual12/z019b. Converted-RGB queries were not rebound to old camera evidence. No improvement in the actual current camera-alternative outputs is claimed.

The ROM command-overlay worker independently reports source support overlapping4200 raw0/2. That was read-only coordination; no UI mask, matcher threshold or exclusion rule was borrowed into this implementation.

## Recommendation

Do not replace the default query with this native-grid path. It gives a useful, source-bound alternative sampling domain and explains the4200 ranking discrepancy, but introduces UI/player-fragment false agreements. Preserve it as an inactive experimental helper and retain both domains' failures. No broader speculative fix is proposed.

## Tests and reproduction

19 helper/preprocessor assertions pass. The complete run and final revalidation are reproducible from the existing private workspace:

    python3 compare-appearance-sampling-12deb83d/scripts/prepare-controlled-frames.py
    node compare-appearance-sampling-12deb83d/tests/native-grid-query.test.mjs
    node compare-appearance-sampling-12deb83d/scripts/evaluate-sampling-domains.mjs
    node compare-appearance-sampling-12deb83d/scripts/summarize-sampling.mjs

The decode preparation reuses existing buffers only after verifying their recorded hashes and I420 identity; it does not overwrite a changed prior decode. The inference uses the pinned model and ONNX Runtime Web1.23.2 WASM assets with manifest checks. The runtime emitted an unknown-CPU-vendor warning; all runs completed. No live browser/controller/AT integration was executed.

`SOURCE_INPUT_MANIFEST.json` records baseline/source hashes and fixed input identities. Raw RGBA/YUV, ROM, game template pixels and large per-query evidence remain private. The source archive contains only the new helper, tests/scripts, this report, hashes and aggregate outcomes. No game assets were committed or published.
